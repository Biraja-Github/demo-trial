# 2.0.2 (2015-03-10)

## Features

- **text Over Flow**
  - text OverFlow component is moved to new pattern library and referenced css are updated.

- **Checkbox**
  - checkbox should show title based on value provided.

- **Radio Button**
  - radio button should show title based on value provided.    
  
## Bug Fixes

- **Selector**
  - Fixed performance and Accessibility issues.
  
- **Hour Picker**
  - on change of model value in hour picker component, same value is not updating in hour picker component.

## Breaking Changes

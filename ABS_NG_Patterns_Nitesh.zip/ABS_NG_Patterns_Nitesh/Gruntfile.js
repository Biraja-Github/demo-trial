'use strict';

var path = require('path'),
    neat = require('node-neat').includePaths,
    LIVERELOAD_PORT = 35729,
    mountFolder = function (connect, dir) {
        return connect['static'](path.resolve(dir));
    };

module.exports = function (grunt) {
    require('time-grunt')(grunt);
    require('jit-grunt')(grunt);

    var yeomanConfig = {
        app: 'app',
        dist: 'dist',
        pl: 'ui-patterns-library'
    };

    grunt.initConfig({
        yeoman: yeomanConfig,

        watch: {
            sass: {
                files: [
                    '<%= yeoman.app %>/styles/**/*.{scss,sass}',
                    '<%= yeoman.pl %>/css/**/*.{scss,sass}'
                ],
                tasks: ['sass']
            },
            jshint: {
                files: [
                    '{.tmp,<%= yeoman.app %>}/scripts/**/*.js'
                ],
                tasks: ['jshint']
            },
            livereload: {
                options: {
                    livereload: LIVERELOAD_PORT
                },
                files: [
                    '.tmp/*.html',
                    '{.tmp,<%= yeoman.app %>}/scripts/**/*.js',
                    '{.tmp,<%= yeoman.app %>}/styles/**/*.css',
                    '<%= yeoman.app %>/images/**/*.{png,jpg,jpeg,gif,webp,svg}'
                ]
            },
            assemble: {
                files: [
                    '<%= yeoman.app %>/templates/layouts/*.hbs',
                    '<%= yeoman.app %>/templates/pages/**/*.hbs',
                    '<%= yeoman.app %>/templates/partials/**/*.hbs',
                    '<%= yeoman.app %>/data/*.json',
                    'lib/helpers/**/*.js'
                ],
                tasks: ['assemble']
            },

            webfont: {
                files: [
                    '<%= yeoman.app %>/icons/**/*.svg'
                ],
                tasks: [ 'webfont' ]
            }
        },

        connect: {
            options: {
                port: 9001,
                hostname: '0.0.0.0'
            },
            livereload: {
                options: {
                    middleware: function (connect) {
                        return [
                            require('connect-livereload')({ port: LIVERELOAD_PORT }),
                            mountFolder(connect, '.tmp'),
                            mountFolder(connect, yeomanConfig.app),
                            mountFolder(connect, yeomanConfig.pl)
                        ];
                    }
                }
            },
            test: {
                options: {
                    middleware: function (connect) {
                        return [
                            mountFolder(connect, '.tmp'),
                            mountFolder(connect, 'test')
                        ];
                    }
                }
            },
            dist: {
                options: {
                    middleware: function (connect) {
                        return [
                            mountFolder(connect, yeomanConfig.dist)
                        ];
                    }
                }
            }
        },

        open: {
            server: {
                path: 'http://localhost:<%= connect.options.port %>',
                app: 'Google Chrome Canary'
            }
        },

        clean: {
            dist: {
                files: [{
                    dot: true,
                    src: [
                        '.tmp',
                        '<%= yeoman.dist %>/*',
                        '!<%= yeoman.dist %>/.git*'
                    ]
                }]
            },
            server: '.tmp'
        },

        jshint: {
            options: {
                jshintrc: '.jshintrc'
            },
            all: [
                '<%= yeoman.app %>/scripts/**/*.js',
                '!<%= yeoman.app %>/scripts/vendor/*',
                '!<%= yeoman.app %>/scripts/ng_js_att/**/*',
                '!<%= yeoman.app %>/scripts/ng_js_att_tpls/**/*',
                'test/spec/**/*.js'
            ]
        },

        mocha: {
            all: {
                options: {
                    run: true,
                    urls: ['http://localhost:<%= connect.options.port %>/index.html']
                }
            }
        },

        sass: {
            dist: {
                options: {
                    includePaths: [
                        '<%= yeoman.app %>/styles',
                        '<%= yeoman.pl %>/css',
                        '<%= yeoman.app %>/styles/pages',
                        '<%= yeoman.app %>/styles/partials',
                        '<%= yeoman.app %>/bower_components'
                    ].concat(neat)
                },
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/styles/',
                    src: ['*.scss', '!_*.scss'],
                    dest: '.tmp/styles/',
                    ext: '.css'
                }, {
                    expand: true,
                    cwd: '<%= yeoman.app %>/styles/pages/',
                    src: ['*.scss'],
                    dest: '.tmp/styles/pages/',
                    ext: '.css'
                }]
            }
        },

        modernizr: {
            'devFile' : '<%= yeoman.app %>/bower_components/modernizr/modernizr.js',
            'outputFile' : '<%= yeoman.dist %>/scripts/modernizr.js',
            'extra' : {
                'shiv' : true,
                'printshiv' : false,
                'load' : true,
                'mq' : false,
                'cssclasses' : true
            },
            'extensibility' : {
                'addtest' : false,
                'prefixed' : false,
                'teststyles' : false,
                'testprops' : false,
                'testallprops' : false,
                'hasevents' : false,
                'prefixes' : false,
                'domprefixes' : false
            },
            'uglify' : true,
            'tests' : [],
            'parseFiles' : true,
            'matchCommunityTests' : false,
            'customTests' : []
        },

        assemble: {
            options: {
                flatten:    true,
                layout:     'default.hbs',
                assets:     'dist/images',
                layoutdir:  '<%= yeoman.app %>/templates/layouts',
                partials:   ['<%= yeoman.app %>/templates/partials/**/*.hbs'],
                data:       ['<%= yeoman.app %>/data/*.json'],
                plugins:    [ 'lib/plugins/*.js' ],
                helpers:    ['lib/helpers/**/*.js'],
                production: false
            },
            pages: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/templates/pages/',
                    src: ['*.hbs'],
                    dest: '.tmp/',
                    ext: '.html'
                }]
            },
            iframes: {
                options: {
                    layout: ['iframe.hbs']
                },
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/templates/pages/iframes',
                    src: ['*.hbs'],
                    dest: '.tmp/iframes/',
                    ext: '.html'
                }]
            }
        },

        useminPrepare: {
            options: {
                root: '<%= yeoman.app %>',
                dest: '<%= yeoman.dist %>'
            },
            html: '.tmp/**/*.html'
        },

        usemin: {
            options: {
                root: '<%= yeoman.app %>',
                dirs: ['<%= yeoman.dist %>'],
                assetsDirs: ['<%= yeoman.dist %>', '<%= yeoman.dist %>/images']
            },
            html: ['<%= yeoman.dist %>/**/*.html'],
            css: ['<%= yeoman.dist %>/styles/**/*.css']
        },

        imagemin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/images',
                    src: '**/*.{png,jpg,jpeg}',
                    dest: '<%= yeoman.dist %>/images'
                }]
            }
        },

        svgmin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/images',
                    src: '**/*.svg',
                    dest: '<%= yeoman.dist %>/images'
                }]
            }
        },

        cssmin: {
            dist: {
                options: {
                    keepSpecialComments: 0,
                    banner: '/* AT&T Style Guide Styles */'
                }
            }
        },

        htmlmin: {
            dist: {
                options: {
                },
                files: [{
                    expand: true,
                    cwd: '.tmp',
                    src: '**/*.html',
                    dest: '<%= yeoman.dist %>'
                }]
            }
        },

        copy: {
            dist: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.app %>',
                    dest: '<%= yeoman.dist %>',
                    src: [
                        '*.{ico,png,txt}',
                        '.htaccess',
                        'images/**/*',
                        'videos/*'
                    ]
                }, {
                    expand: true,
                    cwd: '.tmp/images',
                    dest: '<%= yeoman.dist %>/images',
                    src: [ 'generated/*' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.pl %>/css/fonts',
                    dest: '<%= yeoman.dist %>/styles/att/fonts',
                    src: [ '**/*.{eot,ttf,woff}' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.pl %>/css/images',
                    dest: '<%= yeoman.dist %>/styles/att/images',
                    src: [ '**/*.{png,jpg,jpeg,gif,webp}' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.app %>/styles/fonts',
                    dest: '<%= yeoman.dist %>/styles/fonts',
                    src: [ '**/*.{eot,ttf,woff}' ]
                }, {
                    expand: true,
                    cwd: '<%= yeoman.app %>/styles/images',
                    dest: '<%= yeoman.dist %>/styles/images',
                    src: [ '**/*.{png,jpg,jpeg,gif,webp}' ]
                }, {
                    expand: true,
                    cwd: '<%= yeoman.app %>/assets',
                    dest: '<%= yeoman.dist %>/assets',
                    src: [ '**/*.*' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.app %>/styles/ie',
                    dest: '<%= yeoman.dist %>/styles/ie',
                    src: '*.*'
                }, {
                    expand: true,
                    dot: true,
                    cwd: '.tmp/styles/pages',
                    dest: '<%= yeoman.dist %>/styles/pages',
                    src: '**/*.css'
                }, {
                    expand: true,
                    dot: false,
                    cwd: '<%= yeoman.app %>/data',
                    dest: '<%= yeoman.dist %>/data',
                    src: [ '**/*.json' ]
                }]
            },
            server: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.app %>/styles/fonts',
                    dest: '.tmp/styles/fonts',
                    src: [ '**/*.{eot,ttf,woff}' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.pl %>/css/fonts',
                    dest: '.tmp/styles/att/fonts',
                    src: [ '**/*.{eot,ttf,woff}' ]
                }, {
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.pl %>/css/images',
                    dest: '.tmp/styles/att/images',
                    src: [ '**/*.{png,jpg,jpeg,gif,webp}' ]
                }]
            }
        },

        rev: {
            dist: {
                files: {
                    src: [
                        '<%= yeoman.dist %>/scripts/**/*.js',
                        '<%= yeoman.dist %>/styles/**/*.css',
                        '<%= yeoman.dist %>/styles/images/**/*.{png,jpg,jpeg,gif,webp}',
                        '<%= yeoman.dist %>/images/**/*.{png,jpg,jpeg,gif,webp}'
                    ]
                }
            }
        },

        prettify: {
            dist: {
                options: {
                    indent: 4
                },
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.dist %>',
                    src: ['**/*.html'],
                    dest: '<%= yeoman.dist %>',
                    ext: '.html'
                }]
            }
        },

        concurrent: {
            server: [
                'sass:dist',
                'copy:server',
                'assemble:pages',
                'assemble:iframes'
            ],
            test: [
                'sass'
            ]
        },

        webfont: {
            icons: {
                src: '<%= yeoman.app %>/icons/*.svg',
                dest: '<%= yeoman.app %>/styles/fonts/icons',
                destCss: '<%= yeoman.app %>/styles/app',
                options: {
                    font: 'pl-icons',
                    engine: 'node',
                    htmlDemo: false,
                    stylesheet: 'scss',
                    relativeFontPath: 'fonts/icons',
                    templateOptions: {
                        classPrefix: 'pl-icon-'
                    }
                }
            }
        }
    });

    grunt.registerTask('server', function (target) {
        if (target === 'dist') {
            return grunt.task.run(['build', 'open', 'connect:dist:keepalive']);
        }

        grunt.task.run([
            'clean:server',
            'webfont',
            'concurrent:server',
            'connect:livereload',
            'watch'
        ]);
    });

    grunt.registerTask('test', [
        'clean:server',
        'concurrent:test',
        'connect:test',
        'mocha'
    ]);

    grunt.registerTask('build', function () {
        grunt.config.set('assemble.options.production', true);

        grunt.task.run([
            'clean:dist',
            'webfont',
            'sass:dist',
            'copy:dist',
            'assemble:pages',
            'assemble:iframes',
            'useminPrepare',
            'svgmin',
            'htmlmin',
            'concat',
            'cssmin',
            'uglify',
            'usemin'
        ]);
    });

    grunt.registerTask('default', [
        'jshint',
        'test',
        'build'
    ]);

    grunt.registerTask('dist', 'build');
};

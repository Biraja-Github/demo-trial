//
//  att.button.js
//  AT&T UI Library
//
//  Created by André Neves on 05/02/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.button', {
            _super: $.extend(true, {}, $.att.base, $.att.loading),

            isLoading: false,

            _render: function() {

            },

            _create: function() {
                var isLoading   = this.$callingElement.hasClass('button--loading');

                if (isLoading) {
                    this.loading(true);
                }

                this.isLoading = isLoading;
            },

            _enableLoading: function() {
                if (this.isLoading) {
                    return;
                }

                this.$loader = $.att.loading.create();

                this.$callingElement
                    .addClass('button--loading')
                    .append(this.$loader);

                this.isLoading = true;

                this.disabled(true);
            },

            _disableLoading: function() {
                if (!this.isLoading) {
                    return;
                }

                if (this.$loader && this.$loader.size()) {
                    this.$loader.remove();
                }

                this.$callingElement.removeClass('button--loading');

                this.isLoading = false;

                this.disabled(false);
            },

            _enable: function() {
                this.$callingElement.removeClass('button--disabled');

                if (this.$callingElement.is('button')) {
                    this.$callingElement.prop('disabled', null);
                }
            },

            _disable: function() {
                this.$callingElement.addClass('button--disabled');

                if (this.$callingElement.is('button')) {
                    this.$callingElement.prop('disabled', true);
                }
            },

            disabled: function(isDisabled) {
                this[isDisabled ? '_disable' : '_enable'].call(this);
            },

            loading: function(isLoading) {
                this[isLoading ? '_enableLoading' : '_disableLoading'].call(this);
            },

            options: {
                loaderClass: 'loading'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.loading' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('button:not(.button--dropdown), .button:not(.button--dropdown)').button();
        });
    }
})();

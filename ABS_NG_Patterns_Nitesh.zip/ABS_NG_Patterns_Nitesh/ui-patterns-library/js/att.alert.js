//
//  att.alert.js
//  AT&T UI Library
//
//  Created by André Neves on 02/09/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.alert', {
            _super: $.att.base,

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                setTimeout($.proxy(this, 'show'), this.option('showDelay'));
            },

            _init: function(option) {
                if (option !== 'hide') {
                    this.show();
                }
            },

            _render: function() {
                this.$callingElement.find('[data-role=close], [data-close]')
                    .off('click.att-close')
                    .on('click.att-alert', $.proxy(this, 'hide'));
            },

            show: function() {
                var self = this;

                this._clearTimeout();

                this.$callingElement.animate({ top: this.option('top') }, this.option('showDuration'), function() {
                    if (!self.option('sticky')) {
                        self.$callingElement.data('att.alert.hideTimeout', setTimeout($.proxy(self, 'hide'), self.option('hideDelay')));
                    }
                });
            },

            hide: function(e) {
                var self = this;

                this._clearTimeout();

                this.$callingElement.animate({ top: 0 }, this.option('hideDuration'), function() {
                    if (self.option('remove')) {
                        self.$callingElement.remove();
                    }
                });

                if (e) {
                    e.preventDefault();
                }
            },

            _clearTimeout: function() {
                clearTimeout(this.$callingElement.data('att.alert.hideTimeout'));
            },

            options: {
                /**
                 * The time in milliseconds to wait before showing the alert
                 *
                 * @type {Number}
                 * @default 0
                 */
                showDelay: 0,

                /**
                 * * The time in milliseconds to wait before hidding the alert
                 *
                 * @type {Number}
                 * @default 10000 (10 seconds)
                 */
                hideDelay: 10000,

                /**
                 * The show animation duration in milliseconds
                 *
                 * @type {Number}
                 * @default 200
                 */
                showDuration: 200,

                /**
                 * The hide animation duration in milliseconds
                 *
                 * @type {Number}
                 * @default 200
                 */
                hideDuration: 200,

                /**
                 * If the alert element should be removed after hidding.
                 * Useful if the alert is to be shown more than once.
                 *
                 * @type {Boolean}
                 * @default true
                 */
                remove: true,

                /**
                 * The Y offset from the document's top.
                 *
                 * @type {Number}
                 * @default 50
                 */
                top: 50,

                /**
                 * Controls if the alert hides automatically
                 *
                 * @type {Boolean}
                 * @default false
                 */
                sticky: false
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-alert]').alert();
        });
    }
})();

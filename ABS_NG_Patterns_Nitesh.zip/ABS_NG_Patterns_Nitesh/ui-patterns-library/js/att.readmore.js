//
//  att.readmore.js
//  AT&T UI Library
//
//  Created by André Neves on 15/09/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.readmore', {
            _super: $.att.base,

            _render: function() {
                this.$extraContent = this.$callingElement.find(this.option('extraSelector'));

                if (this.$extraContent.size()) {
                    this.$extraContent.attr('data-extra-content', 'true');
                }

                this.$toggle = $('<span>', { 'class': 'att-readmore-toggle' });
                this.$ellipsis = $('<span>', { 'class': 'att-readmore-ellipsis' });
                this.$link = $('<a>', { 'href': '#', 'class': 'link att-readmore-link' });

                this.$ellipsis.text(this.option('ellipsisText') + ' ');

                this.$toggle.append(this.$ellipsis);
                this.$toggle.append(this.$link);

                this.$toggle.on('click', this.toggle.bind(this));

                this.update();

                this.$callingElement.append(this.$toggle);
            },

            isExpanded: function() {
                return this.$callingElement.attr('data-expanded') !== undefined;
            },

            update: function() {
                var text = this.option( this.isExpanded() ? 'lessText' : 'moreText');

                this.$link.text(text);
            },

            toggle: function() {
                if (this.isExpanded()) {
                    this.$callingElement.removeAttr('data-expanded');
                } else {
                    this.$callingElement.attr('data-expanded', true);
                }

                this.update();
            },

            options: {
                /**
                 * The text to show when the extra content is collapsed
                 *
                 * @type {String}
                 * @default Read more
                 */
                moreText: 'Read more',

                /**
                 * The text to show when the extra content is expanded
                 *
                 * @type {String}
                 * @default Less
                 */
                lessText: 'Less',

                /**
                 * The text to prepend the link with
                 *
                 * @type {String}
                 * @default ...
                 */
                ellipsisText: '...',

                /**
                 * The jQuery selector of the extra content element
                 *
                 * @type {String}
                 * @default [data-extra-content]
                 */
                extraSelector: '[data-extra-content]'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.utils' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-readmore]').readmore();
        });
    }
})();

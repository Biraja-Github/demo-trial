//
//  att.input-clear.js
//  AT&T UI Library
//
//  Created by Nelson Fonseca on 18/08/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.inputClear', {
            _super: $.att.base,

            _events: {
                'click.att-inputClear': 'clear'
            },

            _render: function() {
                this.$input = this.$callingElement.parent().find('input');
                this.$input.css({ 'padding-right': '35px'});
                this.$input.on('keyup.att-inputClear', $.proxy(this, '_update'));

                this._update();
            },

            _update: function() {
                var val = this.$input.val();

                this.$callingElement[val.length ? 'show' : 'hide']();
            },

            destroy: function() {
                this.$input.off('.att-inputClear');

                this._trigger('destroy');
                $.removeData(this.callingElement, this.fullname);
                this._off(this._events, 'off');
            },

            clear: function() {
                this.$input
                    .val('')
                    .focus()
                ;

                this.$callingElement.hide();
            },

            options: {}
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-role="clear-input"]').inputClear();
        });
    }
})();

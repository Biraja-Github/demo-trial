//
//  att.popover.js
//  AT&T UI Library
//
//  Created by André Neves on 02/17/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.popover', {
            _super: $.extend(true, {}, $.att.base, $.att.tooltip),

            className: 'att-popover',

            _render: function() {
                this._superMethod('_render');

                if (this.option('trigger') === 'hover') {
                    this.$callingElement.off('blur.att-tooltip');
                }
            },

            _getContent: function() {
                if (!this.option('content')) {
                    return this.$callingElement.attr('title') || '';
                }

                if ($.isFunction(this.option('content'))) {
                    return this.option('content').apply(this.$callingElement);
                } else if ($.type(this.option('content') === 'string')) {
                    return $(this.option('content')).html();
                }

                return '';
            },

            show: function() {
                var self = this;

                $('body')
                    .trigger('att-popover-hide')
                    .on('att-popover-hide.att-popover', this.hide.bind(this));

                this._superMethod('show');

                if (!this.tooltip || this.tooltip.hasClass('att-popover--on')) {
                    return;
                }

                this.tooltip
                    .addClass('att-popover--on')
                    .find('[data-role="close"], [data-close]')
                    .off('click.att-popover')
                    .on('click.att-popover', function(e) {
                        self.hide();

                        e.preventDefault();
                    });

                this.tooltip
                    .attr('tabindex', 0)
                    .focus();

                $('body').on('keydown.' + this.id, function(e) {
                    if (e.keyCode === $.att.base.keys.ESC) {
                        self.hide();

                        self.$callingElement.focus();
                    }
                });

                if (this.option('trigger') === 'hover') {
                    this.tooltip
                        .on('mouseenter', function() {
                            clearTimeout(self.timeout);
                        })
                        .on('mouseleave', this.hide.bind(this));
                }
            },

            hide: function(e, options) {
                var self = this;

                if (!this.tooltip) {
                    return this;
                }

                if (!arguments.length) {
                    options = {};
                } else if (arguments.length === 1) {
                    options = e;
                }

                if ($.isPlainObject(options) && $(options.exclude).is(this.$callingElement)) {
                    return this;
                }

                $('body')
                    .off('att-popover-hide.att-popover')
                    .off('keydown.' + this.id);

                clearTimeout(this.timeout);

                if (this.option('hideDelay') && (this.option('trigger') === 'hover')) {
                    this.timeout = setTimeout(function() {
                        self.tooltip.remove();
                        self.tooltip = null;
                    }, 200);
                } else {
                    this._unbindClickOutside();
                    this.tooltip.remove();
                    this.tooltip = null;
                }

                return this;
            },

            options: $.extend($.extend({}, $.att.tooltip.options), {
                style:     'light',
                content:   null,
                hideDelay: 200
            })
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.tooltip' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-popover]').popover();
        });
    }
})();

window.cenas = 0;

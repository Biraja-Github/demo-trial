//
//  att.base.js
//  AT&T UI Library
//
//  Created by André Neves on 09/09/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    window: false,
    define: false
*/

'use strict';

window.ATT = window.ATT || {
    apps: {}
};

(function() {

    function factory($) {
        $.jqfactory('att.base', {
            _create: function() {
                return this._bootstrap();
            },

            _bootstrap: function() {
                this._initializeOptions();

                return this._checkDependencies();
            },

            _initializeOptions: function() {
                var self = this;

                $.each(this.options || {}, function(key, value) {
                    self._setOption(key, value);
                });
            },

            _checkDependencies: function() {
                var self     = this,
                    goodToGo = true;

                if (!this.dependencies) {
                    return true;
                }

                $.each(this.dependencies.required || [], function(i, params) {
                    if (params && !params.test) {
                        if (console && console.error) {
                            console.error(self.fullname + ' requires "' + params.name + '" to be loaded.' + (params.url ? ' (' + params.url + ')' : ''));
                        }

                        goodToGo = false;
                    }
                });

                $.each(this.dependencies.optional || [], function(i, params) {
                    if (!params.test) {
                        if (console && console.warn) {
                            console.warn(self.fullname + ' works better with "' + params.name + '" loaded.' + (params.url ? ' (' + params.url + ')' : ''));
                        }
                    }
                });

                return goodToGo;
            },

            _setOption: function(name, value) {
                this.option(name, this.$callingElement.data(name) !== undefined ? this.$callingElement.data(name) : (this.option('name') !== undefined ? this.option(name) : value));
            },

            _getRandomId: function(prefix, suffix) {
                return [ prefix, Date.now(), suffix ].join('');
            }
        }, false);

        $.extend($.att.base, {
            'keys': {
                'BACKSPACE':   8,
                'TAB':         9,
                'ENTER':       13,
                'SHIFT':       16,
                'CTRL':        17,
                'ALT':         18,
                'CAPS_LOCK':   20,
                'ESC':         27,
                'SPACE':       32,
                'ARROW_LEFT':  37,
                'ARROW_UP':    38,
                'ARROW_RIGHT': 39,
                'ARROW_DOWN':  40,
                'DELETE':      46,
                '0': 48, '1': 49, '2': 50, '3': 51, '4': 52, '5': 53, '6': 54, '7': 55, '8': 56, '9': 57,
                'A': 65, 'B': 66, 'C': 67, 'D': 68, 'E': 69, 'F': 70, 'G': 71, 'H': 72, 'I': 73, 'J': 74, 'K': 75, 'L': 76, 'M': 77, 'N': 78, 'O': 79, 'P': 80, 'Q': 81, 'R': 82, 'S': 83, 'T': 84, 'U': 85, 'V': 86, 'W': 87, 'X': 88, 'Y': 89, 'Z': 90,
                'F1': 112 ,'F2': 113 ,'F3': 114 ,'F4': 115 ,'F5': 116 ,'F6': 117 ,'F7': 118 ,'F8': 119 ,'F9': 120, 'F10': 121, 'F11': 122, 'F12': 123,
                'DASH': 189
            }
        });

        // From jQueryUI
        // Add :focusable and :tabbable jQuery selectors
        $.extend($.expr[':'], {
            focusable: function(element) {
                var nodeName = element.nodeName.toLowerCase(),
                    tabIndex = $.attr(element, 'tabindex');
                return (/input|select|textarea|button|object/.test(nodeName)
                    ? !element.disabled
                    : 'a' == nodeName || 'area' == nodeName
                        ? element.href || !isNaN(tabIndex)
                        : !isNaN(tabIndex))

                    // the element and all of its ancestors must be visible
                    // the browser may report that the area is hidden
                    && !$(element)['area' == nodeName ? 'parents' : 'closest'](':hidden').length;
            },

            tabbable: function(element) {
                var tabIndex = $.attr(element, 'tabindex');

                return (isNaN(tabIndex) || tabIndex >= 0) && $(element).is(':focusable');
            }
        });
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'jqfactory' ], factory);
    } else {
        factory(window.jQuery);
    }

})();

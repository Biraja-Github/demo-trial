//
//  att.number-selector.js
//  AT&T UI Library
//
//  Created by André Neves on 04/16/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.numberSelector', {
            _super: $.att.base,

            _render: function() {
                var self = this;

                if (this.$callingElement.attr('type').toLowerCase() === 'number') {
                    $.each([ 'min', 'max', 'step' ], function() {
                        if (self.$callingElement.attr(this) !== undefined) {
                            self.option(this, parseInt(self.$callingElement.attr(this), 10));
                        }
                    });
                }

                this.$container = $('<div>', { 'class': 'att-number-selector' });
                this.$upButton = $('<a>', { 'class': 'link att-number-selector__button att-number-selector__up-button', 'href': '#' });
                this.$downButton = $('<a>', { 'class': 'link att-number-selector__button att-number-selector__down-button', 'href': '#' });

                this.$container
                    .append(this.$upButton)
                    .append(this.$downButton);

                this.$callingElement
                    .after(this.$container)
                    .appendTo(this.$container);

                this.value(this.value());

                this._bindEvents();

                if (this.$callingElement.prop('disabled')) {
                    this.disable();
                }
            },

            _bindEvents: function() {
                this.$callingElement.on({
                    'keydown.att-number-selector': $.proxy(this, '_handleKey'),
                    'blur.att-number-selector':    $.proxy(this, '_handleBlur')
                });

                this.$upButton.add(this.$downButton).on({
                    'mousedown.att-number-selector':  $.proxy(this, '_handleButtonMouseDown'),
                    'mouseleave.att-number-selector': $.proxy(this, '_clearTimeout'),
                    'dragstart.att-number-selector':  $.proxy(this, '_clearTimeout'),
                    'click.att-number-selector':      $.proxy(this, '_clearTimeout')
                });
            },

            _handleButtonMouseDown: function(e) {
                var self    = this,
                    $button = $(e.currentTarget);

                if (!this.mouseDownTimeout) {
                    $('body').on('mouseup.att-number-selector', $.proxy(this, '_clearTimeout'));
                }

                window.clearTimeout(this.mouseDownTimeout);

                if ($button.hasClass('att-number-selector__button--disabled')) {
                    return false;
                }

                if ($button.is(this.$upButton)) {
                    this.increment(e.shiftKey);
                } else {
                    this.decrement(e.shiftKey);
                }

                this.mouseDownTimeout = window.setTimeout(function() {
                    self._handleButtonMouseDown(e);
                }, this.mouseDownTimeout ? this.option('stepDelay') : 500);
            },

            _clearTimeout: function(e) {
                if (e) {
                    e.preventDefault();
                }

                window.clearTimeout(this.mouseDownTimeout);
                this.mouseDownTimeout = null;

                $('body').off('mouseup.att-number-selector', $.proxy(this, '_clearTimeout'));
            },

            _handleKey: function(e) {
                var keyCode     = e.which,
                    key         = $.att.base.keys,
                    isNumber    = $.isNumeric(String.fromCharCode(e.which)),
                    isArrowKey  = ($.inArray(keyCode, [ key.ARROW_LEFT, key.ARROW_UP, key.ARROW_RIGHT, key.ARROW_DOWN ]) >= 0),
                    isSelectAll = (keyCode === key.A && (e.metaKey || e.ctrlKey)),
                    isRefresh   = ((keyCode === key.R && e.metaKey) || keyCode === key.F5),
                    isTab       = (keyCode === key.TAB),
                    isBackspace = (keyCode === key.BACKSPACE),
                    isDelete    = (keyCode === key.DELETE),
                    isDash      = (keyCode === key.DASH),
                    prevent     = (!isNumber && !isTab && !isArrowKey && !isSelectAll && !isRefresh && !isBackspace && !isDelete && !isDash);

                if (this.option('min') >= 0 && isDash) {
                    prevent = true;
                }

                // prevent a "change" event with an invalid value
                if (isTab) {
                    this.value(this.value());
                } else if (keyCode === key.ARROW_UP) {
                    this.increment(e.shiftKey);

                    e.preventDefault();
                } else if (keyCode === key.ARROW_DOWN) {
                    this.decrement(e.shiftKey);

                    e.preventDefault();
                } else if (prevent) {
                    e.preventDefault();

                    return false;
                }
            },

            _handleBlur: function() {
                this.value(this.value());
            },

            _sanitizeValue: function(value) {
                return Math.min(this.option('max'), Math.max(this.option('min'), parseInt(value, 10)));
            },

            _updateButtonsState: function() {
                var value = this.value();

                this.$upButton.toggleClass('att-number-selector__button--disabled', value >= this.option('max'));
                this.$downButton.toggleClass('att-number-selector__button--disabled', value <= this.option('min'));
            },

            value: function(newValue) {
                if (newValue !== undefined) {
                    var triggerChange = false;

                    newValue = this._sanitizeValue(newValue);

                    if (parseInt(this.$callingElement.val(), 10) !== newValue) {
                        triggerChange = true;
                    }

                    this.$callingElement.val(newValue);

                    if (triggerChange) {
                        this.$callingElement.trigger('change');
                    }

                    this._updateButtonsState();
                } else {
                    return parseInt(this.$callingElement.val() || 0, 10);
                }
            },

            increment: function(bigStep) {
                var step = this.option('step');

                if (bigStep === true) {
                    step = this.option('bigStep');
                }

                this.value(this.value() + step);
            },

            decrement: function(bigStep) {
                var step = this.option('step');

                if (bigStep === true) {
                    step = this.option('bigStep');
                }

                this.value(this.value() - step);
            },

            enable: function() {
                this.$container.removeClass('att-number-selector--disabled');

                this.$callingElement.prop('disabled', false);
            },

            disable: function() {
                this.$container.addClass('att-number-selector--disabled');

                this.$callingElement.prop('disabled', true);
            },

            destroy: function() {
                this.$callingElement
                    .add(this.$upButton)
                    .add(this.$downButton)
                    .off('.att-number-selector');

                this.$callingElement.insertBefore(this.$container);

                this.$container.remove();

                this._trigger('destroy');
                $.removeData(this.callingElement, this.fullname);
                this._off(this._events, 'off');

                return this;
            },

            options: {
                step:      1,
                bigStep:   10,
                min:       0,
                max:       100,
                stepDelay: 100
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-number-selector]').each(function() {
                var el = $(this);

                if (!$(this).is('input')) {
                    el = $(this).find('input[type=text], input[type="number"]');
                }

                el.numberSelector();
            });
        });
    }
})();

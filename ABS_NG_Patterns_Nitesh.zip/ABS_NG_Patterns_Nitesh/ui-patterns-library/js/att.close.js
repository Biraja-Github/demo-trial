//
//  att.close.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.close', {
            _super: $.att.base,

            _events: {
                'click.att-close': 'close'
            },

            close: function(e) {
                var self   = this,
                    el     = $(e.currentTarget),
                    target = this.option('target') ? $(this.option('target')) : el.parent();

                if (this.option('fade')) {
                    target.fadeOut(this.option('fadeDuration') || 200, function() {
                        if (self.option('remove')) {
                            $(this).remove();
                        }
                    });
                } else {
                    if (self.option('remove')) {
                        target.remove();
                    } else {
                        target.hide();
                    }
                }

                e.preventDefault();
            },

            options: {
                /**
                 * A jQuery selector that return the element to be close/removed
                 *
                 * @type {String}
                 * @default null
                 */
                target: null,

                /**
                 * Controls if the element is faded out before removed
                 *
                 * @type {Boolean}
                 * @default true
                 */
                fade: true,

                /**
                 * The fadeOut animation duration in milliseconds
                 *
                 * @type {Number}
                 * @default 200
                 */
                fadeDuration: 200,

                /**
                 * Whether to remove the element after fading
                 *
                 * @type {Boolean}
                 * @default true
                 */
                remove: true
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-role="close"], [data-close]').close();
        });
    }
})();

//
//  att.slider.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($, Hammer) {
        $.jqfactory('att.slider', {
            _super: $.att.base,

            dependencies: {
                required: [
                    { name: 'att.tooltip', test: $.att.tooltip },
                    { name: 'Hammer.js', test: Hammer, url: 'http://eightmedia.github.io/hammer.js/' },
                    { name: 'jquery.hammer.js', test: $.fn.hammer, url: 'http://eightmedia.github.io/hammer.js/' }
                ]
            },

            currentValues: [],
            _readonlyValues: [],
            maxX: 0,

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                this.container = this._newEl().insertAfter(this.$callingElement);
                this.track     = this._newEl('track');
                this.handles   = this._newEl('handles-container');
                this.handleEls = { editable: [], disabled: [] };

                this.$callingElement.appendTo(this.container).hide();

                this.container
                    .append(this.track)
                    .append(this.handles);

                if (this.option('minLabel') !== null) {
                    this.container.append(this._newEl('label').text(this.option('minLabel')).addClass('att-slider__label--min att-slider__label--' + this.option('labelsPosition')));
                }

                if (this.option('maxLabel') !== null) {
                    this.container.append(this._newEl('label').text(this.option('maxLabel')).addClass('att-slider__label--max att-slider__label--' + this.option('labelsPosition')));
                }

                this.maxX = this.track.outerWidth();

                if (this.option('readonlyValues')) {
                    this._readonlyValues = (String(this.option('readonlyValues'))).replace(/\s/g, '').split(',').splice(0, 2);
                }

                if (this.$callingElement.val()) {
                    this.values(this.$callingElement.val().replace(/\s/g, '').split(',').splice(0, 2));
                } else {
                    this.value(0);
                }
            },

            _reset: function() {
                this.maxX = this.track.outerWidth();

                this._resetRanges();
                this._resetHandles();
            },

            _resetRanges: function() {
                this.editableRange = this._newEl('range');

                this.track.empty();

                if (this._readonlyValues.length) {
                    this.disabledRange = this._newEl('range').addClass('att-slider__range--disabled');

                    if (this._readonlyValues.length > 1) {
                        this.disabledRange.css({
                            left:  this._positionForValue(this._readonlyValues[0]),
                            width: this._positionForValue(this._readonlyValues[1] - this._readonlyValues[0])
                        });
                    } else {
                        this.disabledRange.width(this._positionForValue(this._readonlyValues[0]));
                    }

                    this.track.append(this.disabledRange);
                }

                if (this.currentValues.length > 1) {
                    this.editableRange.css({
                        left:  this._positionForValue(this.currentValues[0]),
                        width: this._positionForValue(this.currentValues[1] - this.currentValues[0])
                    });
                } else {
                    this.editableRange.width(this._positionForValue(this.currentValues[0]));
                }
                this.track.append(this.editableRange);

                if (this.disabledRange) {
                    if (this.currentValues.length > 1) {
                        if (this.currentValues[0] >= this._readonlyValues[0] || this.currentValues[1] <= this._readonlyValues[1]) {
                            this.disabledRange.css('z-index', 0);
                            this.editableRange.css('z-index', 1);
                        } else {
                            this.disabledRange.css('z-index', 1);
                            this.editableRange.css('z-index', 0);
                        }
                    } else {
                        if (this.currentValues[0] >= this._readonlyValues[0]) {
                            this.disabledRange.css('z-index', 1);
                            this.editableRange.css('z-index', 0);
                        } else {
                            this.disabledRange.css('z-index', 0);
                            this.editableRange.css('z-index', 1);
                        }
                    }
                }
            },

            _resetHandles: function() {
                var self       = this,
                    handleDrag = $.proxy(self, '_handleDrag');

                this.handles.empty();

                if (this._readonlyValues.length) {
                    $.each(this._readonlyValues, function(i, value) {
                        var handle = self._newEl('handle');

                        handle
                            .css('left', (value / self.option('max') * 100) + '%')
                            .addClass('att-slider__handle--disabled');

                        self.handles.append(handle);

                        if (self.option('tooltip')) {
                            handle.tooltip({
                                style:     'att-tooltip--textonly',
                                title:     self._formatValue(value),
                                trigger:   'manual',
                                container: 'self'
                            }).tooltip('show');
                        }
                    });
                }

                if (this.currentValues.length) {
                    $.each(this.currentValues, function(i, value) {
                        var handle = self._newEl('handle').css('left', (value / self.option('max') * 100) + '%');

                        self.handles.append(handle);

                        if (self.option('tooltip')) {
                            handle.tooltip({
                                style:     self.option('tooltipStyle'),
                                title:     self._formatValue(value),
                                trigger:   'manual',
                                container: 'self',
                                position:  self.option('labelsPosition') === 'above' ? 'below' : 'above'
                            }).tooltip('show');
                        }

                        handle.data('att-slider-value', value);

                        handle.hammer({ 'correct_for_drag_min_distance': false, 'drag_block_horizontal': true })
                            .on('dragstart drag dragend', handleDrag)
                            .on('mousedown', function() {
                                self._resetTooltipsPosition(handle);
                            });
                    });
                }

                this.handleEls = {
                    editable: this.handles.children(':not(.att-slider__handle--disabled)'),
                    disabled: this.handles.children('.att-slider__handle--disabled')
                };
            },

            _handleDrag: function(e) {
                var handle = $(e.currentTarget);

                if (e.type === 'dragstart') {
                    this.initialDragPosition = handle.position().left;
                    this.otherHandleValue    = $(this.handleEls.editable).not(handle).data('att-slider-value');

                    handle.addClass('dragging');

                    this._resetTooltipsPosition(handle);
                } else if (e.type === 'drag') {
                    var position = Math.max(0, Math.min(this.initialDragPosition + e.gesture.deltaX, this.maxX)),
                        value    = this._valueForPosition(position);

                    handle
                        .css({ left: position })
                        .data('att-slider-value', value);

                    if (this.option('tooltip')) {
                        handle
                            .tooltip('setTitle', this._formatValue(value))
                            .tooltip('update');

                        this._resetTooltipsPosition(handle);
                    }

                    this.currentValues = this.otherHandleValue ? this._sortArray([ value, this.otherHandleValue ]) : [ value ];

                    this.$callingElement.val(this.currentValues.join(', '));

                    this._resetRanges();
                } else if (e.type === 'dragend') {
                    handle.removeClass('dragging');
                }

                return false;
            },

            _formatValue: function(value) {
                if (this.option('valueFormat') && this.option('valueFormat') !== 'none') {
                    if ($.isFunction(this.option('valueFormat'))) {
                        value = this.option('valueFormat')(value);
                    } else if (this.option('valueFormat') === 'round') {
                        value = Math.round(value);
                    }
                }

                return (this.option('valuePrefix') || '') + value + (this.option('valueSuffix') || '');
            },

            _newEl: function(className) {
                return $('<div />', { 'class': 'att-slider' + (className ? '__' + className : '') });
            },

            _positionForValue: function(value) {
                return Math.round(this.track.width() * (value / this.option('max')));
            },

            _valueForPosition: function(position) {
                return position / this.track.width() * this.option('max');
            },

            _sortArray: function(array) {
                return array.sort(function(a, b) {
                    return a - b;
                });
            },

            _resetTooltipsPosition: function(draggingHandle) {
                if (this.currentValues.length === 1 || !this.option('tooltip')) {
                    return;
                }

                var handle1Tooltip = $(this.handleEls.editable).not(draggingHandle).data('attTooltip'),
                    handle2Tooltip = $(draggingHandle).data('attTooltip');

                if (!handle1Tooltip.tooltipElement().size() || !handle2Tooltip.tooltipElement().size()) {
                    return;
                }

                var labelsPosition    = this.option('labelsPosition'),
                    altLabelsPosition = (labelsPosition === 'above' ? 'below' : 'above'),
                    handle1Left       = handle1Tooltip.tooltipElement().offset().left,
                    handle1Width      = handle1Tooltip.tooltipElement().outerWidth(),
                    handle2Left       = handle2Tooltip.tooltipElement().offset().left,
                    handle2Width      = handle2Tooltip.tooltipElement().outerWidth();

                if ((handle1Left >= handle2Left - handle1Width) && (handle1Left <= handle2Left + handle2Width)) {
                    if (handle2Tooltip.position() !== handle1Tooltip.position()) {
                        return;
                    }

                    if (handle2Tooltip.position() === labelsPosition) {
                        handle1Tooltip.setPosition(altLabelsPosition);
                    }

                    if (handle1Tooltip.position() === altLabelsPosition) {
                        handle1Tooltip.setPosition(labelsPosition);
                    }
                } else {
                    if (handle2Tooltip.position() === labelsPosition) {
                        handle2Tooltip.setPosition(altLabelsPosition);
                    }

                    if (handle1Tooltip.position() === labelsPosition) {
                        handle1Tooltip.setPosition(altLabelsPosition);
                    }
                }
            },

            value: function() {
                var args = [].slice.call(arguments);

                if (!args.length) {
                    return this.currentValues.length === 1 ? this.currentValues[0] : this.currentValues;
                }

                this.values([ args[0] ]);

                return this;
            },

            values: function() {
                var args = [].slice.call(arguments),
                    values = args[0];

                if (!args.length) {
                    return this.currentValues;
                }

                for (var i = 0; i < values.length; i++) {
                    values[i] = Math.min(this.option('max'), Math.max(values[i], this.option('min')));
                }

                this.currentValues = this._sortArray(values);

                this._reset();

                return this;
            },

            readonlyValues: function() {
                var args = [].slice.call(arguments),
                    values = args[0];

                if (!args.length) {
                    return this._readonlyValues;
                }

                for (var i = 0; i < values.length; i++) {
                    values[i] = Math.min(this.option('max'), Math.max(values[i], this.option('min')));
                }

                this._readonlyValues = this._sortArray(values);

                this._reset();

                return this;
            },

            refresh: function() {
                this._reset();
            },

            options: {
                /**
                 * The minimum value
                 *
                 * @type {Number}
                 * @default 0
                 */
                min: 0,

                /**
                 * The maximum value
                 *
                 * @type {Number}
                 * @default 100
                 */
                max: 100,

                /**
                 * The text to display at the start of the slider
                 *
                 * @type {String}
                 * @default null
                 */
                minLabel: null,

                /**
                 * The text to display at the end of the slider
                 *
                 * @type {String}
                 * @default null
                 */
                maxLabel: null,

                /**
                 * The position of the min and max labels. They can be:
                 * * 'below': will show the labels below the slider
                 * * 'above': will show the labels above the slider
                 *
                 * @type {String}
                 * @default 'below'
                 */
                labelsPosition: 'below',

                /**
                 * Whether to display a tooltip on the slider handles
                 *
                 * @type {Boolean}
                 * @default true
                 */
                tooltip: true,

                /**
                 * The tooltip style. See att.tooltip for options
                 *
                 * @type {String}
                 * @default 'light'
                 */
                tooltipStyle: 'light',

                /**
                 * The comma separated values to use as 'previously selected' values
                 *
                 * @type {String}
                 * @default ''
                 */
                readonlyValues: '',

                /**
                 * The text to prepend to the handles tooltip value
                 *
                 * @type {String}
                 * @default null
                 */
                valuePrefix: null,

                /**
                 * The text to append to the handles tooltip value
                 *
                 * @type {String}
                 * @default null
                 */
                valueSuffix: null,

                /**
                 * Controls how the handles values are formatted.
                 * If 'round' is passed, the value will be rounded.
                 * If a function is passed, it receives the full unformatted value and it's return value will be used.
                 * If null, the unformatted value will be used.
                 *
                 * @type {String|Function}
                 * @default 'round'
                 */
                valueFormat: 'round'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'hammerjs', 'jquery.hammer', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($, window.Hammer);

        $(function() {
            $('[data-slider]').slider();
        });
    }
})();

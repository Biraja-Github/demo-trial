//
//  att.utils.js
//  AT&T UI Library
//
//  Created by André Neves on 03/02/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    jQuery: false,
    window: false,
    define: false
*/

'use strict';

window.ATT = window.ATT || {};

(function($, ATT) {
    var isMobile = {
            android: function() {
                return navigator.userAgent.match(/Android/i) ? true : false;
            },

            blackBerry: function() {
                return navigator.userAgent.match(/BlackBerry/i) ? true : false;
            },

            ios: function() {
                return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
            },

            windows: function() {
                return navigator.userAgent.match(/IEMobile/i) ? true : false;
            },

            any: function() {
                return (
                    ATT.utils.isMobile.android()    ||
                    ATT.utils.isMobile.blackBerry() ||
                    ATT.utils.isMobile.ios()        ||
                    ATT.utils.isMobile.windows()
                );
            }
        };

    ATT.utils = {
        isMobile: isMobile,

        scrollTo: function(position, options) {
            var el,
                defaults = {
                    duration: 200,
                    easing:   'swing',
                    edge:     'top',
                    offset:   0,
                    callback: null
                },
                type = $.type(position),
                invokedCallback = false;

            if ($.type(options) === 'function') {
                defaults.callback = options;
                options = defaults;
            } else {
                options = $.extend(defaults, options);
            }

            if (type === 'object' || type === 'string') {
                el = $(position);

                if (el.size()) {
                    position = $(el).offset().top;
                }

                if (options.edge === 'bottom') {
                    var viewportHeight = $(window).height(),
                        elHeight       = el.outerHeight();

                    position = (position + elHeight) - viewportHeight;
                }
            }

            $('html, body')
                .stop(true, false)
                .animate({ 'scrollTop': position + options.offset }, options.duration, options.easing, function() {
                    if (options.callback && !invokedCallback) {
                        invokedCallback = true;

                        options.callback.call(this);
                    }
                })

                .on([
                    'scroll.att-scrollTo',
                    'DOMMouseScroll.att-scrollTo',
                    'mousedown.att-scrollTo',
                    'mousewheel.att-scrollTo',
                    'keydown.att-scrollTo'
                ].join(' '), function() {
                    $(this)
                        .stop()
                        .off('.att-scrollTo')
                    ;
                });
        },

        vendorPrefix: function(property, value) {
            var prefixes = [ 'moz', 'webkit', 'o', 'ms' ],
                result   = {};

            $.each(prefixes, function(i, prefix) {
                result['-' + prefix + '-' + property] = value;
            });

            return result;
        },

        relativeOffset: function(el, relativeTo) {
            var elOffset = el.offset(),
                relativeOffset;

            if (!relativeTo) {
                relativeTo = el.offsetParent();
            } else if ($.type(relativeTo) === 'string') {
                relativeTo = $(relativeTo);
            }

            if (!relativeTo || !relativeTo.size()) {
                return elOffset;
            }

            relativeOffset = relativeTo.offset();

            return {
                top: elOffset.top - relativeOffset.top,
                left: elOffset.left - relativeOffset.left
            };
        },

        router: function() {
            var self = this;

            this.hasPushState = ('pushState' in window.history);

            if (this.hasPushState) {
                $(window).on('popstate', function() {
                    if ($.isFunction(self.onPopStateCallback)) {
                        self.onPopStateCallback.call(null, window.location.pathname + window.location.search);
                    }
                });
            } else {
                $(window).on('hashchange', function() {
                    if ($.isFunction(self.onPopStateCallback)) {
                        self.onPopStateCallback.call(null, window.location.hash.replace('#', ''));
                    }
                });
            }

            return {
                navigate: function(URL) {
                    if (self.hasPushState) {
                        window.history.pushState({}, null, URL);
                    } else {
                        window.location.hash = URL;
                    }
                },

                setNavigateBackCallback: function(callback) {
                    self.onPopStateCallback = callback;
                }
            };
        },

        getQueryParameters: function(fromHash) {
            var from,
                pairs,
                results = {},
                hasPushState = ('pushState' in window.history);

            if ($.type(fromHash) === 'string') {
                from = fromHash;
            } else if (fromHash === true || !hasPushState) {
                from = location.hash.substring(2);
            } else {
                from = location.search.substring(1);
            }

            if (from.indexOf('?') !== -1) {
                from = from.substring(from.indexOf('?') + 1);
            }

            pairs = from.split('&');

            $.each(pairs, function(i, pair) {
                pair = decodeURIComponent(pair).split('=');

                var name  = pair[0],
                    value = pair[1] || null;

                results[name] = value;
            });

            return results;
        },

        getQueryParameter: function(name, fromHash) {
            var allParameters = this.getQueryParameters(fromHash);

            return allParameters[name] || null;
        }
    };

    if (typeof define === 'function' && define.amd) {
        define([ 'att.base' ], function() {
            return ATT.utils;
        });
    }

}(jQuery, window.ATT));

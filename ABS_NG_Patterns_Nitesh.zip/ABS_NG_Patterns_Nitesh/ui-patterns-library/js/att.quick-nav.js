//
//  att.quick-nav.js
//  AT&T UI Library
//
//  Created by André Neves on 03/04/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    ATT: false,
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.quickNav', {
            _super: $.att.base,

            dependencies: {
                required: [
                    { name: 'att.utils', test: window.ATT.utils },
                    { name: 'jquery-waypoints', test: $.fn.waypoint }
                ]
            },

            $sections: [],

            _create: function() {
                if (!this._superMethod('_create')) {
                    return;
                }

                /* jshint indent: false */
                this.$container = $([
                    '<section class="att-quick-nav__section att-quick-nav__section--sticky">',
                        '<article class="att-quick-nav__container">',
                            '<div class="att-quick-nav att-quick-nav--sticky att-quick-nav--collapsed">',
                                '<div class="att-quick-nav__controls">',
                                    '<a data-action="up" class="att-quick-nav__control att-quick-nav__control--disabled icon-arrow-up" href="#"></a>',
                                    '<div class="att-quick-nav__items-container">',
                                        '<a class="att-quick-nav__control icon-list" href="#"></a>',
                                        '<ul class="att-quick-nav__items"></ul>',
                                    '</div>',
                                    '<a data-action="down" class="att-quick-nav__control att-quick-nav__control--disabled icon-arrow-down" href="#"></a>',
                                '</div>',
                            '</div>',
                        '</article>',
                    '</section>'
                ].join(''));
                /* jshint indent: 4 */

                this.$sections       = this.$callingElement.find('[data-nav-title]');
                this.$nav            = this.$container.find('.att-quick-nav');
                this.$controls       = this.$container.find('.att-quick-nav__controls');
                this.$itemsContainer = this.$container.find('.att-quick-nav__items');
                this.$upButton       = this.$container.find('[data-action=up]');
                this.$itemsWrapper   = this.$container.find('.att-quick-nav__items-container');
                this.$downButton     = this.$container.find('[data-action=down]');

                this.$container.addClass('att-quick-nav__section--' + this._getSide());

                this.$upButton.on('click', $.proxy(this, '_up'));
                this.$itemsWrapper.on({
                    'mouseenter mouseleave': $.proxy(this, '_toggleList'),
                    'click': function(e) { e.preventDefault(); }
                });
                this.$downButton.on('click', $.proxy(this, '_down'));

                this.update();
                this._resetButtons('down');

                $(window).on('resize.quick-nav', $.proxy(this, '_onResizeWindow'));
            },

            _getSide: function() {
                return this.option('side') === 'right' ? 'right' : 'left';
            },

            _up: function(e) {
                var $button  = $(e.currentTarget),
                    $current = this.$itemsContainer.find('.att-quick-nav__item--current'),
                    $prev    = $current.prev();

                if ($button.hasClass('att-quick-nav__control--disabled')) {
                    return false;
                }

                if (!$current.size()) {
                    $current = this.$itemsContainer.find('.att-quick-nav__item--active:last');
                    $prev    = $current;
                }

                if ($current.size() && $prev.size()) {
                    $prev.trigger('click');
                }

                e.preventDefault();
            },

            _down: function(e) {
                var $button  = $(e.currentTarget),
                    $current = this.$itemsContainer.find('.att-quick-nav__item--current'),
                    $next    = $current.next(':not(.att-quick-nav__item--back-to-top)');

                if ($button.hasClass('att-quick-nav__control--disabled')) {
                    return false;
                }

                if (!$current.size()) {
                    $current = this.$itemsContainer.find('.att-quick-nav__item--active:first');
                    $next    = $current;
                }

                if ($current.size() && $next.size()) {
                    $next.trigger('click');
                }

                e.preventDefault();
            },

            _resetButtons: function(direction) {
                var $items    = this.$itemsContainer.find('.att-quick-nav__item'),
                    $current  = this.$itemsContainer.find('.att-quick-nav__item--current'),
                    canGoUp   = false,
                    canGoDown = false,
                    currentSectionIndex;

                if (!$current.size()) {
                    $current = this.$itemsContainer.find('.att-quick-nav__item--active' + (direction === 'down' ? ':first' : 'last'));
                }

                currentSectionIndex = $items.index($current);

                canGoUp = currentSectionIndex > 0;
                canGoDown = (currentSectionIndex > -1) && (currentSectionIndex < $items.size() - 1);

                this.$upButton.toggleClass('att-quick-nav__control--disabled', !canGoUp);
                this.$downButton.toggleClass('att-quick-nav__control--disabled', !canGoDown);
            },

            _toggleList: function(e) {
                if (this.$nav.hasClass('att-quick-nav--expanded')) {
                    return false;
                }

                this.$nav.toggleClass('att-quick-nav--open', e.type === 'mouseenter');

                e.preventDefault();
            },

            _onResizeWindow: function() {
                $.waypoints('refresh');

                this._checkIfExpanded();
                this._reposition();
            },

            _checkIfExpanded: function() {
                var viewportWidth  = $(window).width(),
                    containerWidth = this.$itemsContainer.width(),
                    gridWidth      = this.option('gridWidth') || 980,
                    availableSpace = (viewportWidth - gridWidth) / 2,
                    isExpanded     = availableSpace >= containerWidth + this.option('sideMargin') + this.option('expandedOffset');

                if (this.$sections.size()) {
                    this.$nav.toggleClass('att-quick-nav--expanded', isExpanded);
                    this.$nav.toggleClass('att-quick-nav--collapsed', !isExpanded);
                }

                this.$container.toggleClass('att-quick-nav__section--squeezed', availableSpace <= 50);
            },

            _reposition: function() {
                var top,
                    minY      = this.option('minY'),
                    topMargin = this.option('topMargin'),
                    unstick   = false;

                if (this.$sections.size()) {
                    if ($.type(topMargin) === 'string' && topMargin.indexOf('%') !== -1) {
                        topMargin = $(window).height() * (parseInt(topMargin, 10) / 100);
                    }

                    top = Math.round(Math.max(minY, topMargin));

                    this.$nav.css('top', top);
                } else {
                    this.$nav.css('bottom', 0);
                }

                unstick = this.option('minY') + this.$itemsContainer.height() > $(window).height();

                this.$container.toggleClass('att-quick-nav__section--sticky', !unstick);
            },

            _addBackToTopButtons: function() {
                var self              = this,
                    hasCSSTransitions = $('html').hasClass('csstransitions'),
                    $buttons;

                this.$backToTopButton = $('<a data-action="top" class="att-quick-nav__control att-quick-nav__back-to-top icon-arrow-up-top" href="#"></a>');
                this.$backToTopExpandedButton = $('<li data-action="top" class="att-quick-nav__item att-quick-nav__item-content att-quick-nav__item--back-to-top" tabindex="-1"><i class="icon-arrow-up-top"></i></li>');

                this.$backToTopExpandedButton.prepend(this.option('backToTopText') + ' ');

                $buttons = this.$backToTopButton.add(this.$backToTopExpandedButton);

                this.$nav.prepend(this.$backToTopButton);
                this.$itemsContainer.append(this.$backToTopExpandedButton);

                $('body').waypoint(function(direction) {
                    if (hasCSSTransitions) {
                        if (self.$container.hasClass('att-quick-nav__section--empty')) {
                            $.fn[direction === 'down' ? 'fadeIn' : 'fadeOut'].apply($buttons, [ 300 ]);
                        } else {
                            $buttons.toggleClass('visible', direction === 'down');
                        }
                    } else {
                        if (self.$container.hasClass('att-quick-nav__section--empty')) {
                            $.fn[direction === 'down' ? 'fadeIn' : 'fadeOut'].apply($buttons, [ 300 ]);
                        } else {
                            self.$backToTopButton.animate({ top: (direction === 'down' ? '-40px' : '0') }, 300);
                            self.$backToTopExpandedButton.animate({ top: (direction === 'down' ? '-50px' : '0') }, 300);
                        }
                    }

                    $buttons.attr('tabindex', direction === 'down' ? 0 : -1);

                }, { offset: -this.option('backToTopOffset') });
            },

            _scrollTo: function($section) {
                var self = this;

                ATT.utils.scrollTo($section || 0, {
                    duration: self.option('scrollDuration'),
                    offset: -self.option('scrollOffset')
                });
            },

            _bindItemEvents: function() {
                var self = this;
                var events = 'click.att-quick-nav, keypress.att-quick-nav';

                this.$itemsContainer.on(events, '.att-quick-nav__item', function(e) {
                    var $item = $(e.currentTarget);
                    var index = self.$itemsContainer.children().index($item);

                    var $section = self.$sections.eq(index);

                    if (e.type === 'keypress') {
                        if (e.keyCode === $.att.base.keys.ENTER) {
                            self._scrollTo($section.size() ? $section : null);
                        }
                    } else {
                        self._scrollTo($section.size() ? $section : null);
                    }
                });
            },

            update: function() {
                var self = this,
                    $items;

                this.$itemsContainer.empty();

                $.each(this.$sections, function(index, section) {
                    var $section = $(section),
                        title    = $section.data('nav-title'),
                        $item;

                    $section.data('att-quick-nav__index', index);

                    $item = $('<li>', {
                        'class': 'att-quick-nav__item',
                        'tabindex': 0
                    });

                    $item.append($('<span>', { 'class': 'att-quick-nav__item-content' }).text(title));

                    if (index === self.$sections.size() - 1) {
                        $item.addClass('att-quick-nav__item--last');
                    }

                    self.$itemsContainer.append($item);
                });

                $items = self.$itemsContainer.children();

                this.$sections

                    // Highlight when the item's top is at the scrollOffset option's value
                    .waypoint(function(direction) {
                        var index = $(this).data('att-quick-nav__index');

                        $items.removeClass('att-quick-nav__item--current');

                        if (direction === 'down') {
                            $items.filter(':lt(' + index + ')').removeClass('att-quick-nav__item--active att-quick-nav__item--current');
                            $items.eq(index).addClass('att-quick-nav__item--active att-quick-nav__item--current');
                        } else {
                            $items.eq(index).addClass('att-quick-nav__item--active');
                        }

                        self._resetButtons(direction);
                    },
                    {
                        offset: self.option('scrollOffset')
                    })

                    // Highlight items whose top is at 80% or less of the viewport's height
                    .waypoint(function(direction) {
                        var index = $(this).data('att-quick-nav__index');

                        if (direction === 'down') {
                            $items.eq(index).addClass('att-quick-nav__item--active');
                        } else {
                            $items.eq(index).removeClass('att-quick-nav__item--active');
                        }

                        self._resetButtons(direction);
                    },
                    {
                        offset: '80%'
                    })

                    // Highlight when the item's bottom is at the scrollOffset option's value
                    .waypoint(function(direction) {
                        var index = $(this).data('att-quick-nav__index');

                        $items.removeClass('att-quick-nav__item--current');

                        if (direction === 'up') {
                            $items.filter(':gt(' + index + ')').removeClass('att-quick-nav__item--current');
                            $items.eq(index).addClass('att-quick-nav__item--active att-quick-nav__item--current');
                        } else {
                            $items.eq(index).removeClass('att-quick-nav__item--active');
                        }

                        self._resetButtons(direction);
                    },
                    {
                        offset: function() {
                            return self.option('scrollOffset') - $(this).height();
                        }
                    });

                this.$sections.last().waypoint(function(direction) {
                    var index = $(this).data('att-quick-nav__index');

                    if (direction === 'down') {
                        $items.eq(index).removeClass('att-quick-nav__item--active att-quick-nav__item--current');
                    }

                    self._resetButtons(direction);
                },
                {
                    offset: function() {
                        return -$(this).height() + self.option('scrollOffset');
                    }
                });

                this._addBackToTopButtons();

                if (!this.$sections.size()) {
                    this.$container.addClass('att-quick-nav__section--empty');

                    this.$controls.remove();
                } else {
                    this.$container.removeClass('att-quick-nav__section--empty');
                }

                $('body').prepend(this.$container);

                this.$container.css('visibility', 'hidden');

                this.$itemsContainer.css('marginTop', '-' + (Math.round(this.$itemsContainer.height() / 2) - 1) + 'px');

                this._bindItemEvents();

                this._checkIfExpanded();
                this._reposition();

                setTimeout(function() {
                    self.$container
                        .css('visibility', 'visible')
                        .fadeOut(0)
                        .fadeIn(200);
                }, 400);
            },

            destroy: function() {
                this._trigger('destroy');
                $.removeData(this.callingElement, this.fullname);
                this._off(this._events, 'off');

                this.$container.remove();

                $(window).off('resize.quick-nav');
            },

            options: {
                side:            'left',
                scrollDuration:  400,
                scrollOffset:    140,
                expandedOffset:  0,
                backToTopOffset: 400,
                sideMargin:      30,
                topMargin:       '30%',
                gridWidth:       980,
                minY:            300,
                backToTopText:   'Back to Top'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.utils' ], factory);
    } else {
        $(function() {
            var $ = window.jQuery;

            factory($);
            $('body').quickNav();
        });
    }
})();

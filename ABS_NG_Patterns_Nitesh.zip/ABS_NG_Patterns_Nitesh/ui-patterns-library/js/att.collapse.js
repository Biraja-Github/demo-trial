//
//  att.close.js
//  AT&T UI Library
//
//  Created by André Neves on 02/14/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {
    function factory($) {
        $.jqfactory('att.collapse', {
            _super: $.att.base,

            animationDirection: null,

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                /**
                 * We need to clear previously bound events
                 * to prevend misfiring on the wrong event
                 */
                this._events = {};
                this._events[this.option('trigger') === 'hover' ? 'mouseenter' : this.option('trigger')] = 'toggle';

                this._updateText();
            },

            _parseTarget: function(selector) {
                var target  = null,
                    context = this.option('skipParent') ? this.$callingElement.parent() : this.$callingElement;

                selector = selector.toLowerCase();

                if (selector.indexOf(':parents(') !== -1) {
                    var matches = selector.match(/(\:parents\(['"]*)([^\'"].*[^\'"])(['"]*\))/i);

                    if (matches && matches.length >= 2) {
                        target = context.parents(matches[2]);
                    }
                } else {
                    switch (selector) {
                        case 'parent':
                            target = context.parent();
                            break;

                        case 'previous':
                            target = context.prev();
                            break;

                        case 'next':
                            target = context.next();
                            break;

                        default:
                            target = $(selector);
                            break;
                    }
                }

                return target;
            },

            _updateText: function() {
                var text,
                    $icon,
                    isCollapsed = this.isCollapsed();

                if (this.$callingElement.data('ariaCollapsedText') || this.$callingElement.data('ariaExpandedText')) {
                    var label = isCollapsed ? this.$callingElement.data('ariaCollapsedText') : this.$callingElement.data('ariaExpandedText');

                    this.$callingElement.attr('aria-label', label);
                }

                if (!this.$callingElement.data('collapsedText') && !this.$callingElement.data('expandedText') && !this.option('addChevron')) {
                    return;
                }

                text = (this.$callingElement.data(isCollapsed ? 'collapsedText' : 'expandedText') || '');

                this.$callingElement.text(text);

                if (this.option('addChevron')) {
                    $icon = $('<i>', { 'class': 'icon-chevron-' + (isCollapsed ? 'down' : 'up') });

                    if (text) {
                        this.$callingElement.text(this.$callingElement.text() + ' ');
                    }

                    this.$callingElement.append($icon);
                }
            },

            isCollapsed: function() {
                var self = this,
                    targetSelector = this.option('target') ? this.option('target') : (this.$callingElement.data('collapse') || 'previous'),
                    target;

                targetSelector = targetSelector || null;

                if (!targetSelector) {
                    return true;
                }

                target = this._parseTarget(targetSelector);

                if (!target || !target.size()) {
                    return true;
                }

                if (!this.animationDirection) {
                    return !target.is(':visible');
                } else {
                    return this.animationDirection === 'up';
                }
            },

            toggle: function(e) {
                var self = this,
                    targetSelector = this.option('target') ? this.option('target') : (this.$callingElement.data('collapse') || 'previous'),
                    target,
                    animation,
                    animate = this.option('animate'),
                    options = { toggle: true };

                targetSelector = targetSelector || null;

                e.preventDefault();
                e.stopPropagation();

                if (!targetSelector) {
                    return;
                }

                target = this._parseTarget(targetSelector);

                if (!target || !target.size()) {
                    return;
                }

                target.trigger('beforeToggle', options);

                if (options.toggle === false) {
                    return false;
                }

                if (animate) {
                    if (target[this.option('animation') + 'Toggle']) {
                        animation = target[this.option('animation') + 'Toggle'];
                    } else {
                        animation = target.slideToggle;
                    }

                    target.stop(true, false);
                }

                this.animationDirection = this.animationDirection ? (this.animationDirection === 'up' ? 'down' : 'up') : 'down';
                self._updateText(self.isCollapsed());

                if (this.option('triggerImmediately') !== false) {
                    self.option('change').call(target, this.animationDirection === 'up');
                }

                if (animate) {
                    animation.call(target, animate ? this.option('duration') : 0, function() {
                        var isVisible = target.is(':visible');

                        if (self.option('className')) {
                            target.toggleClass(self.option('className'), !isVisible);
                        }

                        if (self.option('triggerImmediately') === false && $.isFunction(self.option('change'))) {
                            self.option('change').call(target, !target.is(':visible'));
                        }

                        target.trigger('toggle', !isVisible);
                    });
                } else {

                    if (this.option('className')) {
                        target.toggleClass(this.option('className'));
                    } else {
                        target.toggle();
                    }

                    var isVisible = target.is(':visible');

                    if (this.option('triggerImmediately') === false && $.isFunction(this.option('change'))) {
                        this.option('change').call(target, !isVisible);
                    }

                    target.trigger('toggle', !isVisible);
                }

                return false;
            },

            options: {
                'trigger':            'click',
                'change':             null,
                'animate':            true,
                'duration':           200,
                'animation':          'slide',
                'addChevron':         true,
                'skipParent':         false,
                'triggerImmediately': false,
                'className':          ''
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-collapse]').collapse();
        });
    }
})();

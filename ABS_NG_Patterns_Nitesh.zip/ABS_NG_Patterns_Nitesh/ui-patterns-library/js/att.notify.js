//
//  att.notify.js
//  AT&T UI Library
//
//  Created by André Neves on 04/17/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    $,
    define
*/

'use strict';

(function() {

    function factory($) {
        if ($('body').data('attNotify')) {
            return $('body').data('attNotify');
        }

        $.jqfactory('att.notify', {
            _super: $.att.base,

            api: function() {
                console.log(arguments);
            },

            options: {

            }
        }, false);

        $.notify = function() {
            var args = Array.prototype.slice.call(arguments, 0);

            this.widget = $('body').data('attNotify');

            this.widget.api.apply(this.widget, args);
        };

        $.notify.alert = function(title, message) {
            console.log(this.widget);

            var params = {
                title: title,
                message: message,
                type: this.widget.TYPE_ALERT
            };

            this.widget.api.apply(this.widget, params);
        };
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], function($) {
            factory($);

            $('body').notify();
        });
    } else {
        factory(window.jQuery);

        $(function() {
            $('body').notify();
        });
    }
})();

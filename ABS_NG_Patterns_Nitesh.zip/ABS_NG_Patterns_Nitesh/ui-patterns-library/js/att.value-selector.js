//
//  att.value-selector.js
//  AT&T UI Library
//
//  Created by André Neves on 02/16/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.valueSelector', {
            _super: $.extend(true, {}, $.att.base, $.att.colorSelector),

            dependencies: {
                required: [
                    { name: 'att.radio', test: $.att.radio },
                    { name: 'att.tooltip', test: $.att.tooltip },
                    { name: 'att.popover', test: $.att.popover }
                ]
            },

            className: 'att-value-selector',

            _styleSelectedValueCircle: function($selectedRadio) {
                var value = $selectedRadio.data('value'),
                    unit  = $selectedRadio.data('unit');

                this.$selectedValueCirce
                    .addClass('att-value-selector__selected-circle')
                    .find('.att-value-selector__value, .att-value-selector__unit').remove();

                this.$selectedValueCirce
                    .append($('<span>', { 'class': 'att-value-selector__value' }).text(value))
                    .append($('<span>', { 'class': 'att-value-selector__unit' }).text(unit));

                this.$selectedValueInput.val($selectedRadio.val());
            },

            _initializeRadios: function($el, selectedIndex) {
                var self = this;

                this.$radios = $el.find(':radio');

                this.$radios.each(function() {
                    var el, value, unit, $indicator;

                    $(this).radio({
                        tooltip: self.option('tooltips'),
                        style: 'light'
                    });

                    el = $(this).parent().addClass(self.className + '__item');

                    value = $(this).data('value');
                    unit = $(this).data('unit');

                    $indicator = el.find('.att-radio__indicator');

                    $indicator.append($('<span>', { 'class': 'att-value-selector__value' }).text(value));
                    $indicator.append($('<span>', { 'class': 'att-value-selector__unit' }).text(unit));

                    el.find(':radio').on('change', $.proxy(self, '_onChange'));
                }).eq(selectedIndex).radio('select');
            },

            options: $.extend({}, $.att.colorSelector.options)
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.color-selector' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-value-selector]').valueSelector();
        });
    }
})();

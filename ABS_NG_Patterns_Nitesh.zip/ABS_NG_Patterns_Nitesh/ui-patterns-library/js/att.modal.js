//
//  att.modal.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.modal', {
            _super: $.att.base,

            _render: function() {
                var self = this;

                this.id = this.$callingElement.attr('id');
                this._moveOffscreen = $.proxy(this, '_moveOffscreen');
                this.$overlay = $('<div>', { 'class': 'att-modal__overlay' });

                if (!this.id) {
                    this.id = new Date().getTime();

                    this.$callingElement.attr('id', this.id);
                }

                this.$callingElement
                    .attr({
                        'tabindex': -1,
                        'role': 'dialog',
                        'aria-hidden': true
                    })
                    .addClass('att-modal');

                $('[data-role="show-modal"][data-target="#' + this.id + '"]').on('click.att-modal', this.show.bind(this));

                this.$callingElement
                    .find('[data-role="hide-modal"], [data-role="close"], [data-close]')
                    .add($('[data-role="hide-modal"][data-target="#' + this.id + '"]'))
                    .on('click.att-modal', this.hide.bind(this));

                // Unbind the att.close event (if any)
                this.$callingElement.find('[data-close]').off('click.att-close');

                this.$callingElement.on('keydown.att-modal', this._onKeyPress.bind(this));

                this.$overlay.on('click.att-modal', function() {
                    if (self.option('readOnly') === false) {
                        self.hide();
                    } else {
                        self.$callingElement.focus();
                    }
                });

                $('body').append(this.$overlay);

                if ($('html').hasClass('csstransitions')) {
                    this.$callingElement.on('transitionend', this._moveOffscreen);

                    if (!this.$callingElement.hasClass('att-modal--visible')) {
                        this._moveOffscreen();
                    }
                }
            },

            _moveOffscreen: function() {
                var isVisible = this.$callingElement.hasClass('att-modal--visible');

                this.$callingElement.toggleClass('att-modal--offscreen', !isVisible);
                this.$overlay.toggleClass('att-modal__overlay--offscreen', !isVisible);
            },

            _onKeyPress: function(e) {
                if (e.keyCode !== $.att.base.keys.TAB) {
                    return;
                }

                var tabbables = this.$callingElement.find(':tabbable');
                var first = tabbables.filter(':first').get(0);
                var last  = tabbables.filter(':last').get(0);

                if (e.target === last && !e.shiftKey) {
                    $(first).focus();

                    return false;
                } else if (e.target === first && e.shiftKey) {
                    $(last).focus();

                    return false;
                }
            },

            show: function() {
                if (this.$overlay && this.$overlay.size()) {
                    this.$overlay.addClass('att-modal__overlay--visible');
                }

                this.$callingElement
                    .attr('aria-hidden', false)
                    .addClass('att-modal--visible')
                    .focus();
            },

            hide: function() {
                if (this.$overlay && this.$overlay.size()) {
                    this.$overlay.removeClass('att-modal__overlay--visible');
                }

                this.$callingElement
                    .attr('aria-hidden', true)
                    .removeClass('att-modal--visible');

                return this;
            },

            toggle: function() {
                if (this.$callingElement.hasClass('att-modal--visible')) {
                    return this.hide();
                } else {
                    return this.show();
                }
            },

            options: {
                /**
                 * If the modal is a confirmation and can't be closed without
                 * a button click. Clicking the overlay won't close the modal.
                 *
                 * @type {Boolean}
                 * @default false
                 */
                readOnly: false
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.utils' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-modal]').modal();
        });
    }
})();

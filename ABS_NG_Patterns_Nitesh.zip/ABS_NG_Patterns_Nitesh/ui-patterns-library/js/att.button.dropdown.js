//
//  att.button.dropdown.js
//  AT&T UI Library
//
//  Created by André Neves on 05/02/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false,
    window: false
*/

(function() {
    'use strict';

    function factory($) {
        $.jqfactory('att.buttonDropdown', {
            _super: $.extend(true, {}, $.att.base, $.att.button),

            _create: function() {
                this._superMethod('_create');

                if (!this.$callingElement.is('button') && !this.$callingElement.attr('tabindex')) {
                    this.$callingElement.attr('tabindex', 0);
                }

                this.$callingElement.on({
                    'click.att-button-dropdown':   this._handleDropdownClick.bind(this),
                    'keydown.att-button-dropdown': this._onKeydown.bind(this)
                });

                this.$dropdown = this.$callingElement.find('.dropdown__menu');
                this.$items = this.$dropdown.children();

                this.$dropdown.on('mouseenter.att-button-dropdown', '.dropdown__menu-item', this._onMouseEnterItem.bind(this));
            },

            _onKeydown: function(e) {
                var $active         = this.$items.filter('.dropdown__menu-item--active'),
                    code            = e.keyCode,
                    key             = $.att.base.keys,
                    isNavigationKey = $.inArray(code, [ key.SPACE, key.ARROW_UP, key.ARROW_DOWN ]) !== -1,
                    $item;

                /**
                 * Show the list if the key is UP, Down
                 * or Space and it's not yet visible
                 */
                if (isNavigationKey && !this.$callingElement.hasClass('button--active')) {
                    this.show();

                    return false;
                }

                if (code === key.ENTER || code === key.SPACE) {
                    if (code === key.ENTER && !this.$callingElement.hasClass('button--active')) {
                        return false;
                    }

                    var itemLocation = $active.find('.dropdown__menu-link').attr('href');

                    if (itemLocation && window) {
                        window.location = itemLocation;
                    }

                    this.hide();

                    return false;
                } else if (code === key.ESC) {
                    this.hide();

                    return;
                } else if (code === key.ARROW_UP) {
                    $item = this._getPreviousEnabledItem($active);
                } else if (code === key.ARROW_DOWN) {
                    $item = this._getNextEnabledItem($active);
                } else if (code === key.TAB) {
                    this.$callingElement.removeClass('button--active');

                    return;
                }

                if ($item && $item.size()) {
                    $active.removeClass('dropdown__menu-item--active');
                    $item.addClass('dropdown__menu-item--active');
                }

                if (isNavigationKey) {
                    return false;
                }
            },

            _onMouseEnterItem: function(e) {
                var $item = $(e.currentTarget);

                if ($item.hasClass('dropdown__menu-item--disabled')) {
                    return;
                }

                this.$items.removeClass('dropdown__menu-item--active');
                $item.addClass('dropdown__menu-item--active');
            },

            _bindClickOutside: function() {
                $('html').on('click.att-button-dropdown', this.hide.bind(this));
            },

            _unbindClickOutside: function() {
                $('html').off('click.att-button-dropdown');
            },

            _getPreviousEnabledItem: function($active) {
                var index;
                var $item;

                if (!$active) {
                    $item = this.$items.last();
                } else {
                    index = this.$items.index($active);

                    if (index < 0) {
                        $item = this.$items.filter(':not(.dropdown__menu-item--disabled):last');
                    } else {
                        $item = this.$items.filter(':lt(' + index + '):not(.dropdown__menu-item--disabled):last');

                        if (!$item.size()) {
                            $item = this.$items.filter(':gt(' + index + '):not(.dropdown__menu-item--disabled):last');
                        }
                    }
                }

                return $item;
            },

            _getNextEnabledItem: function($active) {
                var index;
                var $item;

                if (!$active) {
                    $item = this.$items.first();
                } else {
                    index = this.$items.index($active);

                    if (index < 0) {
                        $item = this.$items.filter(':not(.dropdown__menu-item--disabled):first');
                    } else {
                        $item = this.$items.filter(':gt(' + index + '):not(.dropdown__menu-item--disabled):first');

                        if (!$item.size()) {
                            $item = this.$items.filter(':lt(' + index + '):not(.dropdown__menu-item--disabled):first');
                        }
                    }
                }

                return $item;
            },

            _getItemAt: function(index) {
                return this.$items.eq(index);
            },

            _handleDropdownClick: function(e) {
                if (!$(e.target).is('.dropdown__menu-link')) {
                    this.toggle();

                    return false;
                }
            },

            show: function() {
                this.$items.removeClass('dropdown__menu-item--active');

                this.$callingElement
                    .addClass('button--active')
                    .trigger('show-dropdown.att-button-dropdown', this);

                this._bindClickOutside();
            },

            hide: function() {
                this.$callingElement
                    .removeClass('button--active')
                    .trigger('hide-dropdown.att-button-dropdown', this);

                this._unbindClickOutside();
            },

            toggle: function() {
                var isVisible = this.$callingElement.hasClass('button--active');

                if (!isVisible) {
                    $('html').trigger('click.att-button-dropdown');
                }

                this[isVisible ? 'hide' : 'show'].call(this);
            },

            // For backwards compatibility
            toggleDropdown: function(e) {
                this.toggle(e);
            },

            options: {}
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.button' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('.button--dropdown').buttonDropdown();
        });
    }
})();

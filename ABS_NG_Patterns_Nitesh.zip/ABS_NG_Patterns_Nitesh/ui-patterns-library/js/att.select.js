//
//  att.select.js
//  AT&T UI Library
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.select', {
            _super: $.att.base,

            dependencies: {
                required: [ { name: 'Select2', test: $.fn.select2, url: 'http://ivaynberg.github.io/select2/' } ]
            },

            _create: function() {
                var self = this,
                    select2Options,
                    className;

                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                if (!this.$callingElement.is('select')) {
                    if (console && console.error) {
                        console.error('att.select must be called on select elements', this.$callingElement);
                    }

                    return;
                }

                className = function() {
                    var classes = [];
                    var formFieldClasses = self.$callingElement.parents('.form-field:first').attr('class');

                    if (formFieldClasses && formFieldClasses.length) {
                        formFieldClasses = $.map(formFieldClasses.split(' '), function(className) {
                            if (className.indexOf('form-field--') !== -1) {
                                return className;
                            }
                        });
                    }

                    if (self.option('className')) {
                        classes.push(self.option('className'));
                    }

                    if (self.option('showSearch')) {
                        classes.push('show-search');
                    }

                    classes = classes.concat(formFieldClasses);

                    return classes.join(' ');
                };

                if (this.option('width') === 'full') {
                    this.option('width', function() {
                        return '100%';
                    });
                }

                select2Options = {
                    width:             this.option('width'),
                    dropdownCssClass:  className,
                    containerCssClass: className,
                    dropdownContainer: this._getContainer(),
                    dropdownAutoWidth: true
                };

                if (this.option('allowHtml') !== null) {
                    // Override select2's escapeMarkup to return the unescaped markup
                    select2Options.escapeMarkup = function(m) { return m; };
                }

                this.$callingElement
                    .select2(select2Options)
                    .on('select2-open.att-select', function() {
                        var $el = $(this);
                        var select2 = $el.data('select2');
                        var $dropdown = select2.dropdown;

                        if ($dropdown.size()) {
                            setTimeout(function() {
                                $dropdown.find('.select2-input').focus();
                            }, 50);
                        }
                    });

                this._fixChoiceAttributes();

                // If we are using fastclick on the page,
                // add the needsclick class to the ".select2-choice"
                // element and it's children
                if (window.FastClick) {
                    var $choice = this.$callingElement.parent().find('.select2-choice');

                    $choice
                        .addClass('needsclick')
                        .children().each(function() {
                            $(this).children().andSelf().addClass('needsclick');
                        });
                }
            },

            // Removes the onclick="return false" and
            // href="javascript:void(0)" from the .select2-choice
            _fixChoiceAttributes: function() {
                var data = $(this.$callingElement).data();

                if (data && data.select2 && data.select2.container) {
                    data.select2.container.find('.select2-choice')
                        .attr('href', '#')
                        .removeAttr('onclick');
                }
            },

            _getContainer: function() {
                var self      = this,
                    container = null,
                    option    = this.option('container');

                if ($.type(option) === 'function') {
                    return option;
                }

                if (option) {
                    if (option === 'parent') {
                        container = self.$callingElement.parent();
                    } else if (option.indexOf('parent:') === 0) {
                        return $(this.containerSelector).parents(self.option('container').replace('parent:', ''));
                    } else {
                        container = $(option);
                    }
                }

                return container;
            },

            destroy: function() {
                this.$callingElement
                    .select2('destroy')
                    .off('.att-select');

                this._superMethod('destroy');
            },

            options: {
                /**
                 * Extra class to add to the select2 element.
                 * Auto adds form-field--error, form-field--warning
                 * and form-field--success to allow stying
                 *
                 * @type {String}
                 * @default null
                 */
                className: null,

                /**
                 * Controls the width style attribute of the Select2 container div. The following values are supported:
                 * * null:    No width attribute will be set;
                 * * full:    100%;
                 * * element: Uses javascript to calculate the width of the source element;
                 * * copy:    Copies the value of the width style attribute set on the source element;
                 * * resolve: First attempts to copy than falls back on element.
                 * Can also be a function that will be evaluated.
                 *
                 * @type {null|String|Function}
                 * @default full
                 */
                width: 'full',

                /**
                 * The dropdown container element. This is useful when using the select inside modals.
                 * The following values are supported:
                 * * null:              The container will be "body"
                 * * parent:            The container will be the select element's parent
                 * * parent:{selector}: Will be the result of $(select2element).parents({selector});
                 *
                 * @type {null|String|Function}
                 * @default null
                 */
                container: null,

                /**
                 * Whether to show a text input inside the dropdown
                 * that allows searching it's values. Searching is still
                 * possible even if no input is shown.
                 *
                 * @type {Boolean}
                 * @default false
                 */
                showSearch: false,

                /**
                 * Whether to allow the dropdown values to be HTML.
                 * Note: the select options HTML will need to be encoded
                 * so the browser doen't try to render it.
                 * Potentially dangerous. Use with caution.
                 *
                 * @type {Boolean}
                 * @default false
                 */
                allowHtml: false
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'select2', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-select]').each(function() {
                var el = $(this);

                if (!$(this).is('select')) {
                    el = $(this).find('select');
                }

                if (el.size()) {
                    el.select();
                }
            });
        });
    }
})();

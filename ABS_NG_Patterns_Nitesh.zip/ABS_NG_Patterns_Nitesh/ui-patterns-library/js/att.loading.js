//
//  att.button.js
//  AT&T UI Library
//
//  Created by André Neves on 05/02/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.loading', {
            _super: $.att.base,

            _render: function() {

                var ie = $('html').hasClass('lt-ie9');

                var circle;

                var inset = $('<div>', { 'class': 'att-loading-inset'})
                        .append($('<div>', { 'class': 'att-loading-inset__percentage'}));

                if (ie) {
                    this.ieRender();
                }
                else {

                    var circleFull = $('<div>', { 'class': 'att-loading-circle__mask att-loading-circle__full' })
                        .append($('<div>', { 'class' : 'att-loading-circle__fill'}));

                    var circleHalf = $('<div>', { 'class': 'att-loading-circle__mask att-loading-circle__half' })
                        .append($('<div>', { 'class' : 'att-loading-circle__fill'}))
                        .append($('<div>', { 'class' : 'att-loading-circle__fill att-loading-circle__fix'}));

                    circle =  $('<div>', { 'class': 'att-loading-circle'})
                        .append(circleFull).append(circleHalf);

                    if (this.option('background-color') !== null) {
                        inset.css('background-color', this.option('background-color'));
                    }
                }

                this.$callingElement
                        .addClass('att-loading-count')
                        .append(circle)
                        .append(inset);
            },

            reset: function() {
                this.value(0);
            },

            decrement: function() {
                this.value(this.value() - this.option('step'));
            },

            increment: function() {
                this.value(this.value() + this.option('step'));
            },

            value: function(newValue) {

                if (newValue !== undefined) {
                    newValue = Math.min(100, Math.max(0, newValue));

                    this.$callingElement.attr('data-progress', newValue);

                } else {
                    return parseInt(this.$callingElement.attr('data-progress'), 10);
                }

                if ($('html').hasClass('lt-ie9')) {
                    this.ieRender(newValue);
                }


            },

            ieRender: function(newValue) {

                var $progress = newValue ? newValue : this.$callingElement.data('progress');

                var shiftX = 0,
                    shiftY = $progress * 36;

                if (this.$callingElement.is('.att-loading--dark, .att-loading--blue, .att-loading--white')) {
                    if (this.$callingElement.hasClass('att-loading--blue')) {
                        shiftX = -36;
                    }
                    else if (this.$callingElement.hasClass('att-loading--white')) {
                        shiftX = -72;
                    }
                }

                this.$callingElement.find('att-loading-inset__percentage').innerHTML += $progress;

                this.$callingElement.css({
                    'background-position-x' : shiftX,
                    'background-position-y' : -shiftY
                });
            },

            options: {
                /**
                 * The loading count background color
                 *
                 * @type {string}
                 * @default null
                 */
                'background-color': null,

                'step': 1
            }
        }, false);

        $.extend($.att.loading, {
            create: function() {
                var $el = $('<div>', {
                        'class': 'loading'
                    }).append($('<div>', {
                        'class': 'loading__inside'
                    }));

                return $el;
            }
        });
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-loading][data-progress]').loading();
        });
    }
})();

//
//  att.tree-view.js
//  AT&T UI Library
//
//  Created by Nelson Fonseca on 05/11/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.treeView', {
            _super: $.att.base,

            _events: {
            },

            _render: function() {
                this.$callingElement.find('.tv__toggle').remove();

                this.$callingElement.find('.tv__row').each(function() {
                    var $row = $(this);
                    var $icon;

                    if ($row.find('> .tree-view').size()) {
                        $icon = $('<a>', { 'class': 'tv__toggle', 'href': '#' });
                    } else {
                        $row.addClass('tv__row--leaf');

                        $icon = $('<span>', { 'class': 'tv__toggle' });
                    }

                    $row.find('> .tv__row-header').prepend($icon);
                });

                $('.tree-view').each(function() {
                    var depth = $(this).parents('.tree-view').length;

                    $(this).attr('data-depth', depth + 1);
                });

                this.$callingElement.on('click', '.tv__row:not(.tv__row--leaf) > .tv__row-header > .tv__toggle', this.toggle.bind(this));
            },

            toggle: function(e) {
                var $toggle = $(e.currentTarget);

                $toggle.parents('.tv__row:first').toggleClass('tv__row--expanded');
            },

            destroy: function() {

            },

            options: {}
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-tree-view]').treeView();
        });
    }
})();

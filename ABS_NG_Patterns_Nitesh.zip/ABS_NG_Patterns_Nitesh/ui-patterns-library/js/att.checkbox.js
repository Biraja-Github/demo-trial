//
//  att.checkbox.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.checkbox', {
            _super: $.att.base,

            checked: false,
            disabled: false,

            $label: null,

            _render: function() {
                this.$container = $('<div>', { 'class': 'att-checkbox' });

                this.$container.append($('<div>', {
                    'class': 'att-checkbox__indicator',
                    'aria-hidden': true
                }));

                this.$callingElement
                    .after(this.$container)
                    .appendTo(this.$container);

                this.$element = this.$container;

                this._bindEvents();
                this._bindLabelEvent();

                if (this.option('checked')) {
                    this.$callingElement
                        .prop('checked', true)
                        .trigger('change');
                } else {
                    this.update();
                }
            },

            _bindEvents: function() {
                this.$container
                    .off('.att-checkbox')
                    .on('click.att-checkbox', this.toggle.bind(this));

                this.$callingElement
                    .off('.att-checkbox')
                    .on({
                        'click.att-checkbox': this.toggle.bind(this),
                        'change.att-checkbox': this.update.bind(this),
                        'focus.att-checkbox': this._updateFocus.bind(this),
                        'blur.att-checkbox': this._updateFocus.bind(this)
                    });
            },

            _bindLabelEvent: function() {
                if (this.$container.parent().is('label')) {
                    this.$label = this.$container.parent();

                    // unbind from the container, as the label
                    // will pick up the event
                    this.$container.off('click.att-checkbox');
                    this.$label.addClass('form-field__label--with-input');
                } else if (this.$callingElement.attr('id')) {
                    this.$label = $('label[for=' + this.$callingElement.attr('id') + ']');
                }

                if (this.$label && this.$label.size()) {
                    this.$label.on('click', this._onClickLabel.bind(this));
                }
            },

            _onClickLabel: function(e) {
                this.toggle();

                this.$callingElement.focus();

                e.preventDefault();
            },

            _updateFocus: function() {
                var self = this;

                setTimeout(function() {
                    var isFocused = self.$callingElement.is(':focus');

                    self.$container.toggleClass('att-checkbox--focused', isFocused);
                }, 10);
            },

            update: function(e) {
                var self = this;

                setTimeout(function() {
                    // If we have an event, then we know the state has changed
                    // and we can safely assume the state is no longer indeterminate
                    if (e) {
                        self.setIndeterminate(false);
                    }

                    self.checked = self.$callingElement.prop('checked');
                    self.disabled = self.$callingElement.prop('disabled');

                    self.$container.toggleClass('att-checkbox--on', self.checked);

                    self[self.disabled ? 'disable' : 'enable']();
                }, 10);
            },

            switchOn: function() {
                this.$callingElement
                    .prop('checked', true)
                    .trigger('change');

                this.$container.addClass('att-checkbox--on');
                this.checked = true;
            },

            switchOff: function() {
                this.$callingElement
                    .prop('checked', false)
                    .trigger('change');

                this.$container.removeClass('att-checkbox--on');
                this.checked = false;
            },

            toggle: function(e) {
                if ($.type(e) === 'boolean') {
                    if (e) {
                        this.switchOn();
                    } else {
                        this.switchOff();
                    }
                } else {
                    if (e) {
                        e.stopPropagation();

                        this.$callingElement.focus();
                    }

                    if (this.disabled) {
                        return;
                    }

                    this[this.checked ? 'switchOff' : 'switchOn']();
                }
            },

            enable: function() {
                this.disabled = false;

                this.$callingElement.prop('disabled', false);

                this.$container.removeClass('att-checkbox--disabled');

                if (this.$label && this.$label.size()) {
                    this.$label.removeClass('form-field__label--disabled');
                }
            },

            disable: function() {
                this.disabled = true;

                this.$callingElement.prop('disabled', true);

                this.$container.addClass('att-checkbox--disabled');

                if (this.$label && this.$label.size()) {
                    this.$label.addClass('form-field__label--disabled');
                }
            },

            isChecked: function() {
                return this.$callingElement.prop('checked');
            },

            isIndeterminate: function() {
                return this.$callingElement.get(0).indeterminate;
            },

            setIndeterminate: function(state) {
                var isOn = state ? true : false;

                this.$callingElement.get(0).indeterminate = isOn;

                this.$container.toggleClass('att-checkbox--indeterminate', isOn);
            },

            options: {
                /**
                 * Force initial state of the checkbox regardless of the element's current state.
                 * If null, the element's current state will be used.
                 *
                 * @type {Boolean}
                 * @default null
                 */
                checked: null
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-checkbox]').each(function() {
                var el = $(this);

                if (!$(this).is(':checkbox')) {
                    el = $(this).find(':checkbox');
                }

                el.checkbox();
            });
        });
    }
})();

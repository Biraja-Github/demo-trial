//
//  att.tooltip.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    ATT: false,
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.tooltip', {
            _super: $.att.base,

            title: null,
            timeout: null,
            tooltip: null,

            className: 'att-tooltip',

            forcedPosition: null,
            count: 0,

            _render: function() {
                this.title = this.$callingElement.attr('title');

                this.$callingElement.attr('title', '');

                if (!this.$callingElement.attr('aria-label')) {
                    this.$callingElement.attr('aria-label', this.title);
                }

                if (this.option('trigger') === 'hover') {
                    this.$callingElement.on({
                        'mouseenter.att-tooltip focus.att-tooltip': this.show.bind(this),
                        'mouseleave.att-tooltip blur.att-tooltip': this.hide.bind(this)
                    });
                }

                if (this.option('trigger') === 'click') {
                    this.$callingElement.on('click', this.toggle.bind(this));
                }

                $(window).on('resize', this.hide.bind(this));
            },

            _reset: function() {
                if (!this.tooltip) {
                    return;
                }

                this._resetPosition();
                this._resetStyleClass();

                this.forcedPosition = null;
            },

            _resetPosition: function() {
                this.tooltip
                    .css(this._getPosition())
                    .addClass(this._getStyleClass());
            },

            _getPosition: function(desiredPosition) {
                var elPosition = {
                        top: 0,
                        left: 0
                    },
                    position = {};

                if (!this.tooltip) {
                    return;
                }

                if (this.option('container') === 'body') {
                    elPosition = this.$callingElement.offset();
                } else if (this.option('container')) {
                    elPosition = ATT.utils.relativeOffset(this.$callingElement, this.getContainer());
                }

                this.count++;

                desiredPosition = desiredPosition || this.option('position');

                switch (desiredPosition) {
                    case 'above':
                        position.top = elPosition.top - this.tooltip.outerHeight();
                        position.left = elPosition.left - this.tooltip.outerWidth() / 2 + this.$callingElement.outerWidth() / 2;
                        break;

                    case 'below':
                        position.top = elPosition.top + this.$callingElement.outerHeight();
                        position.left = elPosition.left - this.tooltip.outerWidth() / 2 + this.$callingElement.outerWidth() / 2;
                        break;

                    case 'left':
                        position.top = elPosition.top + this.$callingElement.outerHeight() / 2 - this.tooltip.outerHeight() / 2;
                        position.left = elPosition.left - this.tooltip.outerWidth();
                        break;

                    case 'right':
                        position.top = elPosition.top + this.$callingElement.outerHeight() / 2 - this.tooltip.outerHeight() / 2;
                        position.left = elPosition.left + this.$callingElement.outerWidth();
                        break;
                }

                var tooltipWidth = this.tooltip.outerWidth();

                if (this.option('offsetX') !== 0) {

                    var offset = this.option('offsetX'),
                        maxOffset = tooltipWidth / 2 - 28;

                    if (offset > 0 && offset > maxOffset) {
                        offset = maxOffset;
                    } else if (offset < 0 && offset < -maxOffset) {
                        offset = -maxOffset;
                    }

                    position.left += parseFloat(offset);
                    this._moveAfter(tooltipWidth / 2 - offset);
                }

                position.top += this.option('offsetY') ? parseFloat(this.option('offsetY')) : 0;

                if (this.tooltip.hasClass('att-tooltip--fixed')) {
                    position.top = position.top - $(window).scrollTop();
                }

                var windowHeight = $(window).outerHeight();
                var windowWidth = $(window).outerWidth();
                var tooltipHeight = this.tooltip.outerHeight();
                var scrollTop = $(window).scrollTop();
                var tooltipTop = position.top - scrollTop;

                if (this.option('autoPosition') === true && (tooltipHeight < windowHeight) && (tooltipWidth < windowWidth)) {
                    if (tooltipTop < 0 && (desiredPosition === 'above' || this.forcedPosition === 'above')) {
                        if (this.forcedPosition === 'above') {
                            this.forcedPosition = 'left';
                        } else {
                            this.forcedPosition = 'below';
                        }
                    } else if ((tooltipTop + tooltipHeight) > windowHeight && (desiredPosition === 'below' || this.forcedPosition === 'below')) {
                        if (this.forcedPosition === 'below') {
                            this.forcedPosition = 'left';
                        } else {
                            this.forcedPosition = 'above';
                        }
                    } else if (position.left < 0 && (desiredPosition === 'left' || this.forcedPosition === 'left')) {
                        if (this.forcedPosition === 'left') {
                            this.forcedPosition = 'right';
                        } else {
                            this.forcedPosition = 'left';
                        }
                    } else if ((position.left + tooltipWidth) > windowWidth && (desiredPosition === 'right' || this.forcedPosition === 'right')) {
                        if (this.forcedPosition === 'right') {
                            this.forcedPosition = 'left';
                        } else {
                            this.forcedPosition = 'right';
                        }
                    }

                    if (position.left < 0 && (this.forcedPosition === 'above' || this.forcedPosition === 'below' || desiredPosition === 'above')) {
                        this.forcedPosition = 'right';
                    } else if ((position.left + tooltipWidth) > windowWidth && (this.forcedPosition === 'above' || this.forcedPosition === 'below' || desiredPosition === 'above')) {
                        this.forcedPosition = 'left';
                    }

                    if (desiredPosition && this.forcedPosition && (desiredPosition !== this.forcedPosition)) {
                        return this._getPosition(this.forcedPosition);
                    } else {
                        this.forcedPosition = desiredPosition;
                    }
                }

                return {
                    top: Math.round(position.top),
                    left: Math.round(position.left)
                };
            },

            _moveAfter: function(elOffset) {
                var styleElement = document.createElement('style');

                styleElement.type = 'text/css';

                if ($('html').hasClass('lt-ie9')) {

                    if (styleElement.styleSheet) {
                        styleElement.styleSheet.cssText = '.att-tooltip.' + this.option('className') + '::after { left: ' + elOffset + 'px; } .att-tooltip.' + this.option('className') + '::before { display: none; }';
                    } else {
                        styleElement.appendChild(document.createTextNode('.att-tooltip.' + this.option('className') + '::after { left: ' + elOffset + 'px; } .att-tooltip.' + this.option('className') + '::before { display: none; }'));
                    }

                    document.getElementsByTagName('head')[0].appendChild(styleElement);

                } else {
                    document.getElementsByTagName('head')[0].appendChild(styleElement);

                    var sheet = styleElement.sheet;

                    sheet.insertRule('.att-tooltip.' + this.option('className') + '::after { left: ' + elOffset + 'px; }', 0);
                    sheet.insertRule('.att-tooltip.' + this.option('className') + '::before { display: none; }', 0);
                }
            },

            _getContent: function() {
                return (this.title !== undefined ? String(this.title) : null) || (this.option('title') !== undefined ? String(this.option('title')) : null) || '';
            },

            _resetStyleClass: function() {
                this.tooltip
                    .removeClass('att-tooltip--above att-tooltip--below att-tooltip--right att-tooltip--left')
                    .addClass(this._getStyleClass());
            },

            _getStyleClass: function() {
                var styleName = '';

                if (this.option('style')) {
                    styleName = this.option('style').replace('att-tooltip--', '');
                }

                return [ 'att-tooltip--' + styleName,
                    'att-tooltip--' + (this.forcedPosition ? this.forcedPosition : this.option('position'))
                ].join(' ');
            },

            _bindClickOutside: function() {
                $('html').on('click.att-tooltip', this.hide.bind(this));

                this.tooltip.on('click', function(e) {
                    e.stopPropagation();
                });
            },

            _unbindClickOutside: function() {
                $('html').off('.att-tooltip');
            },

            show: function() {
                var self = this;
                var id = this._getRandomId('att-tooltip-');

                this.id = id;

                if (this.option('disabled')) {
                    return;
                }

                if (this.tooltip) {
                    this._reset();

                    return this;
                }

                clearTimeout(this.timeout);

                this.tooltip = $('<div>', {
                    'id': id,
                    'class': 'att-tooltip ' + this.className + (this.option('className') ? ' ' + this.option('className') : '')
                })
                    .html(this._getContent())
                    .appendTo(this.getContainer());

                this.$callingElement.attr('aria-describedby', id);

                if ($.isFunction(self.option('beforeOpen'))) {
                    self.option('beforeOpen').call(self, self.$callingElement, self.tooltip);
                }

                this._reset();

                if (this.option('trigger') === 'hover') {
                    $('html')
                        .trigger('att-tooltip-hide', { exclude: this.$callingElement })
                        .on('att-tooltip-hide.att-tooltip', this.hide.bind(this));
                }

                if (this.option('delay') && (this.option('trigger') === 'hover')) {
                    this.timeout = setTimeout(function() {
                        self.tooltip.addClass('att-tooltip--on');

                        if ($.isFunction(self.option('onOpen'))) {
                            self.option('onOpen').call(self, self.$callingElement, self.tooltip);
                        }
                    }, self.option('delay'));
                } else {
                    this.tooltip.addClass('att-tooltip--on');

                    if (this.option('trigger') !== 'hover') {
                        this._bindClickOutside();
                    }

                    if ($.isFunction(this.option('onOpen'))) {
                        this.option('onOpen').call(this, this.$callingElement, this.tooltip);
                    }
                }

                return this;
            },

            hide: function() {
                var self = this;

                if (!this.tooltip) {
                    return this;
                }

                clearTimeout(this.timeout);

                this.$callingElement.removeAttr('aria-describedby');

                if ($.isFunction(self.option('beforeClose'))) {
                    self.option('beforeClose').call(self, self.$callingElement);
                }

                if (this.option('trigger') === 'hover') {
                    $('html').off('att-tooltip-hide.att-tooltip');
                }

                if (this.option('delay') && (this.option('trigger') === 'hover')) {
                    this.timeout = setTimeout(function() {
                        self.tooltip.remove();
                        self.tooltip = null;

                        if ($.isFunction(self.option('onClose'))) {
                            self.option('onClose').call(self, self.$callingElement);
                        }
                    }, this.option('delay'));
                } else {
                    if (this.option('trigger') !== 'hover') {
                        this._unbindClickOutside();
                    }

                    this.tooltip.remove();
                    this.tooltip = null;

                    if ($.isFunction(self.option('onClose'))) {
                        self.option('onClose').call(self, self.$callingElement);
                    }
                }

                return this;
            },

            toggle: function(e) {
                if ($.type(e) === 'boolean') {
                    if (e) {
                        return this.show();
                    } else {
                        return this.hide();
                    }
                }

                if (e && e.type === 'click' && this.$callingElement.is('a')) {
                    e.preventDefault();
                }

                e.stopPropagation();

                if (this.option('disabled')) {
                    return;
                }

                if (this.tooltip) {
                    return this.hide();
                } else {
                    return this.show();
                }

                return false;
            },

            update: function() {
                this._reset();

                return this;
            },

            getTitle: function() {
                return this.title;
            },

            setTitle: function(title) {
                this.title = title;

                if (this.tooltip) {
                    this.tooltip.html(this.title);
                }

                return this;
            },

            position: function() {
                return this.option('position');
            },

            setPosition: function(position) {
                this.option('position', position);

                if (this.tooltip) {
                    this.hide()
                        .show();
                }

                return this;
            },

            getContainer: function() {
                if ($.isFunction(this.option('container'))) {
                    return this.option('container').call(this, this.$callingElement);
                }

                if (this.option('container') === 'parent') {
                    return this.$callingElement.parent();
                }

                return $(this.option('container'));
            },

            tooltipElement: function() {
                return $(this.tooltip);
            },

            removeAll: function(selector) {
                $(selector || 'body').find('.' + this.className).remove();
            },

            destroy: function() {
                this.$callingElement.attr('title', this.title);

                this._trigger('destroy');
                $.removeData(this.callingElement, this.fullname);
                this._off(this._events, 'off');

                if (this.option('trigger') === 'hover') {
                    this.$callingElement.off('mouseente.att-tooltipr', this.show.bind(this));
                    this.$callingElement.off('mouseleave.att-tooltip', this.hide.bind(this));
                } else if (this.option('trigger') !== 'manual') {
                    this.$callingElement.off('click', this.toggle.bind(this));
                }

                $(window).off('resize', this.hide.bind(this));
            },

            options: {
                /**
                 * The time in milliseconds before showing the tooltip
                 *
                 * @type {Number}
                 * @default 0
                 */
                delay: 0,

                /**
                 * The tooltip style. The available ones are:
                 * * light:   white background
                 * * dark:    dark gray background
                 *
                 * @type {Number}
                 * @default 'dark'
                 */
                style: 'dark',

                /**
                 * The tooltip position relative to the element. Possible values:
                 * * above
                 * * below
                 * * left
                 * * right
                 *
                 * @type {String}
                 * @default 'above'
                 */
                position: 'above',

                /**
                 * Whether or not to find the best position based on
                 * the viewport dimensions
                 *
                 * @type {Boolean}
                 * @default true
                 */
                autoPosition: true,

                /**
                 * A jQuery selector that will be the tooltip's container
                 *
                 * @type {String}
                 * @default 'body'
                 */
                container: 'body',

                /**
                 * The amount to offset the tooltip position in the horizontal axis
                 *
                 * @type {Number}
                 * @default 0
                 */
                offsetX: 0,

                /**
                 * The amount to offset the tooltip position in the vertical axis
                 *
                 * @type {Number}
                 * @default 0
                 */
                offsetY: 0,

                /**
                 * The event that triggers the tooltip. Can be any DOM/jQuery event
                 *
                 * @type {String}
                 * @default 'hover'
                 */
                trigger: 'hover',

                /**
                 * Extra css classes to add to the tooltip
                 *
                 * @type {String}
                 * @default ''
                 */
                className: '',

                /**
                 * Function to call when before the tooltip is shown
                 *
                 * @type {function}
                 */
                beforeOpen: null,

                /**
                 * Function to call when the tooltip is shown
                 *
                 * @type {function}
                 */
                onOpen: null,

                /**
                 * Function to call when before the tooltip is hidden
                 *
                 * @type {function}
                 */
                beforeClose: null,

                /**
                 * Function to call when the tooltip is hidden
                 *
                 * @type {Function}
                 */
                onClose: null
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.utils' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-tooltip]').each(function() {
                var el = $(this);

                if (!$(this).attr('title')) {
                    el = $(this).find('[title]');
                }

                el.tooltip();
            });
        });
    }
})();

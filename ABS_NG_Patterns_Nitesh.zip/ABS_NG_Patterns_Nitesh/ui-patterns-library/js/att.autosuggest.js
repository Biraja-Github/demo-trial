//
//  att.autosuggest.js
//  AT&T UI Library
//
//  Created by André Neves on 06/09/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($, Handlebars) {
        $.jqfactory('att.autosuggest', {
            _super: $.att.base,

            dependencies: {
                required: [ { name: 'Twitter Typeahead', test: $.fn.typeahead, url: 'https://github.com/twitter/typeahead.js' } ],
                optional: [ { name: 'Handlebarsjs', test: Handlebars, url: 'http://handlebarsjs.com' } ]
            },

            _create: function() {
                var self     = this,
                    el       = this.$callingElement,
                    params   = [],
                    defaults = {},
                    urls,
                    template;

                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                urls = (this.option('url') || '').replace(' ', '').split(',');
                template = $(this.option('template'));

                if (Handlebars) {
                    defaults.template = Handlebars.compile($(template).size() ? template.html() : '<div class="att-autosuggest-result">{{value}}</div>');
                    defaults.engine = Handlebars;
                }

                $.each(urls, function(i, url) {
                    params.push($.extend({}, defaults, {
                        remote: { url: url + '&' + self.option('queryParam') + '=%QUERY' },
                        footer: (self.option('seeMoreUrl') && i === urls.length -1) ? '<div class="att-autosuggest-footer"><a href="' + self.option('seeMoreUrl') + '" class="att-autosuggest-seemore">' + self.option('seeMoreText') + '</a></div>' : null
                    }));
                });

                el.typeahead(params)
                    .on('typeahead:opened', function() {
                        self.container.addClass('att-autosuggest-open');
                    })
                    .on('typeahead:closed', function() {
                        self.container.removeClass('att-autosuggest-open');
                    });

                this.container = el.parents('.twitter-typeahead:first').addClass('att-autosuggest');

                $(document).on('click', '.att-autosuggest-seemore', function() {
                    var el    = $(this),
                        query = el.parents('.att-autosuggest').find('.tt-query').val();

                    el.attr('href', window.unescape(el.attr('href')).replace('%QUERY', query));
                });
            },

            options: {
                /**
                 * The comma separated URLs used to make the ajax calls that should return the search results.
                 * The dropdown will list the results grouped by URL.
                 * See the "remote" section of Twitter Typeahed's documentation for more info.
                 *
                 * @type {String}
                 * @default null
                 */
                url: null,

                /**
                 * The query param to append to the URLs.
                 * This is the parameter that the server will use the find the results.
                 *
                 * @type {String}
                 * @default 'q'
                 */
                queryParam: 'q',

                /**
                 * A jQuery selector used to find an element whose HTML will be used as an
                 * Handlebars template. If null, the "value" property of the search results
                 * will be used.
                 *
                 * @type {String}
                 * @default null
                 */
                template: null,

                /**
                 * The URL for the link in the dropdown's footer.
                 * The '%QUERY' text will be replaced by the searching string.
                 * If null, the footer will be hidden.
                 *
                 * @type {String}
                 * @default null
                 */
                seeMoreUrl: null,

                /**
                 * The text to display in the dropdown footer
                 *
                 * @type {String}
                 * @default 'Sell all results'
                 */
                seeMoreText: 'See all results'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'handlebars', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($, window.Handlebars);

        $(function() {
            $('[data-autosuggest]').autosuggest();
        });
    }
})();

//
//  att.dropdown.js
//  AT&T UI Library
//
//  Created by André Neves on 02/09/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.dropdown', {
            _super: $.att.base,

            _events: {
                '.att-dropdown__selection click': '_clickSelection'
            },
            selectedIndex: 0,

            _render: function() {
                var self = this,
                    srPrefixText,
                    srSuffixText,
                    $selectedOption;

                this.id = this.$callingElement.attr('id');

                if (!this.id) {
                    this.id = this._getRandomId('att-dropdown-');
                }

                this.$options   = this.$callingElement.find('option');
                this.$container = $('<div>', { 'class': 'att-dropdown' });
                this.$selection = $('<a>', {
                    'class': 'att-dropdown__selection',
                    'href': '#',
                    'role': 'combobox',
                    'tabindex': 0
                });

                this.$dropdown  = $('<div>', {
                    'class': 'att-dropdown__items'
                });

                if (this.option('isLinksList')) {
                    this.$dropdown.addClass('att-dropdown__items--links-list')
                }

                this.$dropdownList = $('<ul>', {
                    'class': 'att-dropdown__wrapper',
                    'role': 'listbox',
                    'tabindex': 0
                });

                this.$overlay   = $('<div>', { 'class': 'att-dropdown__overlay' });

                srPrefixText = this.option('srPrefix');
                srSuffixText = this.option('srSuffix');

                if ($.type(srPrefixText) === 'string' && srPrefixText.length) {
                    this.$srPrefix = $('<span>', { 'class': this.option('srClass') }).text(srPrefixText);
                }

                if ($.type(srSuffixText) === 'string' && srSuffixText.length) {
                    this.$srSuffix = $('<span>', { 'class': this.option('srClass') }).text(srSuffixText);
                }

                this.$container.addClass(this.option('class'));
                this.$dropdown
                    .addClass(this.option('class'))
                    .append(this.$dropdownList);

                this.$element = this.$container;

                $selectedOption = this.$options.filter('[selected]:first');

                if (!$selectedOption.size()) {
                    $selectedOption = this.$options.first();
                    $selectedOption.attr('selected', true);
                }

                this.$callingElement
                    .hide()
                    .after(this.$container)
                    .appendTo(this.$container);

                $.each(this.$options, function(i) {
                    var option = $(this);
                    var isSelected = option.is(':selected') === true;
                    var $item = self._buildItem(option.text(), i, isSelected);

                    self.$dropdownList.append($item);
                });

                this.$items = self.$dropdownList.children();

                this._buildSelection($selectedOption.text());
                this._setDropdownItemsTextSize();

                this.selectedIndex = this.$options.index($selectedOption);

                this._getSelectedItem().addClass('att-dropdown__item--selected');

                this.$container.append(this.$selection);

                $('body')
                    .append(this.$overlay)
                    .append(this.$dropdown);

                this.$overlay.on('click.att-dropdown', $.proxy(this, '_blur'));

                this.$dropdown
                    .on('click.att-dropdown', '.att-dropdown__item', $.proxy(this, '_select'))
                    .on('mouseenter.att-dropdown', '.att-dropdown__item', $.proxy(this, '_activate'));

                this.$items.add(this.$selection)
                    .on('keydown.att-dropdown', $.proxy(this, '_onKeydown'))
                    .on('focus.att-dropdown', $.proxy(this, '_focus'));

                $(window).on('resize.att-dropdown', this._onBrowserResize.bind(this));
            },

            _getNewCaret: function() {
                return $('<span>', { 'class': 'caret', 'aria-hidden': 'true' });
            },

            _buildSelection: function(text) {
                var words;
                var totalWords;
                var $el = $('<div>');

                text = $.trim(text).replace(/\s{2,}/g, ' ');

                words = text.split(' ');
                totalWords = words.length;

                if (totalWords) {
                    var $firstWord = $('<span>', { 'class': 'first-word' });
                    var $middleWords;
                    var $lastWord;

                    $firstWord.text(words[0]);

                    if (totalWords > 1) {
                        $firstWord.text($firstWord.text() + ' ');

                        $lastWord = $('<span>', { 'class': 'last-word' });

                        $lastWord.text(words[totalWords - 1]);
                    } else {
                        $firstWord.addClass('last-word');
                    }

                    $el.append($firstWord);

                    words.shift();
                    words.pop();

                    if (words.length) {
                        $middleWords = $('<span>', { 'class': 'middle-words' });
                        $middleWords.text(words.join(' ') + ' ');

                        $el.append($middleWords);
                    }

                    if (totalWords > 1) {
                        $lastWord.append(this._getNewCaret());

                        $el.append($lastWord);
                    } else {
                        $firstWord.append(this._getNewCaret());
                    }
                }

                if (this.$srPrefix) {
                    $el.prepend(this.$srPrefix);
                }

                if (this.$srSuffix) {
                    $el.append(this.$srSuffix);
                }

                this.$selection.html($el.html());
            },

            _setDropdownItemsTextSize: function() {
                var keys =  [ 'h2', 'h3', 'h4', 'h5' ];
                var sizes = [ 30, 40, 68, 161 ];
                var maxTextLength = 0;

                this.$items.each(function() {
                    var textLength = $(this).text().length;

                    if (textLength > maxTextLength) {
                        maxTextLength = textLength;
                    }
                });

                for (var i = sizes.length - 1; i >= 0; i--) {
                    var key = keys[i];
                    var size = sizes[i];

                    if (maxTextLength > size) {
                        this.$dropdown.removeClass(this.option('class'));
                        this.$dropdown.addClass('att-dropdown--' + key);

                        break;
                    }
                }
            },

            _buildItem: function(text, index, active) {
                var $item = $('<li>', {
                    'class': 'att-dropdown__item',
                    'role': 'listitem',
                    'id': this.id + '-item-' + index,
                    'tabindex': 0
                }).data('index', index);

                var $icon = $('<i>', {
                    'class': this.option('selectedItemIcon'),
                    'aria-hidden': true
                }).addClass('checkmark');

                if (active) {
                    $item
                        .attr('aria-selected', true)
                        .addClass('att-dropdown__item--active');
                }

                var words = text.split(' ');
                var $lastWord = $('<span>', {
                    'class': 'last-word',
                    'text': words[words.length - 1]
                });

                words.pop();

                if (active) {
                    $lastWord.append($icon);
                }

                $item.text(words.join(' ') + ' ').append($lastWord);

                return $item;
            },

            _getItemAt: function(index) {
                return this.$items.eq(index);
            },

            _getSelectedItem: function() {
                return this._getItemAt(this.selectedIndex);
            },

            _getSelectedItemInnerOffset: function() {
                var self        = this;
                var innerOffset = 0;

                for (var i = 0; i < this.selectedIndex; i++) {
                    var $item = self._getItemAt(i);

                    innerOffset += $item.outerHeight(true);
                }

                return innerOffset;
            },

            _focus: function() {
                // Remove any focused att-dropdown
                $('.att-dropdown--focus').removeClass('att-dropdown--focus');

                this.$container.addClass('att-dropdown--focus');
            },

            _blur: function() {
                this._hide();

                this.$selection.focus();
            },

            _show: function() {
                var $activeItem   = this._getSelectedItem();
                var elOffset      = this.$selection.find('.first-word').offset();
                var windowHeight  = $(window).height();
                var maxHeight     = windowHeight / 2 * 0.8;
                var pageYOffset   = window.pageYOffset ? window.pageYOffset : $('body').scrollTop();
                var viewportWidth = $(window).width();
                var dropdownWidth = this.$dropdown.width();
                var optionPosition;
                var dropdownHeight;

                this._activate($activeItem);

                this.$dropdown
                    .css({ left: -99999 })
                    .attr('id', 'att-dropdown--open')
                    .addClass('att-dropdown--open');

                this.$dropdownList.css({ maxHeight: maxHeight });

                dropdownHeight = this.$dropdown.height();

                this.$dropdown.scrollTop(this._getSelectedItemInnerOffset() - dropdownHeight / 2 + $activeItem.outerHeight(true) / 2);

                optionPosition = $activeItem.position();

                if (elOffset.left + dropdownWidth > viewportWidth) {
                    elOffset.left = viewportWidth - dropdownWidth;
                }

                this.$dropdown.css({
                    top:  Math.max(this.option('minTop'), Math.min(pageYOffset + windowHeight - dropdownHeight - 10, elOffset.top - optionPosition.top)),
                    left: elOffset.left
                });

                $activeItem.focus();

                this.$overlay.show();
            },

            _hide: function() {
                this.$dropdown.css({
                    top:  '-10000px',
                    left: '-10000px'
                });

                this.$overlay.hide();
                this.$dropdown
                    .removeAttr('id')
                    .removeClass('att-dropdown--open');
            },

            _clickSelection: function(e) {
                e.preventDefault();

                this.$selection.trigger('focus');
                this._show();
            },

            _activate: function(e) {
                var $item = e instanceof jQuery ? e : $(e.currentTarget);

                this.$items.removeClass('att-dropdown__item--active');
                $item.addClass('att-dropdown__item--active');
            },

            _select: function(e) {
                var $item         = $(e.currentTarget),
                    index         = $item.data('index'),
                    $newSelection = this._getItemAt(index);

                this._hide();

                if (this.option('isLinksList')) {
                    var URL = this.$options.eq(index).data('url');

                    if (URL) {
                        return window.location = URL;
                    }
                }

                this.$items
                    .removeClass('att-dropdown__item--selected att-dropdown__item--active')
                    .find('.checkmark').remove();

                var $newItem = this._buildItem($newSelection.text(), index, true);
                $newSelection
                    .html($newItem.html())
                    .addClass('att-dropdown__item--selected');

                this.selectedIndex = index;

                this.$options.eq(this.selectedIndex).prop('selected', true);
                this.$callingElement.trigger('change');

                this._buildSelection($newSelection.text());

                this.$selection.off('focus.att-dropdown');
                this.$selection.focus();
                this.$container.addClass('att-dropdown--focus');
                this.$selection.on('focus.att-dropdown', $.proxy(this, '_focus'));
            },

            _onKeydown: function(e) {
                var $active         = this.$items.filter('.att-dropdown__item--active'),
                    code            = e.keyCode,
                    key             = $.att.base.keys,
                    isNavigationKey = [ key.SPACE, key.ARROW_UP, key.ARROW_DOWN ].indexOf(code) !== -1,
                    activeIndex,
                    index;

                if (!$active.size()) {
                    $active = this._getSelectedItem();
                }

                index = this.$items.index($active);
                activeIndex = this.$items.index(this.$items.filter('.att-dropdown__item--selected'));

                /**
                 * Show the list if the key is UP, Down
                 * or Space and it's not yet visible
                 */
                if (isNavigationKey && !this.$dropdown.hasClass('att-dropdown--open')) {
                    this._show();

                    return false;
                }

                if (code === key.ENTER || code === key.SPACE) {
                    if (code === key.ENTER && !this.$dropdown.hasClass('att-dropdown--open')) {
                        return false;
                    }

                    this.$items.eq(index).trigger('click.att-dropdown');

                    return false;
                } else if (code === key.ESC) {
                    this._hide();

                    return;
                } else if (code === key.ARROW_UP) {
                    index--;

                    if (index < 0) {
                        index = this.$items.size() - 1;
                    }
                } else if (code === key.ARROW_DOWN) {
                    index++;

                    if (index >= this.$items.size()) {
                        index = 0;
                    }
                } else if (code === key.TAB) {
                    this.$container.removeClass('att-dropdown--focus');

                    this._hide();

                    return;
                }

                $active
                    .removeAttr('aria-selected')
                    .removeClass('att-dropdown__item--active');

                $active = this.$items.eq(index);

                var $newItem = this._buildItem($active.text(), $active.data('index'), index === activeIndex);
                $active.html($newItem.html());

                $active
                    .attr('id', 'att-dropdown__item--active')
                    .attr('aria-selected', true)
                    .addClass('att-dropdown__item--active');

                var itemTop = $active.position().top;
                var itemHeight = $active.height();

                if (itemTop < 0) {
                    $active.get(0).scrollIntoView();
                } else if (itemTop + itemHeight > this.$dropdown.height()) {
                    $active.get(0).scrollIntoView(false);
                }

                $active.focus();

                if (isNavigationKey) {
                    return false;
                }
            },

            _onBrowserResize: function() {
                if (this.$overlay.is(':visible')) {
                    this._show();
                }
            },

            options: {
                'class': '',

                'selectedItemIcon': 'icon-checkbox-checkmark',

                'srPrefix': 'Showing options for ',

                'srSuffix': '; Click to choose a different category',

                'srClass': 'visuallyhidden',

                'isLinksList': false,

                'minTop': 20
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-dropdown]').dropdown();
        });
    }
})();

//
//  att.accordion.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.accordion', {
            _super: $.att.base,

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                this.$callingElement.find('> .att-accordion__group > .att-accordion__heading > .att-accordion__toggle').on('click', $.proxy(this, '_toggle'));

                this.$callingElement.find('> .att-accordion__group--open > .att-accordion__body').show();
            },

            _toggle: function(e) {
                var self  = this,
                    group = $(e.currentTarget).parents('.att-accordion__group:first'),
                    body  = group.find('> .att-accordion__body');

                if (!group.size()) {
                    return false;
                }

                if (!this.option('multiple')) {
                    this.$callingElement.find('> .att-accordion__group--open').not(group).each(function() {
                        $(this).removeClass('att-accordion__group--open');

                        $(this)
                            .find('> .att-accordion__body')
                            .slideUp(self.option('duration'), function() {
                                $(this).trigger('toggle', { group: $(this), visible: false });
                            });
                    });
                }

                this.$callingElement.trigger('before:toggle');

                body.trigger('before:toggle');

                body.slideToggle(this.option('duration'), function() {
                    var visible = body.is(':visible');
                    group.toggleClass('att-accordion__group--open', visible);

                    if ($.isFunction(self.option('toggle'))) {
                        self.option('toggle').call(self.$callingElement, { group: group, body: body, visible: visible });
                    }

                    body.trigger('toggle', { group: group, visible: visible });
                    self.$callingElement.trigger('toggle', { group: group, body: body, visible: visible });
                });

                e.preventDefault();
            },

            options: {
                /**
                 * Allow multiple accordion panels to be open at the same time
                 *
                 * @type {Boolean}
                 * @default true
                 */
                multiple: true,

                /**
                 * Function to call when the accordion toggles
                 * it's state
                 * @type {Function}
                 * @default null
                 */
                toggle: null,

                /**
                 * The total time that the toggle animation
                 * should take.
                 *
                 * @type {Number}
                 * @default 200
                 */
                duration: 200
            }
        }, false);

        $(function() {
            $('[data-accordion]').accordion();
        });
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-accordion]').accordion();
        });
    }
})();

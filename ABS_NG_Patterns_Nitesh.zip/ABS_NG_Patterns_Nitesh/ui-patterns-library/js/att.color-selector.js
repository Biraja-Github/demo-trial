//
//  att.color-selector.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.colorSelector', {
            _super: $.att.base,

            dependencies: {
                required: [
                    { name: 'att.radio', test: $.att.radio },
                    { name: 'att.tooltip', test: $.att.tooltip },
                    { name: 'att.popover', test: $.att.popover }
                ]
            },

            selectedIndex: 0,

            className: 'att-color-selector',

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                this.$radios = this.$callingElement.find(':radio');

                this.$callingElement.addClass(this.className);

                if (this.option('usePopover') === true) {
                    this._initializePopover();
                } else {
                    var $selectedRadio = this.$radios.filter(':checked');

                    this.selectedIndex = this.$radios.index($selectedRadio);

                    if (this.selectedIndex === -1) {
                        this.selectedIndex = 0;
                    }

                    this._initializeRadios(this.$callingElement, this.selectedIndex);
                }
            },

            _initializePopover: function() {
                var self           = this,
                    $selectedRadio = this.$radios.filter(':checked'),
                    totalRadios    = this.$radios.size();

                if (!$selectedRadio.size()) {
                    $selectedRadio = this.$callingElement.find(':radio:first');
                }

                this.selectedIndex = this.$radios.index($selectedRadio);
                this.initialHTML = this.$callingElement.html();

                /* jshint indent: false */
                this.$selectedValue = $([
                    '<a class="att-value-selector__popover-toggle" href="#">',
                        '<input type="hidden" />',
                        '<span class="att-value-selector__selected-circle"></span>',
                        '<i class="icon-dropdown-down"></i>',
                    '</a>'
                ].join(''));
                /* jshint indent: 4 */

                this.$callingElement.html(this.$selectedValue);

                if (totalRadios === 1) {
                    this.$selectedValue
                        .addClass('att-value-selector__popover-toggle--single')
                        .find('i').remove();
                }

                this.$selectedValueCirce = this.$selectedValue.find('.att-value-selector__selected-circle');
                this.$selectedValueInput = this.$selectedValue.find('input:hidden');

                if (this.option('tooltips') && $selectedRadio.attr('title')) {
                    this.$selectedValueCirce
                        .attr('title', $selectedRadio.attr('title'))
                        .tooltip();
                }

                this.$selectedValueInput.attr('name', $selectedRadio.attr('name'));

                this._styleSelectedValueCircle($selectedRadio);

                if (totalRadios > 1) {
                    this.$selectedValue.popover({
                        trigger: 'click',
                        position: this.option('popoverPosition'),
                        className: 'att-popover att-popover--value-selector',
                        container: this.option('popoverContainer'),
                        content: function() {
                            return self.initialHTML;
                        },

                        beforeOpen: function(plugin, $el) {
                            self._initializeRadios($el, self.selectedIndex);
                        }
                    });
                } else {
                    this.$selectedValue.on('click', function(e) {
                        e.preventDefault();
                    });
                }
            },

            _styleSelectedValueCircle: function($selectedRadio) {
                var title = $selectedRadio.attr('title');

                if (this.option('tooltips') && title) {
                    this.$selectedValueCirce.tooltip('setTitle', title);
                }

                this.$selectedValueCirce.css('background-color', $selectedRadio.data('color'));

                this.$selectedValueInput.val($selectedRadio.val());
            },

            _initializeRadios: function($el, selectedIndex) {
                var self = this;

                if (selectedIndex === undefined) {
                    selectedIndex = 0;
                }

                this.$radios = $el.find(':radio');

                this.$radios.each(function() {
                    var el;

                    $(this).radio({
                        tooltip: self.option('tooltips'),
                        style:   self.option('tooltipsStyle')
                    });

                    el = $(this).parent().addClass(self.className + '__item');

                    el.find('.att-radio__indicator').css('background-color', $(this).data('color'));
                    el.find(':radio').on('change', $.proxy(self, '_onChange'));
                }).eq(selectedIndex).radio('select');
            },

            _onChange: function() {
                var $checkedEl = this.$radios.filter(':checked');

                if (!$checkedEl.size()) {
                    return;
                }

                this.selectedIndex = this.$radios.index($checkedEl);

                if (this.option('usePopover') === true) {
                    this._styleSelectedValueCircle($checkedEl);
                }

                if (this.option('change') && $.isFunction(this.option('change'))) {
                    this.option('change').call(this.$callingElement, $checkedEl);
                }
            },

            options: {
                /**
                 * Callback to execute when selection changes
                 *
                 * @type Function
                 * @default null
                 */
                change: null,

                /**
                 * If the Tooltip widget shoulf be initialized
                 * if the radios have a title property set
                 * @type {Boolean}
                 */
                tooltips: true,

                tooltipsStyle: 'light',

                usePopover: false,

                popoverPosition: 'below',

                popoverContainer: 'body'
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-color-selector]').colorSelector();
        });
    }
})();

'use strict';

(function() {
    setTimeout(function() {
        $('.att--readmore__link').before('<span class="ellipsis">...&nbsp;</span>');

        $('.att--readmore__link').on('click',function(event){
            var content  = $(this).next(),
                ellipsis = content.parent().find('.ellipsis');

            $(this).hide();
            ellipsis.hide();
            content.show();

            event.preventDefault();
        });

        $('.att--readless__link').on('click',function(event){
            var content   = $(this).parent(),
                seeMore   = content.prev(),
                ellipsis = content.parent().find('.ellipsis');

            content.hide();
            ellipsis.show();
            seeMore.show();

            event.preventDefault();
        });
    }, 500);
})();

//
//  att.switch.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 Gen. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($, Hammer) {
        $.jqfactory('att.toggleSwitch', {
            _super: $.extend(true, {}, $.att.base, $.att.checkbox),

            dependencies: {
                optional: [
                    { name: 'Hammer.js', test: Hammer, url: 'http://eightmedia.github.io/hammer.js/' },
                    { name: 'jquery.hammer.js', test: $.fn.hammer, url: 'http://eightmedia.github.io/hammer.js/' }
                ]
            },

            initialDragPosition: null,

            _render: function() {
                var larger =  this.option('large') || (this.$callingElement.data('large') !== undefined),
                    container = $('<div>', { 'class': 'att-switch' + (larger ? ' att-switch--large' : '') }),
                    overflowWrapper = $('<div>', { 'class': 'att-switch__overflow-wrapper' }),
                    wrapper   = $('<div>', { 'class': 'att-switch__content' }),
                    showLabels = this.option('labels') || (this.$callingElement.data('labels') !== undefined);

                this.$container = container;
                this.$overflowWrapper = overflowWrapper;
                this.$wrapper = wrapper;
                this.$onLabel = $('<div>', { 'class': 'att-switch__on-label' }).text(showLabels ? this.option('onText') : '');
                this.$thumb = $('<div>', { 'class': 'att-switch__thumb' });
                this.$offLabel = $('<div>', { 'class': 'att-switch__off-label' }).text(showLabels ? this.option('offText') : '');

                this.$container
                    .toggleClass('att-switch--icons', !showLabels)
                    .append(overflowWrapper);

                this.$callingElement.after(this.$container);
                this.$callingElement.appendTo(this.$container);

                overflowWrapper.append(wrapper);

                wrapper.append(this.$onLabel);
                wrapper.append(this.$thumb);
                wrapper.append(this.$offLabel);

                this.containerWidth = this.$container.width();
                this.contentWidth = this.$wrapper.width();
                this.labelsWidth = this.$onLabel.width();

                this.$element = this.$container;

                if (Hammer) {
                    var handleDrag = $.proxy(this, '_handleDrag');

                    this.$wrapper
                        .hammer({
                            'correct_for_drag_min_distance': false,
                            'drag_block_horizontal': true,
                            'prevent_default': true
                        })
                        .on('dragstart drag dragend click', handleDrag);
                }

                if (this.option('checked')) {
                    this.$callingElement
                        .prop('checked', true)
                        .trigger('change');
                }

                this.$callingElement.on('keydown.att-dropdown', $.proxy(this, '_onKeydown'));

                this._bindEvents();
                this._bindLabelEvent();
                this.update();
            },

            _handleDrag: function(e) {
                var self = this;
                var min = -this.labelsWidth + 1;

                if (e.type === 'dragstart') {
                    this.initialDragPosition = this.$wrapper.position().left;

                    this.$wrapper.addClass('att-switch--dragging');
                } else if (e.type === 'drag') {
                    var left = Math.min(0, Math.max(this.initialDragPosition + e.gesture.deltaX, min));

                    this.$wrapper.css({ left: left });
                } else if (e.type === 'dragend') {
                    var isOn = this.$wrapper.position().left + (this.contentWidth / 3 * 1.5) > this.containerWidth / 2;

                    this.$wrapper.removeClass('att-switch--dragging');

                    this.$wrapper.animate({ left: (isOn ? 0 : min) }, 100, function() {
                        self.initialDragPosition = null;

                        if (self.$callingElement.prop('checked') !== isOn) {
                            self.toggle(isOn);
                        }

                        self.$wrapper.css({ left: '' });
                        self.$callingElement.focus();
                    });
                } else if (e.type === 'click' && (this.initialDragPosition === null)) {
                    self.toggle();

                    self.$callingElement.focus();
                }

                return false;
            },

            _onKeydown: function(e) {
                if (e.keyCode === $.att.base.keys.ARROW_LEFT) {
                    this.toggle(false);

                    e.preventDefault();
                } else if (e.keyCode === $.att.base.keys.ARROW_RIGHT) {
                    this.toggle(true);

                    e.preventDefault();
                }
            },

            options: {
                /**
                 * Whether to use labels inside the switch
                 *
                 * @type {Boolean}
                 * @default false
                 */
                labels: false,

                /**
                 * The label for the ON state
                 *
                 * @type {String}
                 * @default 'On'
                 */
                onText: 'On',

                /**
                 * The label for the OFF state
                 *
                 * @type {String}
                 * @default 'Off'
                 */
                offText: 'Off',

                /**
                 * Wether to use larger switches
                 *
                 * @type {Boolean}
                 * @default false
                 */
                large: false
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'hammerjs', 'jquery.hammer', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($, window.Hammer);

        $(function() {
            $('[data-toggle-switch]').each(function() {
                var el = $(this);

                if (!$(this).is(':checkbox')) {
                    el = $(this).find(':checkbox');
                }

                el.toggleSwitch();
            });
        });
    }
})();

//
//  att.rating.js
//  AT&T UI Library
//
//  Created by André Neves on 30/01/14.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.rating', {
            _super: $.att.base,

            dependencies: {
                required: [ { name: 'att.radio', test: $.att.radio } ]
            },

            filledClass: 'att-rating__item--filled',

            _events: {
                '.att-rating__item mouseenter': '_onHover',
                'mouseleave':                   '_reset'
            },

            _create: function() {
                var self = this;

                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                this.$callingElement
                    .addClass('att-rating')
                    .find(':radio').each(function() {
                        var el;

                        $(this).radio({
                            tooltip: self.option('tooltips')
                        });

                        el = $(this).parent().addClass('att-rating__item');

                        el.find(':radio').on('change', $.proxy(self, '_onChange'));
                    });

                if (this.option('class')) {
                    this.$callingElement.addClass(this.option('class'));
                }

                this._update();
            },

            _reset: function() {
                this._update();
            },

            _onHover: function(e) {
                var el = $(e.currentTarget).find(':radio');

                if (!el.size()) {
                    return;
                }

                this._update(el);
            },

            _onChange: function() {
                var checkedInput = this.$callingElement.find(':radio:checked');

                this._update();

                if (checkedInput.size() && this.option('change') && $.isFunction(this.option('change'))) {
                    this.option('change').call(this.$callingElement, checkedInput);
                }
            },

            _update: function(el) {
                var checkedInput = el ? el : this.$callingElement.find(':radio:checked'),
                    checkedEl    = checkedInput.parent(),
                    checkedIndex = 0;

                this.$callingElement.children().removeClass(this.filledClass);

                if (!checkedInput.size()) {
                    return;
                }

                checkedIndex = this.$callingElement.children().index(checkedEl);

                this.$callingElement.children().filter(':lt(' + (checkedIndex + 1) + ')').addClass(this.filledClass);
            },

            options: {
                /**
                 * Extra class names to add to the rating wrapper
                 *
                 * @type String
                 * @default null
                 */
                'class': '',

                /**
                 * Callback to execute when selection changes
                 *
                 * @type Function
                 * @default null
                 */
                'change': null,

                /**
                 * If the Tooltip widget shoulf be initialized
                 * if the radios have a title property set
                 * @type {Boolean}
                 */
                'tooltips': true
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-rating]').rating();
        });
    }
})();

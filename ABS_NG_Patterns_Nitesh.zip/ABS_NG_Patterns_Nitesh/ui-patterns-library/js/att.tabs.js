//
//  att.tabs.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.tabs', {
            _super: $.att.base,

            _create: function() {
                if (!this._superMethod('_create')) {
                    return;
                }

                this.$items = this.$callingElement.children();

                this.showPointer = this.$callingElement.hasClass('tabs--image') || this.$callingElement.hasClass('simplified-tabs__items');

                if (this.showPointer) {
                    this.$pointer = $('<li>', { 'class': 'tabs__pointer' });
                    this.$callingElement.append(this.$pointer);
                }

                this.$tabsContainer = $(this.$callingElement.data('tabs'));

                this.$callingElement.find('[href]:not([href="#"])').on('click', $.proxy(this, '_show'));
            },

            _show: function(e) {
                var $el      = e instanceof jQuery ? e : $(e.currentTarget),
                    $tabPane = this.$tabsContainer.find($el.attr('href')),
                    $tab     = $el.parent();

                if ($tab.hasClass('tabs__item--active')) {
                    if (!(e instanceof jQuery)) {
                        e.preventDefault();
                    }

                    return;
                }

                if (this.showPointer) {
                    this._movePointer($tab);
                }

                // Toggle active tab
                this.$callingElement.find('.tabs__item--active').removeClass('tabs__item--active');
                $tab.addClass('tabs__item--active');

                // Toggle active tab pane
                this.$tabsContainer.find('.tabs__pane--active').removeClass('tabs__pane--active');
                $tabPane.addClass('tabs__pane--active');

                if (this.option('change') && $.isFunction(this.option('change'))) {
                    this.option('change').apply(this, [ $el.attr('href').replace('#', '') ]);
                }

                if (!(e instanceof jQuery)) {
                    e.preventDefault();
                }
            },

            _movePointer: function($tab) {
                var self = this;
                var currentTab = this.$callingElement.find('.tabs__item--active');
                var positionOfPointerBefore = currentTab.position().left + currentTab.width() / 2;
                var positionOfPointerAfter = $tab.position().left + $tab.width() / 2;

                this.$callingElement.addClass('tabs--no-pointer');

                if (!this.$pointer.is(':animated')) {
                    this.$pointer
                        .css({ left: positionOfPointerBefore })
                        .show();
                }

                this.$pointer
                    .stop(true)
                    .animate({
                        left: positionOfPointerAfter
                    }, this.option('animationDuration'), function() {
                        $(this).hide();

                        self.$callingElement.removeClass('tabs--no-pointer');
                    });
            },

            activate: function(index) {
                index = Math.max(0, Math.min(index, this.$items.size() - 1));

                this._show(this.$items.eq(index).find('a'));
            },

            options: {
                /**
                 * The function to call when the active tab changes.
                 * The functionreceives the active tabPane id
                 *
                 * @type {Function}
                 * @default null
                 */
                change: null,

                /**
                 * The duration of the pointer animation
                 *
                 * @type {Number}
                 * @default 500
                 */
                animationDuration: 500
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-tabs]').tabs();
        });
    }
})();

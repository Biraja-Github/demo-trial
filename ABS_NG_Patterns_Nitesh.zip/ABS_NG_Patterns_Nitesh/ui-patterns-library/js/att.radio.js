//
//  att.radio.js
//  AT&T UI Library
//
//  Created by André Neves on 01/05/13.
//  Copyright (c) 2013 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('att.radio', {
            _super: $.att.base,

            dependencies: {
                optional: [ { name: 'att.tooltip', test: $.att.tooltip } ]
            },

            name: '',
            disabled: false,
            hasTooltip: false,

            $label: null,
            $radios: null,

            _create: function() {
                if (!this._superMethod('_bootstrap')) {
                    return;
                }

                this.name = this.$callingElement.attr('name');
            },

            _render: function() {
                this.$container = $('<div>', { 'class': 'att-radio' });

                this.$container.append($('<div>', {
                    'class': 'att-radio__indicator',
                    'aria-hidden': true
                }));

                this.$callingElement
                    .after(this.$container)
                    .appendTo(this.$container);

                this.$element = this.$container;

                this.$radios = this._getRadios();

                if (this.option('tooltip') && $.fn.tooltip && this.$callingElement.attr('title')) {
                    this.hasTooltip = true;

                    this.$container.attr('title', this.$callingElement.attr('title'));

                    this.$container.tooltip($.extend({}, this.options, this.$callingElement.data()));
                }

                this._bindEvents();
                this._bindLabelEvent();
                this.update();
            },

            _bindEvents: function() {
                this.$callingElement
                    .off('.att-checkbox')
                    .on({
                        'focus.att-radio': this._updateFocus.bind(this),
                        'blur.att-radio': this._updateFocus.bind(this)
                    });

                this.$radios.on('change', this.update.bind(this));
                this.$container.on('click.att-radio', this.select.bind(this));

                if (this.$label && this.$label.size()) {
                    this.$label.on('click.att-radio', this._onClickLabel.bind(this));
                }
            },

            _bindLabelEvent: function() {
                if (this.$container.parent().is('label')) {
                    this.$label = this.$container.parent();

                    // unbind from the container, as the label
                    // will pick up the event
                    this.$container.off('click.att-radio');
                    this.$label.addClass('form-field__label--with-input');
                } else if (this.$callingElement.attr('id')) {
                    this.$label = $('label[for="' + this.$callingElement.attr('id') + '"]');
                }

                if (this.$label && this.$label.size()) {
                    this.$label.on('click.att-radio', this._onClickLabel.bind(this));
                }
            },

            _getRadios: function() {
                var $form = this.$callingElement.parents('form:first');

                if (!$form.size()) {
                    $form = $('body');
                }

                return $form.find(':radio[name="' + this.name + '"]');
            },

            _updateFocus: function() {
                var self = this;

                setTimeout(function() {
                    var isFocused = self.$callingElement.is(':focus');

                    if (self.hasTooltip) {
                        self.$container.tooltip('toggle', isFocused);
                    }

                    self.$container.toggleClass('att-radio--focused', isFocused);
                }, 10);
            },

            _onClickLabel: function(e) {
                if (!$(e.target).is(this.$callingElement)) {
                    e.preventDefault();
                }

                this.select(e);
            },

            update: function() {
                this.$container.toggleClass('att-radio--on', this.$callingElement.prop('checked'));

                this.disabled = this.$callingElement.prop('disabled');

                this[this.disabled ? 'disable' : 'enable']();
            },

            select: function(e) {
                this.$callingElement
                    .prop('checked', true)
                    .trigger('change');

                $.each(this.$radios, function() {
                    var plugin = $(this).data('attRadio');

                    if (plugin) {
                        plugin.update();
                    }
                });

                if (e) {
                    this.$callingElement.focus();
                }
            },

            enable: function() {
                this.disabled = false;

                this.$callingElement.prop('disabled', false);

                this.$container.removeClass('att-radio--disabled');
            },

            disable: function() {
                this.disabled = true;

                this.$callingElement.prop('disabled', true);

                this.$container.addClass('att-radio--disabled');
            },

            options: {
                /**
                 * If the Tooltip widget shoulf be initialized
                 * if the element has a title property set
                 * @type {Boolean}
                 */
                tooltip: true
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base', 'att.tooltip' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-radio]').each(function() {
                var el = $(this);

                if (!$(this).is(':radio')) {
                    el = $(this).find(':radio');
                }

                el.radio();
            });
        });
    }
})();

//
//  att.labelmask.js
//  AT&T UI Library
//
//  Created by André Neves on 25/07/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {
    function factory($) {
        if ($.inputmask) {
            $.inputmask.defaults.aliases.phone = { 'mask': '+1(###)###-####', 'cc': [ 'US', 'CA' ], 'name_en': 'USA and Canada', 'desc_en': '' };
        }

        $.jqfactory('att.labelmask', {
            _super: $.att.base,

            dependencies: {
                required: [
                    { name: 'jquery.inputmask', test: $.fn.inputmask, url: 'https://github.com/RobinHerbots/jquery.inputmask' }
                ]
            },

            _events: {
                'keyup': 'update',
                'change': 'update',
                'input': 'update',
                'blur': 'update'
            },

            _render: function() {
                this.id = this.$callingElement.attr('id');

                if (!this.id) {
                    return;
                }

                this.$label = $('[for="' + this.id + '"]');

                if (!this.$label.size()) {
                    return;
                }

                this._addMask();
                this.update();
            },

            _addMask: function() {
                this.$mask = $('<span>', { 'class': 'att-labelmask' });

                this.$label.append(this.$mask);
            },

            _getFormatOptions: function() {
                var options = {};

                if (this.$callingElement.data('patternAlias')) {
                    options.alias = this.$callingElement.data('patternAlias');
                } else {
                    options.mask = this.$callingElement.data('pattern') || '';
                }

                options = $.extend({}, options, {
                    greedy: this.option('greedy')
                });

                return options;
            },

            update: function() {
                var value = this.$callingElement.val();
                var options = this._getFormatOptions();

                if (!options.mask && !options.alias) {
                    return;
                }

                var formattedValue = $.inputmask.format(value, options);

                this.$mask.text(formattedValue);
            },

            options: {
                greedy: false
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-labelmask]').labelmask();
        });
    }
})();

![att_logo] 
# ABS Angular library - [AngularJS](http://angularjs.org/)

## To Add a New Module **nModule**
1.	**Create** a copy of the file ng-misc/module.html name it ng-misc/nModule.hbs
2.	**Open** nModule.hbs and replace all the occurrences of *module* by *nModule*
        - Keep and update 'section-id' and 'section-name' in line no. 1 if this component is the first sub-module under the parent module as per the left navigation bar.
        - Otherwise, delete line no. 1
3.	**ADD** one entry at the end of the file app\templates\pages\ng-ui-elements.hbs
```
        {{> nModule }}
```
4.	**ADD** Menu and Sub Menu Items in app\data\menu.json
5.      **Menu.json** file, Each and every Menu & submenu contains two json objects.
        - title- Title of the menu
        - section-Id of that markup section

### Create the following folder / file structure under the directory app\scripts\ng_js_att
```javascript
app\scripts\ng_js_att\nModule\docs
app\scripts\ng_js_att\nModule\test
app\scripts\ng_js_att\nModule\nModule.js
app\scripts\ng_js_att\nModule\docs\demo.html
app\scripts\ng_js_att\nModule\docs\demo.js
app\scripts\ng_js_att\nModule\docs\readme.md
app\scripts\ng_js_att\nModule\test\nModule.spec.js
```

### Inside demo.html
Each sub-module should have the following identifier as the first line:

```
<!-- ABSSBA -->
```

Enclose dev-notes specific code with the following identifiers:

```
<!-- ABSDEVN -->DEV-NOTES SPECIFIC CODE<!-- ABSDEVN -->
```

### Inside readme.md
Each sub-module specific documentation should have the following identifier as the first line:

```
<!-- ABSSBA -->
```

### Inside demo.js
If we have separate controllers for each sub-module, each of them need to have the following identifier as the first line.  
If we have a common controller (only 1) in the demo.js file, we can completely ignore putting the below identifier:

```
//ABSSBA
```

_Note: All files inside 
```
    app\ scripts\ ng_js_att\ nModule\ docs
```
folder, need to have same number of identifiers in each file._


### Any templates used will go under the following folder
```javascript
    app\scripts\ng_js_att_tpls
```

General Development Rules
-------------------------
1.	Directive to have only the logic.
2.	Styles to be out of the logic.
3.	Markup to be into templates.

## To Build
```javascript
run ng-Build.bat which will in turn call the following
grunt --gruntfile ng-Gruntfile.js
grunt --gruntfile Gruntfile.js
```
    
## To Run in Browser
```javascript
    http://localhost:8000/
```
## To Run the node web server
```javascript
    CD dist
    run ng-server.bat
```
# Copyright
PROPRIETARY INFORMATION

_Not for use or disclosure outside of the AT&T family of companies, except under written agreement._


[AngularJS]:http://angularjs.org
[QuickStart]:http://quickstart.att.com
[NodeJS]:http://nodejs.org
[att_logo]:http://www.underconsideration.com/speakup/archives/att_new_logo.jpg
[det_logo]: http://quickstart.web.att.com/images/logo-DETS.png

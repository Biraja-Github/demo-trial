angular.module('abs', ['att.abs', 'att.abs.helper']);
angular.module('att.abs.helper', []);
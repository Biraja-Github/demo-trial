/**
 * Instantiating a modal programmatically:
 */

$(function() {
    var $myModal = $('#modal-selector');

    $myModal.modal({
        /**
         * If the modal should be closed when clicking the overlay
         *
         * @type {Boolean}
         * @default false
         */
        readOnly: false
    });

    $('button.show-modal').on('click', function() {
        $myModal.modal('show');
    });

    $('button.show-modal').on('click', function() {
        $myModal.modal('hide');
    });
});

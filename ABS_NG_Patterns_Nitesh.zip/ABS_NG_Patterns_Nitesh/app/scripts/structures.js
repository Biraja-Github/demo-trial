'use strict';

(function($, window, document, undefined) {
    $(function() {
        initilaizeRadioButtons();
        initializeXRayMachines();
        initializeMagnifiers();
    });

    function initilaizeRadioButtons() {
        $('.radio-group').bind('click', function() {
            var selection = this.id;

            if (selection === 'select4') {
                $('.grid-overlay').removeClass('col-6select').addClass('col-4select');
            } else if (selection === 'select6') {
                $('.grid-overlay').removeClass('col-4select').addClass('col-6select');
            }
        });
    }

    function initializeXRayMachines() {
        $('.twentytwenty-container').each(function() {
            var $el    = $(this),
                images = $el.find('img'),
                total  = images.size(),
                loaded = 0;

            images.on('load', function() {
                loaded++;

                if (loaded === total) {
                    $el.twentytwenty({
                        /* jshint camelcase: false */
                        default_offset_pct: 1,
                        orientation: 'horizontal'
                        /* jshint camelcase: true */
                    });
                }
            });
        });

        $('.twentytwenty-container').mousemove(function(e) {
            var $container = $(this),
                y          = e.pageY - $container.offset().top + 8;

            $container.find('.twentytwenty-handle').css({
                top: y
            });
        });
    }

    function initializeMagnifiers() {
        var $els = $('#glass1, #glass2, #glass3, #glass4');

        $els.each(function() {
            var $el = $(this);

            $el.mlens({
                imgSrc: $el.attr('data-big'),
                imgSrc2x: $el.attr('data-big2x'),
                lensShape: 'circle',
                lensSize: 180,
                borderSize: 4,
                borderColor: '#0679b4',
                borderRadius: 0,
                overlayAdapt: false
            });
        });
    }

}(jQuery, window, document, undefined));

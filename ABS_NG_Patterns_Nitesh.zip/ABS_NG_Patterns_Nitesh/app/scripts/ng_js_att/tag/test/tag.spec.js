describe('Tag', function() {

    var $scope, $compile;

    // load the tagBadges code
    beforeEach(module('att.abs.tag'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/tag/tag.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };

    it('should be rendered when the tag element is applied', function() {
        var localElm = compileElement('<tag>Tag Name</tag>', $scope, $compile);

        expect(localElm.find('div').eq(0)).toHaveClass('tag');
    });

    it('should be rendered closable', function() {
        var localElm = compileElement('<tag>Tag Name</tag>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-erase');
    });
    
    it('should be rendered with icon when the style-type=icon attr is applied', function() {
        var localElm = compileElement('<tag style-type="icon">Tag Name</tag>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-filters tag__icon');
    });
    
    it('should be rendered closable with icon when style-type=icon attr is applied', function() {
        var localElm = compileElement('<tag style-type="icon">Tag Name</tag>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-filters tag__icon');
        expect(localElm.find('i').eq(1)).toHaveClass('icon-erase');
    });
    
    it('should be rendered with correct count', function() {
        var localElm = compileElement('<tag>Tag Name (99)</tag>', $scope, $compile);

        expect(localElm.find('span').eq(0).text()).toBe('Tag Name (99)');
    });
    
    it('should be rendered closable with correct count', function() {
        var localElm = compileElement('<tag>Tag Name (99)</tag>', $scope, $compile);

        expect(localElm.find('span').eq(0).text()).toBe('Tag Name (99)');
        expect(localElm.find('i').eq(0)).toHaveClass('icon-erase');
    });
    
    it('should be rendered small when the small attr is applied', function() {
        var localElm = compileElement('<tag small>Tag Name</tag>', $scope, $compile);

        expect(localElm.find('div').eq(0)).toHaveClass('tag--small');
    });
    
    it('should be rendered closable and small when small attr is applied', function() {
        var localElm = compileElement('<tag small>Tag Name</tag>', $scope, $compile);

        expect(localElm.find('div').eq(0)).toHaveClass('tag--small');
        expect(localElm.find('i').eq(0)).toHaveClass('icon-erase');
    });
    
    it('should be rendered closable and execute on-close function when tag is closed', function() {
        $scope.theMethodToBeCalled = function(data) {
//            alert(data);
        };
        var localElm = compileElement('<tag on-close="theMethodToBeCalled(\'Tag Closed...!!\')">Tag Name</tag>', $scope, $compile);
        expect(localElm.find('i').eq(0)).toHaveClass('icon-erase');
        
        spyOn($scope,"theMethodToBeCalled");
        
        localElm.find('a').eq(0).click();
        expect($scope.theMethodToBeCalled).toHaveBeenCalled();
    });
    
});

describe('Tag Cloud', function() {

    var $scope, $compile;

    // load the tagBadges code
    beforeEach(module('att.abs.tag'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/tag/tagCloud.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/tag/tagCloudItem.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    beforeEach(function() {
        $scope.modelArray={};
    });
    
    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };
    
    it('should render parent(tag-cloud) when it is applied', function() {
        var localElm = compileElement('<tag-cloud></tag-cloud>', $scope, $compile);

        expect(localElm).toHaveClass('tags-cloud');
    });
    
    it('should transclude whatever is applied inside parent(tag-cloud)', function() {
        var localElm = compileElement('<tag-cloud>Test Text</tag-cloud>', $scope, $compile);

        expect(localElm).toHaveClass('tags-cloud');
        expect(localElm.text()).toBe('Test Text');
    });
    
    it('should be rendered correctly when the parent(tag-cloud) and child(tag-cloud-item) element is applied', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item checked="true" ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);

        expect(localElm).toHaveClass('tags-cloud');
        expect(localElm.find('label').eq(0)).toHaveClass('tag');
        expect(localElm.find('label').eq(0).find('input').eq(0).attr('type')).toBe('checkbox');
        expect(localElm.find('span').eq(0)).toHaveClass('tag__title');
    });
    
    it('should be rendered correctly with correct inline text', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);

        expect(localElm.find('span').eq(0).text()).toBe('AT&T');
    });
    
    it('should be rendered pre-selected when attr checked is applied', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item checked="true" ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);

        expect(localElm.find('label').eq(0).find('input').eq(0).attr('checked')).toBeTruthy();
    });
    
    it('should have model value true when attr checked is applied', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item checked="true" ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);
        
        expect($scope.modelArray.att).toBeTruthy();
    });
    
    it('should have default model value false when attr checked is not applied', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);
        
        expect($scope.modelArray.att).toBeFalsy();
    });
    
    it('should toggle model value (true/false) when it is clicked, based on checkbox value', function() {
        var localElm = compileElement('<tag-cloud><tag-cloud-item ng-model="modelArray.att">AT&T</tag-cloud-item></tag-cloud>', $scope, $compile);
        
        expect($scope.modelArray.att).toBeFalsy();
        
        localElm.find('label').eq(0).find('input')[0].click();
        $scope.$digest();
        expect($scope.modelArray.att).toBeTruthy();
        
        localElm.find('label').eq(0).find('input')[0].click();
        $scope.$digest();
        expect($scope.modelArray.att).toBeFalsy();
        
        
        localElm.find('label').eq(0).find('input')[0].click();
        $scope.$digest();
        expect($scope.modelArray.att).toBeTruthy();
        
        localElm.find('label').eq(0).find('input')[0].click();
        $scope.$digest();
        expect($scope.modelArray.att).toBeFalsy();
        
    });
    
});
angular.module('att.abs.tag', [])
        .directive('tag', ['$parse', function($parse) {
                return {
                    restrict: 'E',
                    replace: false,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/tag/tag.html',
                    scope: {
                        styleType: "@",
                        onClose: "&"
                    },
                    link: function(scope, elem, attr, ctrl) {
                        scope.isSmall = false;
                        scope.isIcon = false;
                        scope.display = true;

                        if (attr.small === "") {
                            scope.isSmall = true;
                        }
                        
                        if (scope.styleType === "icon") {
                            scope.isIcon = true;
                        }
                        
                        scope.closeMe = function() {
                            scope.display = false;
                            if(typeof scope.onClose === "function"){
                                scope.onClose = $parse(scope.onClose);
                                scope.onClose();
                            }
                        };
                    }
                };
            }])
        .directive('tagCloud', [ function() {
                return {
                    restrict: 'EA',
                    controller: function(){},
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/tag/tagCloud.html',
                    scope: {
                    },
                    link: function(scope, elem, attr, ctrl) {
                        
                    }
                };
            }])
        .directive('tagCloudItem', [ function() {
                return {
                    restrict: 'EA',
                    require: ['^tagCloud','ngModel'],
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/tag/tagCloudItem.html',
                    scope: {
                        state: '=ngModel'
                    },
                    link: function(scope, elem, attr, tagCloudCtrl) {
                        scope.isChecked=false;
                        
                        if(attr.checked === "true"){
                            scope.isChecked=true;
                            scope.state=true;
                        }
                        else{
                            scope.state=false;
                        }
                    }
                };
            }]);
        
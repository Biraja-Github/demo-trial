<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **tag directive** is built using angular library.
This can be used for rendering various tags in an application.

We can control various parameters like small, style-type, on-close while using this directive.

#### `<Attribute level configuration for rendering tags>` ####

 * `small`
 	:
 	The attr flag to render the Tag of small size. No values required.

 * `style-type`
 	:
 	The attr to indicate the type of Tag. Valid values are icon.

 * `on-close`
 	:
 	The attr serves as an option to specify a callback function, as soon as the Tag is closed.
    
        Sample Callback function :
        $scope.theMethodToBeCalled = function(data) {
            alert(data);
        };

<br/><br/>

<p class="guideline-title">Red Lines</p>
<div class="guidelines-data-tag"></div>

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>The tags are used when a choice is required in order to complete an action.</li>
    <li>The tags can be closed by pressing the cross mark next to each of them.</li>
</ul>

<!-- ABSSBA -->
SAMPLE CONTENT FROM README.MD

**Directives**

1. `tag-cloud`
2. `tag-cloud-item`

//ABSSBA
var tagController = function($scope) {
    $scope.theMethodToBeCalled = function(data) {
        alert(data);
    };
};

//ABSSBA
var tagCloudController = function($scope) {
    $scope.modelArray = {
        active: {
            //These (model: "") are left blank so as to give an empty model container with a reference in Controller.
            model: "",
            label: "Active"
        },
        admin: {
            model: "",
            label: "Admin"
        },
        deactivated: {
            model: "",
            label: "Deactivated"
        },
        idle: {
            model: "",
            label: "Idle"
        },
        lost: {
            model: "",
            label: "Lost"
        },
        locked: {
            model: "",
            label: "Locked"
        },
        stolen: {
            model: "",
            label: "Stolen"
        },
        suspended: {
            model: "",
            label: "Suspended"
        },
        android: {
            model: "",
            label: "Android"
        },
        apple: {
            model: "",
            label: "Apple"
        },
        samsung: {
            model: "",
            label: "Samsung"
        },
        sony: {
            model: "",
            label: "Sony"
        },
        nokia: {
            model: "",
            label: "Nokia"
        },
        htc: {
            model: "",
            label: "HTC"
        },
        att: {
            model: "",
            label: "AT&T",
            checked: "true"
        },
        tag1: {
            model: "",
            label: "Tag1"
        },
        tag2: {
            model: "",
            label: "Tag2"
        },
        tag3: {
            model: "",
            label: "Tag3"
        }
    };
};
describe('Unit Test- Tabs', function() {
    var scope,compile;
    beforeEach(module('att.abs.megaMenu'));
    beforeEach(module('app/scripts/ng_js_att_tpls/megaMenu/menuTab.html'));
	beforeEach(module('app/scripts/ng_js_att_tpls/megaMenu/parentmenuTab.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/megaMenu/submenuTab.html'));
    beforeEach(inject(function(_$rootScope_,_$window_, _$compile_, _$q_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
        $q = _$q_;
		$window=_$window_;
    }));

        var compileMarkup = function(markup, scope) {
			scope.megaMenu = [
    
		    {
            name: "Manage",
            subItems: [
                {
				name: "Account",
				url:"",
				subChildItems:[{
					title:"Alarms",
						value:[
						{value:"View All Alarms",
							url:""},
							{value:"Search All Alarms",
							url:""},
							
						 ]
				},
				{title:"Notifications",
						value:[
							{value:"View All Tests",
							url:""}
						 ]
						 },
						 {title:"Trouble Tickets",
						value:[
							{value:"View All Trouble Ticket",
							url:""},
							{value:"Create a Trouble Ticket",
							url:""}
						 ]
						 }
				
				]	
				},
                {name: "Network",
				url:"#emHome",
				subChildItems:[{title:"Trouble Tickets",
						value:[
							{value:"View All Trouble Ticket",
							url:"#emHomemaintenance"},
							{value:"Create a Trouble Ticket",
							url:"emHomemaintenance"}
						 ]
						 }]	
				}
            ]
        },
		
        {
            name: "Tools",
            subItems: [
                {name: "Support",
				subChildItems:[{title:"Inventory",
						value:[
						{value:"View All Inventory",
							url:""},
							{value:"Search All Assets",
							url:""}
						 ]
						 }]	
				},
                {name: "Settings",
				subChildItems:[{title:"Tests",
						value:[
							{value:"View All Tests",
							url:""},
							{value:"Requets Tests",
							url:""}
						 ]
						 }]	
				},
                {name: "Maitenance",
				subChildItems:[{title:"Notifications",
						value:[
							{value:"View All Tests",
							url:""}
						 ]
						 }]	
				}
            ]
        },
        {
            name: "Support",
            subItems: [
                {name: "SubItem6"}
            ]
        }
    ];
            var el = $compile(markup)(scope);
            scope.$digest();
            return el;
        };

	it('should toggle active class on click on tabs of the MegaMenu', function() {
		$scope.activeClickSubMenu={};
		$scope.activeClickMenu={};
	
        var markUp = compileMarkup('<parent-tab menu-items="megaMenu" active-sub-menu="activeClickSubMenu.x" active-menu="activeClickMenu.x"><parentmenu-tabs mega-menu="true" menu-items="megaMenu"><menu-tabs mega-menu="true" menu-item="item" active-menu="activeClickMenu.x" ng-repeat="item in megaMenu">{{item.name}}{{activeClickMenu.active}}</menu-tabs></parentmenu-tabs></parent-tab>', $scope);
		var list = markUp.children();
        var firstItem = list.children().eq(0);
		var secondItem = firstItem.children().eq(0);
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
		expect(secondItem.text()).toBe('Manage');
		 
		var markUp = compileMarkup('<parent-tab menu-items="megaMenu" active-sub-menu="activeClickSubMenu.x" active-menu="activeClickMenu.x"><parentmenu-tabs sub-menu="true" ng-show="activeClickMenu.x.active" menu-items="activeClickMenu.x.subItems"><menu-tabs sub-menu="true" menu-item="subItem" ng-repeat="subItem in activeClickMenu.x.subItems" active-menu="activeClickSubMenu.x" sub-item-active="{{subItem.active}}">{{subItem.name}}</menu-tabs></parentmenu-tabs></parent-tab>', $scope);
		var list = markUp.children();
		var firstItem = list.children().eq(0);
        var secondItem = list.children().children().eq(0);
		secondItem.mouseover();
        expect(secondItem).toHaveClass('subMenuHover');
		expect(secondItem.text()).toBe('Account');
		
		var markUp = compileMarkup('<parent-tab menu-items="megaMenu" active-sub-menu="activeClickSubMenu.x" active-menu="activeClickMenu.x"><div class="sub__menu"  ng-show="activeClickSubMenu.x.active" ng-mouseleave="activeClickSubMenu.x.active=\'false\'"><menu-tabs ng-repeat="subItem in activeClickSubMenu.x.subChildItems" ng-show="activeClickSubMenu.x.active"><p>{{subItem.title}}</p><div att-links-list=""><a att-links-list-item="" ng-repeat="tabValue in subItem.value track by $index" href="">{{tabValue.value}}</a></div></menu-tabs></div></parent-tab>', $scope);
		var list = markUp.children();
		var firstItem = list.children().eq(0);
		var secondItem = firstItem.children().eq(0);
		 expect(secondItem.text()).toBe('Alarms');
		 var linkItem= markUp.find('a').eq(0);
		 expect(linkItem.text()).toBe('View All Alarms');
    });	
		
	it('should dropdown secondary menu on click of mega menu tab and drop down third menu on hover of secondary menu tab', function() {
		$scope.activeClickSubMenu={};
		$scope.activeClickMenu={};
        var markUp = compileMarkup('<parent-tab menu-items="megaMenu" active-sub-menu=\'activeClickSubMenu.x\' active-menu=\'activeClickMenu.x\'><parentmenu-tabs mega-menu="true" menu-items="megaMenu"><li class="megamenu__item"><a href="#">ATT business support</a></li><menu-tabs mega-menu="true" menu-item="item" active-menu="activeClickMenu.x" ng-repeat="item in megaMenu">{{item.name}}</menu-tabs></parentmenu-tabs><parentmenu-tabs sub-menu="true" ng-show="activeClickMenu.x.active" menu-items="activeClickMenu.x.subItems"><menu-tabs sub-menu="true" menu-item="subItem" ng-repeat="subItem in activeClickMenu.x.subItems" active-menu="activeClickSubMenu.x" sub-item-active="{{subItem.active}}"><a ng-href="{{subItem.url}}">{{subItem.name}}</a></menu-tabs></parentmenu-tabs><div class="sub__menu" ng-show="activeClickSubMenu.x.active" ng-mouseleave="activeClickSubMenu.x.active=\'false\'"><menu-tabs menu-item="subItem" ng-repeat="subItem in activeClickSubMenu.x.subChildItems" ng-show="activeClickSubMenu.x.active"><p class="title">{{subItem.title}}</p><div att-links-list=""><a att-links-list-item="" ng-repeat="tabValue in subItem.value track by $index" href="{{tabValue.url}}">{{tabValue.value}}</a></div></menu-tabs></div> </parent-tab>', $scope);
		var list = markUp.children();
        var firstItem = list.children().eq(0);
		var firstchildItem = firstItem.children().eq(2);
		expect(firstchildItem.text()).toBe('Tools');
        firstchildItem.click();
		var secondItem=list.children().eq(1);
		var secondchildItem = secondItem.children().eq(1);
		expect(secondchildItem.text()).toBe('Settings');
		secondchildItem.mouseover();
		var thirdItem=list.eq(2);
		var linkItem= thirdItem.find('a').eq(0);
		 expect(linkItem.text()).toBe('View All Tests');
    });		
	
	it('should dropdown secondary menu on click of mega menu tab and drop down third menu on hover of secondary menu tab', function() {
		$scope.activeClickSubMenu={};
		$scope.activeClickMenu={};
        var markUp = compileMarkup('<parent-tab menu-items="megaMenu" active-sub-menu=\'activeClickSubMenu.x\' active-menu=\'activeClickMenu.x\'><parentmenu-tabs mega-menu="true" menu-items="megaMenu"><li class="megamenu__item"><a href="#">ATT business support</a></li><menu-tabs mega-menu="true" menu-item="item" active-menu="activeClickMenu.x" ng-repeat="item in megaMenu">{{item.name}}</menu-tabs></parentmenu-tabs><parentmenu-tabs sub-menu="true" ng-show="activeClickMenu.x.active" menu-items="activeClickMenu.x.subItems"><menu-tabs sub-menu="true" menu-item="subItem" ng-repeat="subItem in activeClickMenu.x.subItems" active-menu="activeClickSubMenu.x" sub-item-active="{{subItem.active}}"><a ng-href="{{subItem.url}}">{{subItem.name}}</a></menu-tabs></parentmenu-tabs><div class="sub__menu" ng-show="activeClickSubMenu.x.active" ng-mouseleave="activeClickSubMenu.x.active=\'false\'"><menu-tabs menu-item="subItem" ng-repeat="subItem in activeClickSubMenu.x.subChildItems" ng-show="activeClickSubMenu.x.active"><p class="title">{{subItem.title}}</p><div att-links-list=""><a att-links-list-item="" ng-repeat="tabValue in subItem.value track by $index" href="{{tabValue.url}}">{{tabValue.value}}</a></div></menu-tabs></div> </parent-tab>', $scope);
		alert(document.body.offsetHeight);
		markUp.scrollHeight = 1500;
		var list = markUp.children();
        var firstItem = list.children().eq(0);
		var firstchildItem = firstItem.children().children().eq(1);
        firstchildItem.click();
		var secondItem=list.children().eq(1);
		var secondchildItem = secondItem.children().children().eq(0);
		secondchildItem.click();
		$window.scrollTo(0,700);
    });		
});


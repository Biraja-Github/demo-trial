angular.module('att.abs.megaMenu', [])
		.directive('parentTab',[ function() {
			return {
                restrict: 'EA',
                scope: {
					menuItems:'=',
					activeSubMenu:'=',
					activeMenu:'='
                },
				controller: ['$scope',function($scope){
					$scope.megaMenu=$scope.menuItems;
					$scope.megaMenuTab;
					$scope.megaMenuHoverTab;
					this.setMenu=function(index){
						$scope.menuItems=$scope.megaMenu;
						for(var i=0; i<$scope.menuItems.length; i++){
							if($scope.menuItems[i].active == true){							
								$scope.activeMenu=$scope.menuItems[i];
							};
						};
						this.setSubMenuStatus(false);
						
						$scope.$apply();
					};	
					this.setActiveMenu=function(){
					if(!($scope.megaMenuTab=="undefined" || $scope.megaMenuTab==null)){
						$scope.menuItems=[$scope.megaMenuTab];
						$scope.activeMenu={};
						$scope.activeSubMenu=$scope.megaMenuTab;
						this.setSubMenuStatus(true);				
					}
					else{
						for(var i=0; i<$scope.menuItems.length; i++){
							($scope.menuItems[i].active = false);
							if($scope.menuItems[i].subItems)
							for(var j=0; j<$scope.menuItems[i].subItems.length; j++){
									$scope.menuItems[i].subItems[j].active = false;	
								};
						};
						$scope.menuItems=$scope.megaMenu;
					}	
					$scope.$apply();	
					};
					var checkSubMenuStatus = false;
					
					this.setSubMenuStatus = function(value){
						checkSubMenuStatus = value;
					};
					this.getSubMenuStatus = function(){
						return checkSubMenuStatus;
					};
					this.setActiveMenuTab=function(tab){
					$scope.megaMenuTab=tab;
					};
					this.setActiveMenuHoverTab=function(tab){
					$scope.megaMenuHoverTab=tab;
					};
					this.setActiveSubMenuTab=function(){
					$scope.megaMenuTab=$scope.megaMenuHoverTab;
					};
					this.resetMenuTab=function(){
					$scope.megaMenuTab='undefined';
					};
				}]
			}
		 }])
		.directive('parentmenuTabs',[ function() {
			return {
                restrict: 'EA',
                transclude: true,
                replace: true,
                scope: {
					megaMenu:'@',
					menuItems:'='
                },
				controller: ['$scope',function($scope){
					this.getMenu=function(){
						return $scope.menuItems;
					};
					this.setMenu=function(menuItem){
						 $scope.menuItems=menuItem;
					};					
				}],
				templateUrl: 'app/scripts/ng_js_att_tpls/megaMenu/parentmenuTab.html'
				
			}
				
		 }])
	   .directive('menuTabs',["$window","$document",  function(win,$document) {
            return {
                restrict: 'EA',
                transclude: true,
                replace: true,
				require: ['^parentTab', '^?parentmenuTabs'],
                scope: {
                    activeMenu:"=",
                    menuItem: "=",
					subMenu: "@",
					subItemActive: "@"
                },
				templateUrl:function(element, attrs) {
                        if(attrs.megaMenu){
                            return 'app/scripts/ng_js_att_tpls/megaMenu/menuTab.html';
                        }
                        else{
                            return 'app/scripts/ng_js_att_tpls/megaMenu/submenuTab.html';
                        }
                    },
                link: function(scope, elem, attr,ctrl) {
					var parentCtrl = ctrl[0];
					var parentmenuCtrl = ctrl[1];
					scope.clickInactive=true;
					scope.showHoverChild = function(e){		
					scope.clickInactive=false;
					scope.hoverChild=ctrl[0].getSubMenuStatus();	
						if(e.type=="mouseover" && ctrl[0].getSubMenuStatus())
						{
							scope.showChildren(e);
						}					
					}
					
                    scope.showChildren = function(e){
						scope.parentMenuItems=parentmenuCtrl.getMenu();
						for(var i=0; i<scope.parentMenuItems.length; i++){
							scope.parentMenuItems[i].active = false;
							if(scope.parentMenuItems[i].subItems){							
								for(var j=0; j<scope.parentMenuItems[i].subItems.length; j++){
									scope.parentMenuItems[i].subItems[j].active = false;	
								};
							};
							scope.clickInactive=true;
						};
						scope.menuItem.active = true;
						scope.activeMenu=scope.menuItem;
						e.stopPropagation();
					};
					scope.$watch("subItemActive",function(value){
						if(value=="true" && scope.subMenu=='true'){
						parentCtrl.setActiveMenuHoverTab(scope.menuItem);	
						}
					});
					
					scope.showMenuClick=function(){
						parentCtrl.setActiveMenuTab(scope.menuItem);		
					};
					scope.showSubMenuClick=function(){
						parentCtrl.setActiveSubMenuTab();		
					};
					scope.resetMenu=function(){
						parentCtrl.resetMenuTab();		
					};
					
					function debounce(method, delay) {
						clearTimeout(method._tId);
						method._tId= setTimeout(function(){
							parentCtrl.setMenu();
						}, delay);
					}
					function debounce1(method, delay) {
						clearTimeout(method._tId);
						method._tId= setTimeout(function(){
							parentCtrl.setActiveMenu();
						}, delay);
					}
					$document.bind('scroll', function() {
						if(win.pageYOffset===0){
							debounce(parentCtrl.setMenu, 100);
						}
						else if(win.pageYOffset>1 && win.pageYOffset<1500){
							debounce1(parentCtrl.setActiveMenu, 100);
						}
					});
				}
            };
        }]);
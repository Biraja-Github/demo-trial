var megaMenuCtrl = function($scope) {
				
	$scope.activeClickSubMenu={};
	$scope.activeClickMenu={};
	$scope.megaMenu = [
        {
            name: "Manage",
            subItems: [
                {
				name: "Account",
				subChildItems:[{
					title:"Alarms",
						value:[
						{value:"View All Alarms",
							url:""},
							{value:"Search All Alarms",
							url:""},
							
						 ]
				},
				{title:"Notifications",
						value:[
							{value:"View All Tests",
							url:""}
						 ]
						 },
						 {title:"Trouble Tickets",
						value:[
							{value:"View All Trouble Ticket",
							url:""},
							{value:"Create a Trouble Ticket",
							url:""}
						 ]
						 }
				
				]	
				},
                {name: "Network",
				subChildItems:[{title:"Trouble Tickets",
						value:[
							{value:"View All Trouble Ticket",
							url:""},
							{value:"Create a Trouble Ticket",
							url:""}
						 ]
						 }]	
				}
            ]
        },
        {
            name: "Tools",
            subItems: [
                {name: "Support",
				subChildItems:[{title:"Inventory",
						value:[
						{value:"View All Inventory",
							url:""},
							{value:"Search All Assets",
							url:""}
						 ]
						 }]	
				},
                {name: "Settings",
				subChildItems:[{title:"Tests",
						value:[
							{value:"View All Tests",
							url:""},
							{value:"Requets Tests",
							url:""}
						 ]
						 }]	
				},
                {name: "Maitenance",
				subChildItems:[{title:"Notifications",
						value:[
							{value:"View All Tests",
							url:""}
						 ]
						 }]	
				}
            ]
        },
        {
            name: "Support",
            subItems: [
                {name: "SubItem6"}
            ]
        }
    ];
	};


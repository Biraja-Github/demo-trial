xdescribe('Select', function() {
    
    var $scope, $compile;
    beforeEach(module('att.abs.select'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        scope.countries = [
            {index: 0, value: 'Select a Country', countryName: 'Select a Country', selected: 'selected'},
            {index: 1, value: 'United States of America (USA)', countryName: 'United States of America (USA)'},
            {index: 2, value: 'United Kingdom (UK)', countryName: 'United Kingdom (UK)'},
            {index: 3, value: 'Germany', countryName: 'Germany'},
            {index: 4, value: 'Italy', countryName: 'Italy'},
            {index: 5, value: 'Canada', countryName: 'Canada'}
        ];               
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
   
    it("should create number of dropdown options as provided in data list", function() {                    
        var countryList = compileElement('<div class="form-field" att-select="countries" ng-model="selectValue" show-input-filter="false"></div>', $scope);        
        expect(countryList.find('select').find('option').length).toBe(6);
        expect(countryList.find('select').find('option')[0].innerHTML).toBe('Select a Country');
        expect(countryList.find('select').find('option')[1].innerHTML).toBe('United States of America (USA)');
        expect(countryList.find('select').find('option')[2].innerHTML).toBe('United Kingdom (UK)');
        expect(countryList.find('select').find('option')[3].innerHTML).toBe('Germany');
        expect(countryList.find('select').find('option')[4].innerHTML).toBe('Italy');
        expect(countryList.find('select').find('option')[5].innerHTML).toBe('Canada');       
    });    

    it("Initially only item marked 'selected:selected' in list must be selected", function() {                    
        var countryList = compileElement('<div class="form-field" att-select="countries" ng-model="selectValue" show-input-filter="false"></div>', $scope);                
        expect(countryList.find('select').find('option[selected]')[0].innerHTML).toBe('Select a Country');        
    });
    
    it("Selected item must have a tick mark next to it", function() {                    
        var countryList = compileElement('<div class="form-field" att-select="countries" ng-model="selectValue" show-input-filter="false"></div>', $scope);                
        expect(countryList.find('ul').find('li')).toHaveClass('select2-result-current');        
    });        
});


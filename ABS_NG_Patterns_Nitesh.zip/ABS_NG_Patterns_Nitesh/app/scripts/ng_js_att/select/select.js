angular.module('att.abs.select', ['att.abs.utilities', 'att.abs.position', 'att.abs.utilities'])

.directive('attSelect', ["$document", "$filter", "$isElement", '$documentBind', function($document,$filter,$isElement,$documentBind){
    return{
        restrict: 'A',
        scope:{cName: '=attSelect'},
        transclude: false,
        replace: false,
        require:'ngModel',
        templateUrl: 'app/scripts/ng_js_att_tpls/select/select.html',
        link: function(scope, element, attr, ctrl) {
            scope.selectedIndex = 0;
            scope.selectedOption = attr.placeholder;
            scope.isDisabled = false;
            scope.className = "select2-match";

            if(attr.placeholderAsOption === "false")
            {
                scope.selectMsg = "";
            }
            else
            {
                scope.selectMsg = attr.placeholder;
            }

            if(attr.showInputFilter === "true")
            {scope.showSearch = true;}
            else
            {scope.showSearch = false;}

            scope.showDropdown = function(){
                if(!(attr.disabled)){
                    scope.showlist = !scope.showlist;
                }
            };

            scope.dofilter = function(e){
                if(scope.showSearch === false)
                {
                    if ([8, 9, 13,16,17,18, 27, 37, 38, 39, 40].indexOf(e.which) > -1)
                    {
                        if(scope.title === "")
                        {
                            scope.showlist = false;
                        }
                        scope.title = "";
                    }
                    else
                    {
                        scope.showlist = true;
                        scope.title = scope.title ? scope.title + String.fromCharCode(e.which):String.fromCharCode(e.which);
                    }
                }
            };

            scope.selectOption = function(sItem,sIndex){
                if(sIndex === "-1"){
                   scope.selCategory = "";
                   ctrl.$setViewValue("");
                }
                else
                {
                    scope.selCategory = scope.cName[sIndex];
                    ctrl.$setViewValue(scope.selCategory);
                }
                scope.selectedOption = sItem;
                scope.showlist = false;
                scope.title = "";
            };

           /* element.bind('mouseleave', function(){
                scope.showlist = false;
            });*/

            if(attr.disabled)
            {
               scope.isDisabled = true;
            }

            scope.updateSelection = function(sItem)
            {
                scope.selectedOption = sItem;
                scope.showlist = false;
                scope.title = "";
            };

            scope.$watch('selCategory',function(value)
            {
                if(value){
                    scope.updateSelection(value.title);
                };
            });

            ctrl.$viewChangeListeners.push(function(){
                scope.$eval(attr.ngChange);
            });

            ctrl.$render = function(){
                scope.selCategory = ctrl.$viewValue;
            };

            var outsideClick = function(e){
                var isElement = $isElement(angular.element(e.target), element, $document);
                if(!isElement) {
                    scope.showlist = false;
                    scope.$apply();
                }
            };

            $documentBind.click('showlist', outsideClick, scope);
        }
    };
}])
.directive('textDropdown', ['$document', '$isElement', '$documentBind', function($document,$isElement,$documentBind) {
    return {
        restrict: 'EA',
        replace: true,              
        scope: {
            actions: '=actions',
            defaultAction: '=defaultAction',
            onActionClicked: '=?'

        },
        templateUrl : 'app/scripts/ng_js_att_tpls/select/textDropdown.html',
        link: function(scope, element, attrs) {

            var toggle = scope.toggle = function (show) {
                if(show === true || show === false) {
                    scope.isActionsShown = show;
                } else {
                    scope.isActionsShown = !scope.isActionsShown;
                }
            };

            if (scope.defaultAction != undefined || scope.defaultAction != '')
            {
                for (var act in scope.actions)
                {
                    if (scope.actions[act] === scope.defaultAction)
                    {
                        scope.currentAction = scope.actions[act];
                        scope.isActionsShown = false;
                        break;
                    }
                }
            } else {
                scope.currentAction = scope.actions[0];
            }

            scope.toggleActionDropdown = function($event, action) {
                toggle();
                scope.currentAction = action;
            };

            scope.chooseAction = function($event, action){
                toggle();
                scope.currentAction = action;

                if (angular.isFunction(scope.onActionClicked))
                {
                    scope.onActionClicked(action);
                }

            }

            scope.isCurrentAction = function(action) {
                return (action === scope.currentAction);
            };

            var outsideClick = function(e) {
                var isElement = $isElement(angular.element(e.target), element, $document);
                
                if(!isElement) {
                    toggle(false);
                    scope.$apply();
                }

            };

            $documentBind.click('isActionsShown', outsideClick, scope);
            
        }
    };
}]);

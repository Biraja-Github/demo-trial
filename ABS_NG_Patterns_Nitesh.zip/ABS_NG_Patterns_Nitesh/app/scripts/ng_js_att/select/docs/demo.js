var selectController = function($scope) {
    $scope.countries = [        
        {index: 0, value: 'United States of America (USA)', title: 'United States of America (USA)'},
        {index: 1, value: 'United Kingdom (UK)', title: 'United Kingdom (UK)'},
        {index: 2, value: 'Germany', title: 'Germany'},
        {index: 3, value: 'Italy', title: 'Italy'},
        {index: 4, value: 'Canada', title: 'Canada'}
    ]; 
    
    
    $scope.dXXX = [        
        {index: 0, value: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1', title: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1'},
        {index: 1, value: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx2', title: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx2'},
        {index: 2, value: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3', title: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx3'}
    ]; 
    
    $scope.dXX = [        
        {index: 0, value: 'xxxxxxxxxxxxxxxxxxxx1', title: 'xxxxxxxxxxxxxxxxxxxx1'},
        {index: 1, value: 'xxxxxxxxxxxxxxxxxxxx2', title: 'xxxxxxxxxxxxxxxxxxxx2'},
        {index: 2, value: 'xxxxxxxxxxxxxxxxxxxx3', title: 'xxxxxxxxxxxxxxxxxxxx3'}
    ];
    
    $scope.dXVI = [        
        {index: 0, value: 'xxxxxxxxxxxxxxxx1', title: 'xxxxxxxxxxxxxxxx1'},
        {index: 1, value: 'xxxxxxxxxxxxxxxx2', title: 'xxxxxxxxxxxxxxxx2'},
        {index: 2, value: 'xxxxxxxxxxxxxxxx3', title: 'xxxxxxxxxxxxxxxx3'}
    ];
    
    $scope.dXII = [        
        {index: 0, value: 'xxxxxxxxxxxx1', title: 'xxxxxxxxxxxx1'},
        {index: 1, value: 'xxxxxxxxxxxx2', title: 'xxxxxxxxxxxx2'},
        {index: 2, value: 'xxxxxxxxxxxx3', title: 'xxxxxxxxxxxx3'}
    ];
    
    $scope.dZIP = [        
        {index: 0, value: '0001', title: '0001'},
        {index: 1, value: '0002', title: '0002'},
        {index: 2, value: '0003', title: '0003'}
    ];
    
    $scope.dDAY = [        
        {index: 0, value: '01', title: '01'},
        {index: 1, value: '02', title: '02'},
        {index: 2, value: '03', title: '03'}
    ];
    
    //To initially select a value in dropdown simply pass it to variable being assigned to ng-model of control instance.
    $scope.selectValue4 = $scope.countries[3];    
    $scope.dXXX1 = $scope.dXXX[0];
    $scope.dXXX2 = $scope.dXXX[0];
    $scope.dXX1 = $scope.dXX[0];
    $scope.dXVI1 = $scope.dXVI[0];
    $scope.dXII1 = $scope.dXII[0];
    $scope.dZIP1 = $scope.dZIP[0];
    $scope.dDAY1 = $scope.dDAY[0];
    
    $scope.setOption = function()
    {
        var itm = Math.floor((Math.random() * $scope.countries.length));
        $scope.selectValue41 = $scope.countries[itm];
    };
    
    $scope.actions=[
        "action 1",
        "action 2"
    ];

    $scope.actionClicked = function(action){
        console.log(action);
    };
    
    $scope.funcUpdate = function(){        
        console.log("Do something on selection change");
    };
};
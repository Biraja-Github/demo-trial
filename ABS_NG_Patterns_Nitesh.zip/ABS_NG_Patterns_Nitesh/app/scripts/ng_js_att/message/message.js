angular.module('att.abs.message', [])

.directive('attMessages', [function() {
    return {
        restrict: 'EA',
        controller: ['$scope', '$element', '$attrs', function($scope, $element, $attrs) {
            $scope.messageType;
            $scope.$watchCollection($attrs['for'], function(errors) {
                for (var key in errors) {
                    if (errors[key] === true) {
                        $scope.error = key;
                        break;
                    } else {
                        $scope.error = null;
                    }
                };
                if ($scope.error === null) {
                    $scope.messageType = null;
                    $element.removeAttr('message-type');
                }
            });
            this.setMessageType = function(messageType) {
                $scope.messageType = messageType;
            };
            $scope.$watch('messageType', function(value) {
                if (angular.isDefined(value) && value !== null) {
                    $element.attr('message-type', value);
                }
            });
        }]
    };
}])

.directive('attMessage', [function() {
    return {
        restrict: 'EA',
        scope: {},
        require: '^attMessages',
        link: function(scope, elem, attr, ctrl) {
            scope.when = attr.when || attr.attMessage;
            scope.type = attr.type;
            elem.css({display: 'none'});
            scope.$parent.$watch('error', function(value) {
                if (value === scope.when) {
                    elem.css({display: 'block'});
                    ctrl.setMessageType(scope.type);
                } else {
                    elem.css({display: 'none'});
                }
            });
        }
    };
}]);
describe('checkbox', function() {
    var $scope, $compile;
    beforeEach(module('att.abs.checkbox'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
    it("the checkbox will be checked", function() {
        $scope.checkboxValue = {
            "JAVA": true
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.JAVA" att-checkbox>', $scope);
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');
    });

    it("the checkbox will remain unchecked", function() {
        $scope.checkboxValue = {
            "NG": false
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.NG" att-checkbox>', $scope);
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--on');
    });

    it("should toggle the value when clicked", function() {
        $scope.checkboxValue = {
            "JAVA": true
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.JAVA" att-checkbox>', $scope);
        checkBox.parent().click();
//        console.log($scope.checkboxValue.JAVA);
        expect($scope.checkboxValue.JAVA).toEqual(false);
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--on');

        $scope.checkboxValue = {
            "JAVA": false
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.JAVA" att-checkbox>', $scope);
        checkBox.parent().click();
        expect($scope.checkboxValue.JAVA).toEqual(true);
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');
    });

    it("should toggle the value when clicked", function() {
        $scope.checkboxValue = {
            "NG": false
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.NG" att-checkbox>', $scope);
        checkBox.parent().click();
        expect($scope.checkboxValue.NG).toEqual(true);
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');

        $scope.checkboxValue = {
            "NG": true
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" ng-model="checkboxValue.NG" att-checkbox>', $scope);
        checkBox.parent().click();
        expect($scope.checkboxValue.NG).toEqual(false);
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--on');
    });
      it("should check the header checkbox, when all the child checkboxes are unchecked", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":true,
            "B":true,
            "C":true     
        };
        $scope.$digest();
        compileElement('<input type="checkbox" ng-model="checkboxGroup1.A" att-checkbox>', $scope);
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope); 
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');
    });
    it("should uncheck the header checkbox, when all the child checkboxes are unchecked", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":false,
            "B":false,
            "C":false     
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope); 
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--on');
    });
    it("should make the header checkbox in an indterminate state, when some child checkboxes are uncheck and some as check", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":true,
            "B":false,
            "C":false     
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope); 
        expect(checkBox.parent()).toHaveClass('att-checkbox--indeterminate');
    });
     it("should make the header checkbox in an indterminate state, when some child checkboxes are uncheck and some as check", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":false,
            "B":true,
            "C":false     
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope); 
        expect(checkBox.parent()).toHaveClass('att-checkbox--indeterminate');
    });
    it("should check the header checkbox", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":true,
            "B":true,
            "C":true     
        };
        $scope.checkboxState = "all";
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope); 
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--indeterminate');
    });
     it("should check and uncheck the group checkboxes when clicked on header checkbox", function() {
        $scope.checkboxGroup1 = 
        {     
            "A":false,
            "B":false,
            "C":false     
        };
        $scope.$digest();
        var checkBox = compileElement('<input type="checkbox" checkbox-group="checkboxGroup1">', $scope);
        checkBox.parent().click();
        var checkBoxA = compileElement('<input type="checkbox" ng-model="checkboxGroup1.A" att-checkbox>', $scope);
        var checkBoxB = compileElement('<input type="checkbox" ng-model="checkboxGroup1.B" att-checkbox>', $scope);
        var checkBoxC = compileElement('<input type="checkbox" ng-model="checkboxGroup1.C" att-checkbox>', $scope);
        expect(checkBox.parent()).toHaveClass('att-checkbox--on');
        expect(checkBoxA.parent()).toHaveClass('att-checkbox--on');
        expect(checkBoxB.parent()).toHaveClass('att-checkbox--on');
        expect(checkBoxC.parent()).toHaveClass('att-checkbox--on');
        (checkBox.parent()).click();
        expect(checkBox.parent()).not.toHaveClass('att-checkbox--on');
        expect(checkBoxA.parent()).not.toHaveClass('att-checkbox--on');
        expect(checkBoxB.parent()).not.toHaveClass('att-checkbox--on');
        expect(checkBoxC.parent()).not.toHaveClass('att-checkbox--on');
        
    });
});

describe('radio', function() {
    var $scope, $compile;
    beforeEach(module('att.abs.checkbox'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
    
    it("the checkbox will be checked when you set default directive attribute value", function() {
        $scope.radioValue = "male";
        $scope.$digest();
        var radio = compileElement('<input name="radio" type="radio" ng-model="radioValue" att-radio="male">', $scope);
        expect(radio.parent()).toHaveClass('att-radio--on');
    });

    it("the checkbox will not be checked when you set other value instead default directive attribute value", function() {
        $scope.radioValue = "female";
        $scope.$digest();
        var radio = compileElement('<input name="radio" type="radio" ng-model="radioValue" att-radio="male">', $scope);
        expect(radio.parent()).not.toHaveClass('att-radio--on');
    });

    it("the checkbox will not be checked if you don't set any default directive attribute value", function() {
        $scope.radioValue;
        $scope.$digest();
        var radio = compileElement('<input name="radio" type="radio" ng-model="radioValue" att-radio="male">', $scope);
        expect(radio.parent()).not.toHaveClass('att-radio--on');
    });

    it("it should toggle propely according to it's previous state", function() {
        $scope.radioValue = "male";
        var radio = compileElement('<input name="radio" type="radio" ng-model="radioValue" att-radio="male"><input name="radio" type="radio" ng-model="radioValue" att-radio="female">', $scope);
        expect(radio.eq(0).parent()).toHaveClass('att-radio--on');
        expect(radio.eq(1).parent()).not.toHaveClass('att-radio--on');

        radio.eq(1).click();
        $scope.radioValue = "female";
        $scope.$digest();
        expect(radio.eq(0).parent()).not.toHaveClass('att-radio--on');
        expect(radio.eq(1).parent()).toHaveClass('att-radio--on');
    });
});


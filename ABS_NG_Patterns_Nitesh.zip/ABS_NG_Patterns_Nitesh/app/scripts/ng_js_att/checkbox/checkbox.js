angular.module('att.abs.checkbox', [])

.directive('attCheckbox', ['$compile',function ($compile) {
    return {
        scope: {},
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attribute, ctrl) {
            var ngCtrl = ctrl;
            
            element.css({display:'none'});
            element.wrap($compile('<div tabindex="0" role="checkbox" att-accessibility-click="13,32" class="att-checkbox"></div>')(scope));
            element.parent().append('<div class="att-checkbox__indicator"></div>');
            element.parent().attr("title", attribute.title);

            scope.$parent.$watch(attribute.ngModel, function (value) {
                scope.modelValue = value;
                if (value === true) {
                    element.parent().addClass('att-checkbox--on');
                    element.parent().attr("aria-checked", true);
                } else {
                    element.parent().removeClass('att-checkbox--on');
                    element.parent().attr("aria-checked", false);
                }
            });

            element.parent().bind('click', function (evt) {
                if (scope.disabled !== true) {
                    if (scope.modelValue === true) {
                        ngCtrl.$setViewValue(false);
                        scope.$apply();
                    } else {
                        ngCtrl.$setViewValue(true);
                        scope.$apply();
                    }
                    evt.preventDefault();
                }
            });

            attribute.$observe('disabled', function(val) {
                scope.disabled = val;
                if(val === true) {
                    element.parent().addClass('att-checkbox--disabled');
                    element.parent().attr("tabindex","-1");
                } else {
                    element.parent().removeClass('att-checkbox--disabled');
                    element.parent().attr("tabindex","0");
                }
            });
        }
    };
}])

.directive('attRadio', ['$compile',function ($compile) {
    return {
        scope: {},
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attr, ctrl) {
            var ngCtrl = ctrl;            
            element.wrap($compile('<div tabindex="0" role="radio" att-accessibility-click="13,32" class="att-radio"></div>')(scope));
            element.parent().append('<div class="att-radio__indicator"></div>');
            element.parent().attr("title", attr.title);
            element.attr("tabindex","-1");
            
            scope.$parent.$watch(attr.ngModel, function (value) {
                scope.modelValue = value;
                if (value !== attr.attRadio) {
                    element.parent().removeClass('att-radio--on');
                    element.parent().attr("aria-checked", false);
                } else {
                    element.parent().addClass('att-radio--on');
                    element.parent().attr("aria-checked", true);
                }
            });

            element.parent().bind('click', function () {
                if (scope.disabled !== true) {
                    ngCtrl.$setViewValue(attr.attRadio);
                    scope.$apply();
                }
            });

            attr.$observe('disabled', function (val) {
                scope.disabled = val;
                if (val === true) {
                    element.parent().addClass('att-radio--disabled');
                    element.parent().attr("tabindex","-1");
                } else {
                    element.parent().removeClass('att-radio--disabled');
                    element.parent().attr("tabindex","0");
                }
            });
        }
    };
}])

.directive('checkboxGroup', ['$compile',function($compile) {
    return {
        scope:
            {
                checkboxGroup: "=",
                checkboxGroupValue: "=?"
            },
        restrict: 'A',  
        link: function(scope, element, attribute, ctrl)
            {
                scope.checkboxState = 'none';
                scope.checkboxGroupValue="indeterminate";
                element.css({display:'none'});
                element.wrap($compile('<div tabindex="0" role="checkbox" att-accessibility-click="13,32" class="att-checkbox"></div>')(scope));
                element.parent().append('<div class="att-checkbox__indicator"></div>');
                element.parent().attr("title", attribute.title);
                scope.$watch('checkboxState', function(val) {
                    if (val === 'all') {
                        element.parent().addClass('att-checkbox--on');
                        element.parent().removeClass('att-checkbox--indeterminate');
                        element.parent().attr("aria-checked", true);
                    }
                    else if (val === 'none') {
                        element.parent().removeClass('att-checkbox--on');
                        element.parent().removeClass('att-checkbox--indeterminate');
                        element.parent().attr("aria-checked", false);
                    }
                    else if (val === 'indeterminate') {
                        element.parent().removeClass('att-checkbox--on');
                        element.parent().addClass('att-checkbox--indeterminate');
                        element.parent().attr("aria-checked", true);
                    }
                });

                element.parent().bind('click', function(evt)
                {
                    if (element.parent().hasClass('att-checkbox--on')) {
                            element.parent().removeClass('att-checkbox--on');
                            for (var keys in scope.checkboxGroup) {
                                if (scope.checkboxGroup.hasOwnProperty(keys)) {
                                    scope.$apply(function(){
                                        scope.checkboxGroup[keys] = false;
                                    });
                                }
                            };
                            } 
                    else {
                        element.parent().addClass('att-checkbox--on');
                        for (var keys in scope.checkboxGroup) {
                            if (scope.checkboxGroup.hasOwnProperty(keys)) {
                                scope.$apply(function(){
                                    scope.checkboxGroup[keys] = true;
                            });
                            }
                        };
                    }
                    evt.preventDefault();
                });
                scope.$watch('checkboxGroupValue', function (value) {
                    if (value === false) {
                            element.parent().removeClass('att-checkbox--on');
                            for (var keys in scope.checkboxGroup) {
                                if (scope.checkboxGroup.hasOwnProperty(keys)) {
                                        scope.checkboxGroup[keys] = false;
                                }
                            };
                            } 
                    else if (value === true){
                        element.parent().addClass('att-checkbox--on');
                        for (var keys in scope.checkboxGroup) {
                            if (scope.checkboxGroup.hasOwnProperty(keys)) {
                                    scope.checkboxGroup[keys] = true;
                            }
                        };
                    }
                });
            scope.$watch('checkboxGroup', function()
            {
                var countTrue = 0;
                var countFalse = 0;
                var count = 0;
                for (var keys in scope.checkboxGroup) {
                    if (scope.checkboxGroup.hasOwnProperty(keys)) {
                        count = count + 1;
                        if (scope.checkboxGroup[keys] === true) {
                            countTrue = countTrue + 1;
                        }
                        else if (scope.checkboxGroup[keys] === false) {
                            countFalse = countFalse + 1;
                        }
                    }
                };
                if (count === countTrue) {
                    scope.checkboxState = "all";
                     scope.checkboxGroupValue=true;
                }
                else if (count === countFalse) {
                    scope.checkboxState = "none";
                    scope.checkboxGroupValue=false;
                }
                else {
                    scope.checkboxState = "indeterminate";
                    scope.checkboxGroupValue="indeterminate";
                }
                }, true);
        }
    };
}]);

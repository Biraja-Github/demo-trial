var checkboxController = function ($scope) {
    $scope.checkboxValue = {
        "JAVA": true,
        "NG": false
    };
	$scope.radioValue = 'male';
	$scope.radioButtons = [{'title':'Default','id':'Default'},
	{'title':'Disabled','id':'Disabled'},
	{'title':'Warning','id':'Warning'},
	{'title':'Error-incorrect user/pass','id':'Error'}];
    $scope.radioButtons.id = 'Default';
};

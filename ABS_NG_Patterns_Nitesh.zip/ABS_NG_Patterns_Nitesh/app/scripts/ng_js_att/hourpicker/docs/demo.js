var HourpickerCtrl = function($scope) {

    var fromValue = [
        {index: 0, value: '10.00 am'},
        {index: 1, value: '11.00 am'},
        {index: 2, value: '12.00 am'},
        {index: 3, value: '1.00 pm'}
    ];

    var toValue = [
        {index: 0, value: '5.00 pm'},
        {index: 1, value: '6.00 pm'},
        {index: 2, value: '7.00 pm'},
        {index: 3, value: '8.00 pm'}
    ];


    var preselectValue = [{"day": "Mon", "FromTime": "11.00 am", "ToTime": "6.00 pm"}, {"day": "Wed", "FromTime": "12.00 am", "ToTime": "7.00 pm"}];
    // var preselectValue =  {"day":"Mon - Fri 8AM - 5PM"};

    $scope.optionValues = [
        {
            value: 'Mon - Fri 8AM - 5PM'
        },
        {
            value: 'Mon - Fri Anytime'
        },
        {
            value: '24/7'
        },
        {
            value: 'Custom',
            fromtime: fromValue,
            totime: toValue,
            preselect: preselectValue
        }
    ];
};

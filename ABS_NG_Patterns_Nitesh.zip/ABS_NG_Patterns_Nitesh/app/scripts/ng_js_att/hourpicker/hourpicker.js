'use strict';
angular.module('att.abs.hourpicker', ['att.abs.utilities'])

        .constant('hourpickerConfig', {
            days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            customOption: 'Custom'
        })

        .controller('hourPickerController', ['$scope', function($scope) {

                $scope.options = [];
                this.setOptions = function(value, fromtime, totime, preselect) {
                    
                    $scope.options.push(value);
                    if (preselect !== undefined) {
                        $scope.preselect = preselect;
                    }
                    
                    if (fromtime !== undefined) {
                        $scope.fromtime = fromtime;
                        for (var daycount in $scope.days) {
                            $scope.FrtimeList[$scope.days[daycount]] = {};
                            $scope.FrtimeList[$scope.days[daycount]].value = fromtime[0].value;
                            $scope.selectedFromOption[$scope.days[daycount]] = fromtime[0].value;
                        }
                    }
                    if (totime !== undefined) {
                        $scope.totime = totime;
                        for (var daycount in $scope.days) {
                            $scope.TotimeList[$scope.days[daycount]] = {};
                            $scope.TotimeList[$scope.days[daycount]].value = totime[0].value;
                            $scope.selectedToOption[$scope.days[daycount]] = totime[0].value;
                        }
                    }
                };
            }])

        .directive('attHourpickerOption', [function() {
                return {
                    restrict: 'EA',
                    require: '^attHourpicker',
                    scope: {
                        option: "=option",
                        fromtime: "=fromtime",
                        totime: "=totime",
                        preselect: "=preselect"
                    },
                    link: function(scope, element, attr, ctrl) {
                        ctrl.setOptions(scope.option, scope.fromtime, scope.totime, scope.preselect);
                    }
                };
            }])

        .directive('attHourpicker', ["hourpickerConfig", "$document", "$log", "$documentBind", function(hourpickerConfig, $document, $log, $documentBind) {
                return{
                    require: 'ngModel',
                    restrict: 'EA',
                    controller: 'hourPickerController',
                    transclude: true,
                    scope:{
                      model: "=ngModel"
                    },
                    templateUrl: 'app/scripts/ng_js_att_tpls/hourpicker/hourpicker.html',
                    link: function(scope, element, attr, ctrl) {
                        var flag = false;
                        scope.isFromDropDownOpen = false;
                        scope.isToDropDownOpen = false;
                        var dropDownOpenValue = "";
                        var custTime = {};
                        scope.days = hourpickerConfig.days;
                        scope.daysList = {};
                        scope.FrtimeList = {};
                        scope.FrtimeListDay = {};
                        scope.TotimeListDay = {};
                        scope.selectedFromOption = {};
                        scope.selectedToOption = {};
                        scope.TotimeList = {};
                        scope.selectedIndex = 0;
                        scope.selectedOption = "Select from list";
                        scope.customTime = [];

                        scope.$watch('selCategory', function(value) {
                            if (value){
                                ctrl.$setViewValue(value);                                
                            }
                        });
                        scope.$watch('model', function(value,oldValue) {
                            if (value && oldValue && angular.toJson(value) !== angular.toJson(oldValue)) {
                               scope.updateData(value)
                            }});
                        
                        scope.updateData = function(value)
                        {                        
                        if (value.constructor === Array) {
                                    scope.showDaysSelector = true;
                                    scope.selectedOption = hourpickerConfig.customOption;
                                    for (var arry in value) {
                                        var day = value[arry].day;
                                        scope.daysList[day] = true;

                                        for (var fromcount in scope.fromtime) {
                                            if (scope.fromtime[fromcount].value === value[arry].FromTime) {
                                                scope.FrtimeList[day].value = scope.fromtime[fromcount].value;
                                                scope.selectedFromOption[day] = scope.FrtimeList[day].value;
                                            }
                                        }
                                        for (var tocount in scope.totime) {
                                            if (scope.totime[tocount].value === value[arry].ToTime) {
                                                scope.TotimeList[day].value = scope.totime[tocount].value;
                                                scope.selectedToOption[day] = scope.TotimeList[day].value;
                                            }
                                        }
                                        scope.addSelectedValue(day, value[arry].FromTime, value[arry].ToTime);
                                        //for IE8 Fix
                                        if (parseInt(arry) + 1 === value.length) {
                                            break;
                                        }
                                    }
                                }
                                else {
                                    scope.selectOption(value.day);
                                }
                            }
                            
                        scope.$watch('preselect', function(value) {
                            if (value !== undefined) {
                                
                                if(scope.options){
                                    value = scope.validatePreselectData(value);                                    
                                }
                                if (value === "") {
                                    return;
                                }
                                scope.updateData(value);                               
                            }
                        });

                        scope.validatePreselectData = function(value)
                        {
                            if (value.constructor === Array) {
                                for (var arry in value) {
                                    var day = value[arry].day;
                                    var isDayFound = false;
                                    var isFrmFound = false;
                                    var isToFound = false;
                                    for (var daycount in scope.days) {
                                        if (scope.days[daycount] === day) {
                                            isDayFound = true;
                                            break;
                                        }
                                    }
                                    if (!isDayFound) {
                                        value.splice(arry, 1);
                                        continue;
                                    }
                                    for (var fromcount in scope.fromtime) {
                                        if (scope.fromtime[fromcount].value === value[arry].FromTime) {
                                            isFrmFound = true;
                                            break;
                                        }
                                    }
                                    if (!isFrmFound) {
                                        value[arry].FromTime = scope.fromtime[0].value;
                                    }
                                    for (var tocount in scope.totime) {
                                        if (scope.totime[tocount].value === value[arry].ToTime) {
                                            isToFound = true;
                                            break;
                                        }
                                    }
                                    if (!isToFound) {
                                        value[arry].ToTime = scope.totime[0].value;
                                    }
                                    //for IE8 Fix
                                    if (parseInt(arry) + 1 === value.length) {
                                        break;
                                    }
                                }
                            }
                            else {
                                var isOptionFound = false;
                                for (var optcount in scope.options) {
                                    if (scope.options[optcount] === value.day) {
                                        isOptionFound = true;
                                        break;
                                    }
                                }
                                if (!isOptionFound) {
                                    value = "";
                                }
                            }
                            return value;
                        };

                        scope.selectPrevNextValue = function($event, arrayValues, currValue) {

                            var value;
                            var index = 0;
                            if ($event.keyCode === 38) {
                                value = -1;
                            } else if ($event.keyCode === 40) {
                                value = 1;
                            } else {
                                return currValue;
                            }

                            if (arrayValues.indexOf(currValue) !== -1) {
                                index = arrayValues.indexOf(currValue) + value;
                            } else {
                                for (var count in arrayValues) {
                                    if (arrayValues[count].value === currValue) {
                                        index = parseInt(count) + value;
                                        break;
                                    }
                                }
                            }

                            if (index === arrayValues.length) {
                                index = index - 1;
                            } else if (index === -1) {
                                index = index + 1;
                            }

                            $event.preventDefault();
                            if (arrayValues[index].value)
                                return arrayValues[index].value;
                            else
                                return arrayValues[index];
                        };

                        scope.showDropdown = function()
                        {
                            scope.showlist = !scope.showlist;
                            flag = !flag;
                        };

                        scope.showfromDayDropdown = function(value)
                        {
                            //close dropdown if any other From drop down is opened
                            for (count in scope.FrtimeListDay) {
                                if (count !== value && scope.FrtimeListDay[count] === true) {
                                    scope.FrtimeListDay[count] = false;
                                    break;
                                }
                            }
                            for (count in scope.TotimeListDay) {
                                if (scope.TotimeListDay[count] === true) {
                                    scope.TotimeListDay[count] = false;
                                    break;
                                }
                            }
                            scope.FrtimeListDay[value] = !scope.FrtimeListDay[value];
                            flag = !flag;
                            scope.showlist = false;

                            //save model value so we can close current dropdown on click of other part of the document
                            if (scope.FrtimeListDay[value]) {
                                scope.isFromDropDownOpen = true;
                                dropDownOpenValue = value;

                            } else {
                                scope.isFromDropDownOpen = false;
                            }

                        };

                        scope.showtoDayDropdown = function(value)
                        {
                            //close dropdown if any other To drop down is opened
                            for (count in scope.TotimeListDay) {
                                if (count !== value && scope.TotimeListDay[count] === true) {
                                    scope.TotimeListDay[count] = false;
                                    break;
                                }
                            }
                            for (count in scope.FrtimeListDay) {
                                if (scope.FrtimeListDay[count] === true) {
                                    scope.FrtimeListDay[count] = false;
                                    break;
                                }
                            }
                            scope.TotimeListDay[value] = !scope.TotimeListDay[value];
                            flag = !flag;
                            scope.showlist = false;

                            //save model value so we can close current dropdown on click of other part of the document
                            if (scope.TotimeListDay[value]) {
                                scope.isToDropDownOpen = true;
                                dropDownOpenValue = value;

                            } else {
                                scope.isToDropDownOpen = false;
                            }
                        };

                        scope.selectFromDayOption = function(day, value)
                        {
                            scope.selectedFromOption[day] = value;
                            scope.FrtimeList[day].value = value;
                            scope.FrtimeListDay[day] = false;
                        };

                        scope.selectToDayOption = function(day, value)
                        {
                            scope.selectedToOption[day] = value;
                            scope.TotimeList[day].value = value;
                            scope.TotimeListDay[day] = false;
                        };

                        scope.addSelectedValue = function(value, fromtime, totime)
                        {
                            if (scope.daysList[value] !== undefined && !scope.daysList[value]) {

                                for (var count = 0, len = scope.customTime.length; count < len; count++) {
                                    if (scope.customTime[count].day === value) {
                                        scope.customTime.splice(count, 1);
                                        break;
                                    }
                                }
                            }
                            else {
                                custTime["day"] = value;
                                custTime["FromTime"] = fromtime !== undefined ? fromtime : scope.FrtimeList[value].value;
                                custTime["ToTime"] = totime !== undefined ? totime : scope.TotimeList[value].value;
                                var count = 0, len = scope.customTime.length;
                                for (; count < len; count++) {
                                    if (scope.customTime[count].day === value) {
                                        scope.customTime[count].FromTime = custTime["FromTime"];
                                        scope.customTime[count].ToTime = custTime["ToTime"];
                                        break;
                                    }
                                }
                                if (count === len) {
                                    var x = angular.copy(custTime);
                                    scope.customTime.push(x);
                                }
                            }
                            scope.selCategory = scope.customTime;
                        };


                        var outsideClick = function(e) {
                            if (scope.showlist) {
                                scope.$apply(function() {
                                    scope.showlist = false;
                                });
                            }
                        };

                        $documentBind.click('showlist', outsideClick, scope);

                        var outsideClickFromDropdown = function(e) {
                            scope.$apply(function() {
                                if (scope.isFromDropDownOpen) {
                                    scope.FrtimeListDay[dropDownOpenValue] = false;
                                    scope.isFromDropDownOpen = false;
                                }
                            });
                        };

                        $documentBind.click('isFromDropDownOpen', outsideClickFromDropdown, scope);

                        var outsideClickToDropdown = function(e) {
                            scope.$apply(function() {
                                if (scope.isToDropDownOpen) {
                                    scope.TotimeListDay[dropDownOpenValue] = false;
                                    scope.isToDropDownOpen = false;
                                }
                            });
                        };

                        $documentBind.click('isToDropDownOpen', outsideClickToDropdown, scope);

                        scope.selectOption = function(sItem)
                        {

                            if (sItem === hourpickerConfig.customOption) {
                                scope.showDaysSelector = true;
                                scope.selCategory = scope.customTime;
                            } else {
                                scope.showDaysSelector = false;
                                var fromTime = /[0-9]\s?am/i.exec(sItem);
                                var toTime = /[0-9]\s?pm/i.exec(sItem);
                                scope.selCategory = {day: sItem, FromTime: fromTime === null ? 'NA' : fromTime[0], ToTime: toTime === null ? 'NA' : toTime[0]};
                            }

                            scope.showlist = false;
                            flag = false;
                            scope.selectedOption = sItem;
                        };
                    }
                };
            }]);

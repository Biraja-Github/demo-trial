xdescribe('att.abs.hourpicker', function() {
    var rootScope, $compile, element;
    beforeEach(module('att.abs.hourpicker'));
    beforeEach(module('app/scripts/ng_js_att_tpls/hourpicker/hourpicker.html'));
    beforeEach(inject(function(_$compile_, _$rootScope_) {
        $compile = _$compile_;
        rootScope = _$rootScope_;
        fromValue = [
            {index: 0, value: '10.00 am'},
            {index: 1, value: '11.00 am'},
            {index: 2, value: '12.00 am'},
            {index: 3, value: '1.00 pm'}
        ];
        toValue = [
            {index: 0, value: '5.00 pm'},
            {index: 1, value: '6.00 pm'},
            {index: 2, value: '7.00 pm'},
            {index: 3, value: '8.00 pm'}
        ];
       
    }));

    var compileElement = function() {
         rootScope.optionValues = [
            {
                value: 'Mon - Fri 8AM - 5PM',
                preselect: rootScope.preselectValue1

            },
            {
                value: 'Mon - Fri Anytime',
                preselect: rootScope.preselectValue2

            },
            {
                value: '24/7',
                preselect: rootScope.preselectValue3

            },
            {
                value: 'Custom',
                fromtime: fromValue,
                totime: toValue,
                preselect: rootScope.preselectValue4
            }
        ];
        element = angular.element(' <div att-hourpicker ng-model="selectValue3"> <att-hourpicker-option ng-repeat="option in optionValues" fromtime="option.fromtime" totime="option.totime"  preselect="option.preselect" option="option.value"></att-hourpicker-option> </div>');
        element = $compile(element)(rootScope);
        rootScope.$digest();
        return element;
    };

    it('should show/hide drop down on click of select from list', function() {
        element = compileElement();
        var innerElem = element.find('div').eq(0).eq(0).find('div').eq(2);
        element.find('a').eq(0).click();
        expect(innerElem).not.toHaveClass('ng-hide');
        element.find('a').eq(0).click();
        expect(innerElem).toHaveClass('ng-hide');
    });

    it('should show the days and time selection template on select of custom value from drop down', function() {
        element = compileElement();
        var innerEle = element.find('.customdays-width');
        element.find('li').eq(3).click();
        expect(innerEle).not.toHaveClass('ng-hide');
        element.find('li').eq(1).click();
        expect(innerEle).toHaveClass('ng-hide');
    });

    it('should select 24/7 value and update out field on select of a 24/7 value in drop down', function() {
        element = compileElement();
        element.find('li').eq(2).click();
        expect(rootScope.selectValue3.day).toBe('24/7');
    });

    it('should select First day monday selected when  first check box is selected in custom selection of time', function() {
        element = compileElement();
        element.find('input').parent().find('input').click();
        element.find('input').eq(0).parent().find('input').click();
        expect(rootScope.selectValue3[0].day).toBe('Mon');
    });

    it('should select values from drop down based on preselect value supplied', function() {
        rootScope.preselectValue1 = {"day": "Mon - Fri 8AM - 5PM", "FromTime": "8AM", "ToTime": "5PM"};
        element = compileElement();
        expect(rootScope.selectValue3.day).toBe(rootScope.preselectValue1.day);
        expect(rootScope.selectValue3.FromTime).toBe(rootScope.preselectValue1.FromTime);
        expect(rootScope.selectValue3.ToTime).toBe(rootScope.preselectValue1.ToTime);
    });


    it('should open custom day selection when preselect properties is passed', function() {
        rootScope.preselectValue4 = [{"day": "Mon", "FromTime": "10.00 am", "ToTime": "6.00 pm"}, {"day": "Wed", "FromTime": "12.00 am", "ToTime": "7.00 pm"}];
        element = compileElement();
        var innerEle = element.find('.customdays-width');
        expect(innerEle).not.toHaveClass('ng-hide');
    });

    it('should select custom values from drop down and open custom selection with selected values of day selection, when preselect properties is passed', function() {
        rootScope.preselectValue4 = [{"day": "Mon", "FromTime": "10.00 am", "ToTime": "6.00 pm"}, {"day": "Wed", "FromTime": "12.00 am", "ToTime": "7.00 pm"}];
        element = compileElement();
        expect(rootScope.selectValue3[0].day).toBe(rootScope.preselectValue4[0].day);
        expect(rootScope.selectValue3[0].FromTime).toBe(rootScope.preselectValue4[0].FromTime);
        expect(rootScope.selectValue3[0].ToTime).toBe(rootScope.preselectValue4[0].ToTime);
    });

    it('should avoid pre select attribute if supplied value is not matching with available drop down options', function() {
        rootScope.preselectValue1 = {"day": "No Matching"};
        element = compileElement();
        expect(rootScope.selectValue3).toBe(undefined);
    });

    it('should avoid records of pre select attribute if days supplied value is not matching with available days', function() {
        rootScope.preselectValue4 = [{"day": "Mon-Sat", "FromTime": "10.00 am", "ToTime": "6.00 pm"}, {"day": "Wed", "FromTime": "12.00 am", "ToTime": "7.00 pm"}];
        element = compileElement();
        expect(rootScope.selectValue3.length).toBe(1);
        expect(rootScope.selectValue3[0].day).not.toBe('Mon-Sat');
        expect(rootScope.selectValue3[0].FromTime).not.toBe('10.00 am');
        expect(rootScope.selectValue3[0].ToTime).not.toBe('6.00 pm');
    });

    it('should select first value of from time and to time drop down if no matching value is found from list of custom selection of days', function() {
        rootScope.preselectValue4 = [{"day": "Mon", "FromTime": "15.00", "ToTime": "16.00"}, {"day": "Wed", "FromTime": "12.00 am", "ToTime": "7.00 pm"}];
        element = compileElement();
        expect(rootScope.selectValue3.length).toBe(2);
        expect(rootScope.selectValue3[0].day).toBe(rootScope.preselectValue4[0].day);
        expect(rootScope.selectValue3[0].FromTime).toBe(rootScope.fromtime[0].value);
        expect(rootScope.selectValue3[0].ToTime).toBe(rootScope.totime[0].value);
    });

    it('should select next value on down key press', function() {
        element = compileElement();
        var anchElement = element.find('#customSelect');
        anchElement.trigger({type: 'keydown', keyCode: 40});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[0].value);
        anchElement.trigger({type: 'keydown', keyCode: 40});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[1].value);
        anchElement.trigger({type: 'keydown', keyCode: 40});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[2].value);
    });

    it('should select previou value on up key press', function() {
        rootScope.preselectValue3 = {"day": "24/7"};
        element = compileElement();
        var anchElement = element.find('#customSelect');
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[2].value);
        anchElement.trigger({type: 'keydown', keyCode: 38});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[1].value);
        anchElement.trigger({type: 'keydown', keyCode: 38});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[0].value);
        anchElement.trigger({type: 'keydown', keyCode: 38});
        expect(rootScope.selectValue3.day).toBe(rootScope.optionValues[0].value);
    });
});

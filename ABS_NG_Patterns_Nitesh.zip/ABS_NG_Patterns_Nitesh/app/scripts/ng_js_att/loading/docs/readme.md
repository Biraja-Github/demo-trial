<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **Loading directive** is built using angular library.
This can be used for rendering various types of loading in an application.

We can control various parameters like att-loading,progress-status, color-class, using this directive.

#### `<Attribute level configuration for rendering loading>` ####

 * `att-loading`: The attr flag to render the loading of large size. No values required.
 
 * `att-loading = "small"` : The attr flag to render the loading of small size. 
 
 * `progress-status`: The attr serves the progress status.
 
 * `color-class` : using this attr add class and change the loading  color.
var loading = function($scope,$http) {
 $scope.progressvalue="50";
 $scope.bgColorClass = 'att-loading--dark';
    $scope.colorsItem = [];
    $scope.colorClass = [];
    $http.get('data/colors.json').success(function(data) {
        var obj = data;
        for (var key in obj) {
            if (key == 'loading') {
                var colorObj = obj[key];
                for (var cKey in colorObj) {
                    var color = (colorObj[cKey].color);
                    var title = (colorObj[cKey].title);
                    var name = (colorObj[cKey].name);
                    $scope.colorsItem.push({'color': color, 'title': title});
                    $scope.colorClass[colorObj[cKey].color] = {'color': color,
                        'colorClass': name
                    };
                    var cItemObj = $scope.colorClass;
                    $scope.$watch('selected', function(val) {
                        for (var key in cItemObj) {
                            if (val == key) {
                                $scope.bgColorClass = cItemObj[key].colorClass;
								$scope.progressvalue=Math.floor((Math.random() * 100) + 1);
                            }
                        }
                    });
                }
            }
        }
    });
	
};
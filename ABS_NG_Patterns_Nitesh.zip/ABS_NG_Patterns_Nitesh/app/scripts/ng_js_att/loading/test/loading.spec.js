describe("Loding component",function(){
	var scope,compile;
	beforeEach(module('att.abs.loading'));
	beforeEach(module('app/scripts/ng_js_att_tpls/loading/loading.html'));
	beforeEach(inject(function(_$rootScope_,_$compile_){
		scope=_$rootScope_;
		compile=_$compile_;
	}));
	var htmlcompile=function(markup){
		scope.progressvalue="50";
		scope.bgColorClass = 'att-loading--dark';
		var markup=angular.element(markup);
		markup=compile(markup)(scope);
		scope.$apply(markup);
		return markup;	
	}	
	it('should check normal loading',function(){
		var normalloading=htmlcompile("<div att-loading></div>");
		expect(normalloading).toHaveClass('loading');
		expect(normalloading).not.toHaveClass('loading--small att-loading-count');	
	});
	it('should check small loading',function(){
		var smalliconloading=htmlcompile("<div att-loading='small'></div>");
		expect(smalliconloading).toHaveClass('loading');
		expect(smalliconloading).toHaveClass('loading--small');
		expect(smalliconloading).not.toHaveClass('att-loading-count');	
	});
	it('should check count loading',function(){
		var countloading=htmlcompile("<div att-loading='count' progress-status='80'></div>");
		expect(countloading).not.toHaveClass('loading loading--small');
		expect(countloading).toHaveClass('att-loading-count');	
	});
	it('should check count loading with progress value',function(){
		var countloading=htmlcompile("<div att-loading='count' progress-status='progressvalue'></div>");
		var datavalue=Number(countloading.attr('data-progress'));
		expect(scope.progressvalue).toEqual(datavalue);		
	});
	it('should check external color class',function(){
		var countloading=htmlcompile("<div att-loading='count' progress-status='progressvalue' color-class='bgColorClass'></div>");
		expect(countloading).toHaveClass(scope.bgColorClass);		
	});

});
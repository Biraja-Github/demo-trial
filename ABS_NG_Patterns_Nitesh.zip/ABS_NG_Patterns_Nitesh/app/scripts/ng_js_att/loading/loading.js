'use strict'
angular.module('att.abs.loading', [])
    .directive('attLoading', [
    function() {
        return {
			restrict:'A',
			replace:true,
			scope:{
				icon:'@attLoading',
				progressStatus:'=?',
				colorClass:'=?'
			},
			templateUrl:'app/scripts/ng_js_att_tpls/loading/loading.html',			
			link:function(scope,element,attr){
				var progressvalue=scope.progressStatus;
				scope.progressStatus = Math.min(100, Math.max(0, progressvalue));				 
			}
         };
     }
 ]);

describe('dividerLines', function() {
    var $scope, $compile;
    beforeEach(module('att.abs.dividerLines'));
    beforeEach(module('app/scripts/ng_js_att_tpls/dividerLines/dividerLines.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
    
     it("should show divider line, class divider should be added", function() {
        var element = compileElement('<div att-divider-lines></div>', $scope);
        expect(element.find('div').eq(0)).toHaveClass('divider');      
    });
});



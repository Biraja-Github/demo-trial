'use strict'
angular.module('att.abs.dividerLines', [])
        .directive('attDividerLines', [function()
            {
                return {
                    restrict: 'A',
                    replace: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/dividerLines/dividerLines.html',
                };
            }]);


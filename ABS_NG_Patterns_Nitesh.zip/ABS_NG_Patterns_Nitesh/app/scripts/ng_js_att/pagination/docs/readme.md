<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-pagination directive** is built using angular library.
This directive is used for showing the pagination i.e. the page number.

We can control various parameters like total-pages, current-page while using this directive.

#### `<Attribute level configuration for rendering pagination>` ####

 * `total-pages`
 	:
 	The attr can be used to specify the number of pages.

 * `current-page`
 	:
 	The attr to select a particular page.
    
<br/><br/>

<p class="guideline-title">Red Lines</p>
<br/>
<div class="guidelines-pagination-small-page-count"></div>

<p class="guideline-title">GUIDELINES</p>
 <ul class="guideline-description">
	<li>Page range: up to 10 pages</li>
	<li>When moving from page 1 to the next pages, indicate the current page. </li>
</ul>

 <ul class="guideline-description">
	<li>Because all items are exposed there's no need to add "Previous" or "Next arrows".</li>
	<li>Pagination with keyboard access. Arrows right and left to navigate between pages.</li>
</ul>
<br/>
<a href="/uipatterns.html#pagination-tables" class="link">See Pagination on tables pattern</a><br>
<a href="/uipatterns.html#pagination-alignment" class="link">See Pagination alignment pattern</a>
         

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-pagination directive** is built using angular library.
This directive is used for showing the pagination i.e. the page number.

We can control various parameters like total-pages, current-page while using this directive.

#### `<Attribute level configuration for rendering pagination>` ####

 * `total-pages`
 	:
 	The attr can be used to specify the number of pages.

 * `current-page`
 	:
 	The attr to select a particular page.
    
<br/><br/>

<p class="guideline-title">GUIDELINES</p>
<ul class="guideline-description">
    <li>If pagination has more than 10 pages.</li>
    <li>Page range: up to 100 pages.</li>
    <li>On page 6 truncate the list, showing the first two pages, 3 middle pages, and the last two pages.</li>
    <li>Use ellipsis to simbolize truncated pages.</li>
</ul>
<ul class="guideline-description">
    <li>For medium page, to show N items per page, it is usually better to offer a single default number, such as 10 or 20 and supplement it with "view all" option. </li>
    <li>Offer content sorting and filtering to the user when offering choice to display option for medium page count.</li>
</ul>
<ul class="guideline-description">
    <li>Because the first and last page numbers are exposed, there's no need to include the "Last Page" and "First Page" links.</li>
</ul>


<!-- ABSSBA -->

<p class="guideline-title">Directives</p>

The **att-pagination directive** is built using angular library.
This directive is used for showing the pagination i.e. the page number.

We can control various parameters like total-pages, current-page while using this directive.

#### `<Attribute level configuration for rendering pagination>` ####

 * `total-pages`
 	:
 	The attr can be used to specify the number of pages.

 * `current-page`
 	:
 	The attr to select a particular page.
    
<br/><br/>

<p class="guideline-title">Red Lines</p>
<br/>
<div class="guidelines-pagination-large-page-count"></div>
<br/>
<p class="guideline-title">GUIDELINES</p>
<ul class="guideline-description">
    <li>If pagination has more than 100 pages.</li>
    <li>Page range: up to 1000 pages</li>
    <li>Display: 5 Total choices</li>
    <li>For large page count, the option to "View All" would generate a large page choices so, give users the choice between two numbers; for instances 20 and 60, where the second number is substantially bigger than the default.</li>
</ul>

<ul class="guideline-description">
    <li>Offer content sorting and filtering to the user, this is especially essential for large numbers of items. User might want to sort of filter the search result to limit the alternative of choices.</li>
</ul>


<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **viewPerPages directive** is built using angular library.
This directive is used for showing the viewPerPages i.e. the pages for every view.

We can control various parameters like total-pages, current-page while using this directive.

#### `<Attribute level configuration for rendering pagination>` ####

 * `view-per-pages`
 	:
 	The attr can be used to specify the number of pages.

 * `currentselection`
 	:
 	The attr will highlight the selected number of pages.
    
<br/><br/>

<p class="guideline-title">Red Lines</p>
<br/>
<div class="guidelines-pagination-views-per-page"></div>

<p class="guideline-title">GUIDELINES</p>
<ul class="guideline-description">
    <li>“Views per page” always appears on the top of the content and includes a “view all” option.</li>
    <li>The larger the user’s window is, the more results you should show.</li>
    <li>Use a single default number, such as 20, and supplement it with “View All” for users who want more.</li>
    <li>The larger the user’s window is, the more results you should show.</li>
</ul>
<ul class="guideline-description">
    <li>Alternatively, if “ View All” would generate an unwieldy page, give users the choice between two numbers, 20 and 60, where the second number is substantially bigger than the default.</li>
    <li>The smaller the result, the more should be show per page.</li>
    <li>Linear content flows should never be broken up into multiple screens.</li>
</ul>
<ul class="guideline-description">
    <li>If fetching results takes too much time, bringing more result per page will save the user’s time and will increase positive user experience.</li>
    <li>Use a maximum of 3 and minimum of 2 choices for “views per page”, and that are substantially distant from each other.</li>
</ul>
<br/>
<a href="/uipatterns.html#pagination-alignment_per-page" class="link">See Views per Page pattern</a>
          
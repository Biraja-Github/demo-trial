var paginationController = function($scope) {
    $scope.totalPages1 = 10;

    $scope.totalPages2 = 100;

    $scope.totalPages3 = 1000;
    $scope.showInput = true;
};

var vierPerPageController=function($scope){
$scope.pages=["10","60","All"];
$scope.currentselection="60";
};
angular.module('att.abs.pagination', ['att.abs.utilities'])
.directive('attPagination', ['$timeout', function($timeout) {
    return {
        restrict: 'EA',
        scope: {
            totalPages: '=',
            currentPage: '=',
            showInput: '='
        },
        replace: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/pagination/pagination.html',
        link: function(scope, elem, attr, ctrl) {
            scope.focusedPage;

            scope.$watch('totalPages', function(value) {
                scope.pages = [];
                if (value < 1) {
                    scope.totalPages = 1;
                    return;
                }

                if (value <= 10) {
                    for (var i = 1; i <= value; i++) {
                        scope.pages.push(i);
                    }
                } else if (value > 10) {
                    var midVal = Math.ceil(value / 2);
                    scope.pages = [midVal - 1, midVal, midVal + 1];
                }
                scope.currentPage = 1;
            });

            scope.$watch('currentPage', function(value) {
                if (!value) {
                    scope.currentPage = 1;
                    return;
                } else if (!angular.isNumber(value)) {
                    scope.currentPage = parseInt(value, 10);
                    return;
                }
                if (value > scope.totalPages) {
                    scope.currentPage = scope.totalPages;
                    return;
                } else if (value < 1) {
                    scope.currentPage = 1;
                    return;
                }

                if (scope.totalPages > 10) {
                    if (value <= scope.pages[0] && value >= 3) {
                        scope.pages = [value - 1, value, value + 1];
                    } if (value <= 5) {
                        scope.pages = [1, 2, 3,4,5,6];
                    }else if (value >= scope.pages[2] && value < scope.totalPages - 2) {
                        scope.pages = [value-1, value, value + 1];
                    }
					else if (value >= scope.totalPages - 2) {
                        scope.pages = [scope.totalPages - 2, scope.totalPages - 1, scope.totalPages];
                    }
                }
            });
            
            scope.next = function(event) {
                event.preventDefault();
                if (scope.currentPage < scope.totalPages) {
                    scope.currentPage += 1;
                }
            };

            scope.prev = function(event) {
                event.preventDefault();
                if (scope.currentPage > 1) {
                    scope.currentPage -= 1;
                }
            };

            scope.selectPage = function(value, event) {
                event.preventDefault();
                scope.currentPage = value;
                scope.focusedPage = value;
            };
            
            scope.checkSelectedPage = function(value) {
                if(scope.currentPage === value) {
                    return true;
                }
                return false;
            };

            scope.isFocused = function(page) {
                if(scope.focusedPage === page) {
                    return true;
                } else {
                    return false;
                }
            };
        }
    };
}])
.directive('viewPerPages', function() {
  return {
    scope:{
		viewperpage:'=',
		currentselection:'=?'
	},
    restrict: 'A',
    replace: 'true',
	transclude:'true',
    templateUrl: 'app/scripts/ng_js_att_tpls/pagination/viewperpage.html',
	link: function(scope,elem,attr){	
		scope.pagesclick=function(pages){			
			scope.currentselection=pages;
		}
		scope.currentpage=function(pages){
		  if(scope.currentselection==pages) return true;else return false;
		}
	}
  };
});
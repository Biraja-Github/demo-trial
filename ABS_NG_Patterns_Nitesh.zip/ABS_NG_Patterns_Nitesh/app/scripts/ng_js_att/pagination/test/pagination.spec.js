describe('pagination', function() {
    var $scope, $compile;

    beforeEach(module('att.abs.pagination'));
    beforeEach(module('app/scripts/ng_js_att_tpls/pagination/pagination.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_, _$timeout_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    var click = function(elem, index) {	
        elem.find('a.pager__item-link').eq(index).click();
    };    
    
    it('should show 5 pages starting from 1 with next link, and 1st page is selected.', function() {
        $scope.totalPages = 10;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();
        
        expect(elem.find('li').length).toBe(11);
		expect(elem.find('li').eq(0).text().trim()).toBe('1');
        expect(elem.find('li').eq(0)).toHaveClass('pager__item--active');
    });
    
    it('should select 2nd page on clicking next.', function() {
        $scope.totalPages = 100;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();		
        elem.find(".pager__item--next a").click();
		
        expect(elem.find('li').length).toBe(12);
        expect(elem.find('li').eq(2).text().trim()).toBe('2');
        expect(elem.find('li').eq(2)).toHaveClass('pager__item--active');
    });
    
    it('should select 2nd page on clicking previous after two next.', function() {
        $scope.totalPages = 100;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();        
        elem.find(".pager__item--next a").click();
        elem.find(".pager__item--next a").click();
        elem.find(".pager__item--prev a").click();        
        expect(elem.find('li').length).toBe(12);
        expect(elem.find('li').eq(2).text().trim()).toBe('2');
        expect(elem.find('li').eq(2)).toHaveClass('pager__item--active');
    });
    
    it('should select 4th page on clicking 4.', function() {
        $scope.totalPages = 5;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();        
        click(elem, 3);        
        expect(elem.find('li').length).toBe(6);
        expect(elem.find('li').eq(3).text().trim()).toBe('4');
        expect(elem.find('li').eq(3)).toHaveClass('pager__item--active');
    });
    
    it('should hide previous link on clicking 1.', function() {
        $scope.totalPages = 10;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();
        
        click(elem, 0);
        
        expect(elem.find('li').length).toBe(11);
        expect(elem.find('li').eq(0).text().trim()).toBe('1');
        expect(elem.find('li').eq(0)).toHaveClass('pager__item--active');
    });
    
    it('should hide next link on clicking 5.', function() {
        $scope.totalPages = 10;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();
        
        click(elem, 4);
        
        expect(elem.find('li').length).toBe(11);
        expect(elem.find('li').eq(4).text().trim()).toBe('5');
        expect(elem.find('li').eq(4)).toHaveClass('pager__item--active');
    });
    
    it('should show only 1st 6 pages, last two pages and next link when total pages is greater than 10.', function() {
        $scope.totalPages = 100;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage"></div>')($scope);
        $scope.$digest();        
        
        expect(elem.find('li').length).toBe(11);
        expect(elem.find('li').eq(0).text().trim()).toBe('1');
        expect(elem.find('li').eq(1).text().trim()).toBe('2');
        expect(elem.find('li').eq(2).text().trim()).toBe('3');
        expect(elem.find('li').eq(3).text().trim()).toBe('4');
        expect(elem.find('li').eq(4).text().trim()).toBe('5');
        expect(elem.find('li').eq(5).text().trim()).toBe('6');
        expect(elem.find('li').eq(6).text().trim()).toBe('...');
        expect(elem.find('li').eq(8).text().trim()).toBe('99');
        expect(elem.find('li').eq(9).text().trim()).toBe('100');
        expect(elem.find('li').eq(10).text().trim()).toBe('Next');
        expect(elem.find('li').eq(0)).toHaveClass('pager__item--active');
    });
    
    it('should select 15th page on entering 150 in the text field.', function() {
        $scope.totalPages = 1000;
        $scope.showInput = true;
        var elem = $compile('<div att-pagination total-pages="totalPages" current-page="currentPage" show-input="showInput"></div>')($scope);
        $scope.$digest();
        
        elem.find('input').val(150).triggerHandler('input');
        
        expect(elem.find('li').length).toBe(11);
        expect(elem.find('li').eq(5).text().trim()).toBe('150');
        expect(elem.find('li').eq(5)).toHaveClass('pager__item--active');
    });
});

describe('Unit Test: Slider', function() {
    var scope, compile,myCtrl;
    beforeEach(module('att.abs.slider'));
    beforeEach(module('app/scripts/ng_js_att_tpls/slider/slider.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_,_$controller_) {
        scope = _$rootScope_;
        compile = _$compile_;
        myCtrl = _$controller_('AbsSliderCtrl', {
                $scope: scope
            });
    }));

    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };

    it("should check for single Selection Slider", function() {
        var elem = compileMarkup('<att-slider floor="slider.floor" ceiling="slider.ceiling" step="5"  ng-model-single="slider.currentPosVal"></att-slider>');
        var handle = elem.children().eq(1).children().eq(0);
        var evObjStart = document.createEvent("MouseEvents");
        evObjStart.initMouseEvent("mousedown", true, true, window, 1, 0, 320, 0, 320, false, false, false, false, 0, null);
        var evObj = document.createEvent("MouseEvents");
        evObj.initMouseEvent("mousemove", true, true, window, 1, 50, 320, 50, 320, false, false, false, false, 0, null);
        var evObjEnd = document.createEvent("MouseEvents");
        evObjEnd.initMouseEvent("mouseup", true, true, window, 1, 50, 320, 50, 320, false, false, false, false, 0, null);
        handle[0].dispatchEvent(evObjStart);
        handle[0].dispatchEvent(evObj);
        expect(handle).toHaveClass('dragging');
        handle[0].dispatchEvent(evObjEnd);
        expect(scope.slider.currentPosVal).toBe('83');
        expect(handle).not.toHaveClass('dragging');

    });
     
    it("should check for range Selection Slider", function() {
        var elem = compileMarkup('<att-slider floor="slider.floor" ceiling="slider.ceiling" step="10" precision="2" ng-model-low="slider.rangeSelectionValue.minVal" ng-model-high="slider.rangeSelectionValue.maxVal"></att-slider>');
        var handleMin = elem.children().eq(1).children().eq(0);
        var handleMax = elem.children().eq(1).children().eq(1);
       
        var evObjMaxStart = document.createEvent("MouseEvents");
        evObjMaxStart.initMouseEvent("mousedown", true, true, window, 1, 0, 320, 0, 320, false, false, false, false, 0, null);
        var evObjMax = document.createEvent("MouseEvents");
        evObjMax.initMouseEvent("mousemove", true, true, window, 1, 100, 320, 100, 320, false, false, false, false, 0, null);
        var evObjMaxEnd = document.createEvent("MouseEvents");
        evObjMaxEnd.initMouseEvent("mouseup", true, true, window, 1, 100, 320, 100, 320, false, false, false, false, 0, null);
        
        var evObjMinStart = document.createEvent("MouseEvents");
        evObjMinStart.initMouseEvent("mousedown", true, true, window, 1, 0, 320, 0, 320, false, false, false, false, 0, null);
        var evObjMin = document.createEvent("MouseEvents");
        evObjMin.initMouseEvent("mousemove", true, true, window, 1, 5, 320, 5, 320, false, false, false, false, 0, null);
        var evObjMinEnd = document.createEvent("MouseEvents");
        evObjMinEnd.initMouseEvent("mouseup", true, true, window, 1, 5, 320, 5, 320, false, false, false, false, 0, null);
       
        handleMax[0].dispatchEvent(evObjMaxStart);
        handleMax[0].dispatchEvent(evObjMax);
        expect(handleMax).toHaveClass('dragging');
        handleMax[0].dispatchEvent(evObjMaxEnd);
        expect(handleMax).not.toHaveClass('dragging');
             
        handleMin[0].dispatchEvent(evObjMinStart);
        handleMin[0].dispatchEvent(evObjMin);
        expect(handleMin).toHaveClass('dragging');
        handleMin[0].dispatchEvent(evObjMinEnd);
        expect(handleMin).not.toHaveClass('dragging');
        
        expect(scope.slider.rangeSelectionValue.minVal).toBe('10.00');
        expect(scope.slider.rangeSelectionValue.maxVal).toBe('170.00');
     });

    it("should check for single Selection Slider with disabled property", function() {
        var elem = compileMarkup('<att-slider floor="slider.floor" ceiling="slider.ceiling" step="10" precision="2" text-display="slider.displayTxtSingle" ng-model-disabled="slider.disabledSlider"></att-slider>');
        var disabledWidth =  elem.children().eq(0).children().eq(0);
        expect(disabledWidth).toHaveClass('att-slider__range--disabled');
    });
});

describe('Unit Test: Step Slider', function() {
    var scope, compile,myCtrl;
    beforeEach(module('att.abs.slider'));
    beforeEach(module('app/scripts/ng_js_att_tpls/slider/attStepSlider.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_,_$controller_) {
        scope = _$rootScope_;
        compile = _$compile_;
        myCtrl = _$controller_('AbsSliderCtrl', {
            $scope: scope
        });
    }));

    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };

    it('should have the slider handler', function(){
        scope.sliderValue = "20";
        scope.sliderOptions = {                
            from: 0,
            to: 100,
            step: 1,
            smooth: true,
            dimension: " Kps",
            scale: [0,10,20,30,40,50,60,70,80,90],
            callback: function(value) {}
        };  
        var elem = compileMarkup('<div att-step-slider  ng-model="sliderValue" options="sliderOptions"></div>');
        expect(elem.find('.jslider-pointer-to').length).toBe(1);
    });

    it('should have the slider value label', function(){
        scope.sliderValue = "20";
        scope.sliderOptions = {                
            from: 0,
            to: 100,
            step: 1,
            smooth: true,
            dimension: " Kps",
            scale: [0,10,20,30,40,50,60,70,80,90],
            callback: function(value) {}
        };  
        var elem = compileMarkup('<div att-step-slider  ng-model="sliderValue" options="sliderOptions"></div>');
        expect(elem.find('.jslider-label-to').length).toBe(1);
    });

});
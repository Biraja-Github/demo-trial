angular.module('att.abs.slider', [])
        .constant('sliderDefaultOptions', {
            width: 300,
            step: 1,
            precision: 0,
            disabledWidth: 116
        })
        .directive('attSlider', ['sliderDefaultOptions', function(sliderDefaultOptions)
            {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    scope: {
                        floor: "=", // the minimum possible value
                        ceiling: "=", // the maximum possible value
                        step: "@", // how wide is each step
                        precision: "@", // how many decimal places do we care about
                        width: "@", //how wide the bar would be
                        textDisplay: "=", // Labels of max and min values to be displayed at front End
                        value: "=", // Value of Current Position model
                        ngModelSingle: '=?',
                        ngModelLow: '=?',
                        ngModelHigh: '=?',
                        ngModelDisabled: '=?'
                    },
                    templateUrl: 'app/scripts/ng_js_att_tpls/slider/slider.html',
                    link: function(scope, elem, attr, ctrl)
                    {
                        var minOffset, maxOffset, newOffset, offsetRange, valueRange, start_x = 0, disabledRange, disabled, evFlag = false, minValue, maxValue, range, refLow, refHigh, maxPtr, minPtr, singlePtr, getHandles;
                        scope.minPtrOffset = 0;
                        scope.maxPtrOffset = 0;
                        var disableWidth = sliderDefaultOptions.disabledWidth;
                       
                        //Get handles 
                        var obj = elem.children();
                        disabledRange = obj[0].children;
                        disabledRange = angular.element(disabledRange[0]);
                        getHandles = obj[1].children;
                        singlePtr = angular.element(getHandles[0]);
                        minPtr = angular.element(getHandles[1]);
                        maxPtr = angular.element(getHandles[2]);
                        disabled = ((attr.ngModelSingle == null) && (attr.ngModelLow == null) && (attr.ngModelHigh == null)) && (attr.ngModelDisabled != null);
                        range = (attr.ngModelSingle == null) && ((attr.ngModelLow != null) && (attr.ngModelHigh != null));
                        refLow = 'ngModelLow';
                        refHigh = 'ngModelHigh';
                        if (!range) {
                            minPtr.remove();
                            maxPtr.remove();
                        }
                        else {
                            singlePtr.remove();
                        }
                        if (!disabled) {
                            disabledRange.remove();
                        }
                        else {
                            scope.disabledStyle = {width: disableWidth + 'px', zIndex: 1};
                            scope.handleStyle = {left: disableWidth + 'px'};
                        }
                        minValue = parseFloat(scope.floor);
                        maxValue = parseFloat(scope.ceiling);
                        valueRange = maxValue - minValue;
                        minOffset = 0;
                        if (attr.width !== undefined) {
                            maxOffset = attr.width;
                        }
                        else {
                            if (elem[0].clientWidth !== 0) {
                                maxOffset = elem[0].clientWidth;
                            }
                            else {
                                maxOffset = sliderDefaultOptions.width;
                            }
                        }
                        offsetRange = maxOffset - minOffset;

                        //Mouse Down Event
                        scope.mouseDown = function(e, ref) {
                            scope.ref = ref;
                            evFlag = true;
                            if (!range){
                                if (newOffset)
                                {
                                    start_x = e.clientX - newOffset;

                                }
                                else {
                                    start_x = e.clientX;
                                }
                            } else {
                                if (scope.ref == refLow) {
                                    start_x = e.clientX - scope.minPtrOffset;

                                }
                                else {
                                    start_x = e.clientX - scope.maxPtrOffset;
                                }
                            }
                            if (disabled) {
                                scope.ref= 'ngModelDisabled';
                                scope.disabledStyle = {width: disableWidth + 'px', zIndex: 1};
                            }
                        };

                        // Mouse Move Event
                        scope.moveElem = function(ev) {
                            if (evFlag) {
                                var eventX, newPercent, newValue;
                                eventX = ev.clientX;
                                newOffset = eventX - start_x;
                                //elm[0].getBoundingClientRect().left;
                                newOffset = Math.max(Math.min(newOffset, maxOffset), minOffset);
                                newPercent = scope.percentOffset(newOffset);
                                newValue = minValue + (valueRange * newPercent / 100.0);
                                if (range) {
                                    var rangeSliderWidth;
                                    if (scope.ref == refLow) {
                                        scope.minHandleStyle = {left: newOffset + "px"};
                                        scope.minNewVal = newValue;
                                        scope.minPtrOffset = newOffset;
                                        minPtr.addClass('dragging');
                                        if (newValue > scope.maxNewVal) {
                                            scope.ref = refHigh;
                                            scope.maxNewVal = newValue;
                                            scope.maxPtrOffset = newOffset;
                                            maxPtr.addClass('dragging');
                                            minPtr.removeClass('dragging');
                                            scope.maxHandleStyle = {left: newOffset + "px"};
                                        }
                                    }
                                    else {
                                        scope.maxHandleStyle = {left: newOffset + "px"};
                                        scope.maxNewVal = newValue;
                                        scope.maxPtrOffset = newOffset;
                                        maxPtr.addClass('dragging');
                                        if (newValue < scope.minNewVal) {
                                            scope.ref = refLow;
                                            scope.minVal = newValue;
                                            scope.minPtrOffset = newOffset;
                                            minPtr.addClass('dragging');
                                            maxPtr.removeClass('dragging');
                                            scope.minHandleStyle = {left: newOffset + "px"};
                                        }
                                    }
                                    rangeSliderWidth = parseInt(scope.maxPtrOffset) - parseInt(scope.minPtrOffset);
                                    scope.rangeStyle = {width: rangeSliderWidth + "px", left: scope.minPtrOffset + "px"};
                                }
                                else {
                                    if (disabled && newOffset > disableWidth) {
                                        scope.rangeStyle = {width: newOffset + "px", zIndex: 0};
                                    }
                                    else {
                                        singlePtr.addClass('dragging');
                                        scope.rangeStyle = {width: newOffset + "px"};
                                    }
                                    scope.handleStyle = {left: newOffset + "px"};
                                }
                                if ((scope.precision == undefined) || (scope.step == undefined)) {
                                    scope.precision = sliderDefaultOptions.precision;
                                    scope.step = sliderDefaultOptions.step;
                                }
                                newValue = scope.calStep(newValue, parseInt(scope.precision), parseFloat(scope.step), parseFloat(scope.floor));
                                scope[scope.ref] = newValue;
                            }
                        };

                        // Mouse Up Event
                        scope.mouseUp = function(ev) {
                            evFlag = false;
                            minPtr.removeClass('dragging');
                            maxPtr.removeClass('dragging');
                            singlePtr.removeClass('dragging');
                            $(document).off('mousemove');
                        };

                        //Function to calculate the current PositionValue
                        scope.calStep = function(value, precision, step, floor) {
                            var decimals, remainder, roundedValue, steppedValue;
                            if (floor === null) {
                                floor = 0;
                            }
                            if (step === null) {
                                step = 1 / Math.pow(10, precision);
                            }
                            remainder = (value - floor) % step;
                            steppedValue = remainder > (step / 2) ? value + step - remainder : value - remainder;
                            decimals = Math.pow(10, precision);
                            roundedValue = steppedValue * decimals / decimals;
                            return roundedValue.toFixed(precision);
                        };

                        //Function to calculate Offset Percent
                        scope.percentOffset = function(offset) {
                            return ((offset - minOffset) / offsetRange) * 100;
                        };
                    }
                };
            }
        ]).directive('attSliderMin',[function()
            {
             return{
                 require: '^attSlider',
                 restrict: 'EA',
                 replace: true,
                 transclude: true,
                 templateUrl: 'app/scripts/ng_js_att_tpls/slider/minContent.html'
               };
         }
    ]).directive('attSliderMax',[function()
            {
             return{
                 require: '^attSlider',
                 restrict: 'EA',
                 replace: true,
                 transclude: true,
                 templateUrl: 'app/scripts/ng_js_att_tpls/slider/maxContent.html'
             };
         }
    ])
.constant('sliderConstants', {
    /*
        The MIT License (MIT)
        Copyright (c) 2013 Julien Valéry
    */
    SLIDER: {
      settings: {
        from: 1,
        to: 40,
        step: 1,
        smooth: true,
        limits: true,
        value: "3",
        dimension: "",
        vertical: false
      },
      className: "jslider",
      selector: ".jslider-"
    },
    EVENTS: {
    }
 })
.factory('utils', function() {
    /*
        The MIT License (MIT)
        Copyright (c) 2013 Julien Valéry
    */
    return {
      offset: function(elm) { 
        var rawDom = elm[0]; 
        var _x = 0; 
        var _y = 0; 
        var body = document.documentElement || document.body; 
        var scrollX = window.pageXOffset || body.scrollLeft; 
        var scrollY = window.pageYOffset || body.scrollTop; 
        _x = rawDom.getBoundingClientRect().left + scrollX; 
        _y = rawDom.getBoundingClientRect().top + scrollY; 
        return { left: _x, top:_y };
      }
    };
})
.factory('sliderPointer', ['sliderDraggable', 'utils', function(Draggable, utils) {

    /*
        The MIT License (MIT)
        Copyright (c) 2013 Julien Valéry
    */
    function SliderPointer() {
      Draggable.apply(this, arguments);
    }

    SliderPointer.prototype = new Draggable();

    SliderPointer.prototype.oninit = function(ptr, id, vertical, _constructor) {
      this.uid = id;
      this.parent = _constructor;
      this.value = {};
      this.vertical = vertical;
      this.settings = angular.copy(_constructor.settings);
    };

    SliderPointer.prototype.onmousedown = function(evt) {
      var off = utils.offset(this.parent.domNode);

      var offset = {
        left: off.left,
        top: off.top,
        width: this.parent.domNode[0].clientWidth,
        height: this.parent.domNode[0].clientHeight
      };

      this._parent = {
        offset: offset,
        width: offset.width,
        height: offset.height
      };      

      this.ptr.addClass("jslider-pointer-hover");
      this.setIndexOver();
    };

    SliderPointer.prototype.onmousemove = function(evt, x, y) {
      var coords = this._getPageCoords( evt );      
      this._set(!this.vertical ? this.calc( coords.x ) : this.calc( coords.y ));
    };

    SliderPointer.prototype.onmouseup = function(evt) {
      if( this.settings.callback && angular.isFunction(this.settings.callback) )
        this.settings.callback.call( this.parent, this.parent.getValue() );

      this.ptr.removeClass("jslider-pointer-hover");
    };

    SliderPointer.prototype.setIndexOver = function() {
      this.parent.setPointersIndex(1);
      this.index(2);
    };

    SliderPointer.prototype.index = function(i) {
      this.ptr.css({zIndex:i});
    };

    SliderPointer.prototype.limits = function(x) {
      return this.parent.limits(x, this);
    };

    SliderPointer.prototype.calc = function(coords) {

      return !this.vertical ? 
        this.limits(((coords-this._parent.offset.left)*100)/this._parent.width)
        :
        this.limits(((coords-this._parent.offset.top)*100)/this._parent.height);
    };

    SliderPointer.prototype.set = function(value, opt_origin) {
      this.value.origin = this.parent.round(value);
      this._set(this.parent.valueToPrc(value,this), opt_origin);
    };

    SliderPointer.prototype._set = function(prc, opt_origin) {
      if(!opt_origin)
        this.value.origin = this.parent.prcToValue(prc);

      this.value.prc = prc;
      if (!this.vertical)
        this.ptr.css({left:prc+"%"});
      else
        this.ptr.css({top:prc+"%", marginTop: -5});
      this.parent.redraw(this);
    };

    return SliderPointer;
}])
.factory('sliderDraggable', ['utils', function(utils) {
    /*
        The MIT License (MIT)
        Copyright (c) 2013 Julien Valéry
    */
    function Draggable(){
      this._init.apply( this, arguments );
    }

    Draggable.prototype.oninit = function(){
    };

    Draggable.prototype.events = function(){
    };

    Draggable.prototype.onmousedown = function(){
      this.ptr.css({ position: "absolute" });
    };

    Draggable.prototype.onmousemove = function( evt, x, y ){
      this.ptr.css({ left: x, top: y });
    };

    Draggable.prototype.onmouseup = function(){};

    Draggable.prototype.isDefault = {
      drag: false,
      clicked: false,
      toclick: true,
      mouseup: false
    };

    Draggable.prototype._init = function() {
      if( arguments.length > 0 ){
        this.ptr = arguments[0];
        this.parent = arguments[2];

        if (!this.ptr)
          return;

        this.is = {};
        angular.extend( this.is, this.isDefault );
        var offset = utils.offset(this.ptr);

        this.d = {
          left: offset.left,
          top: offset.top,
          width: this.ptr[0].clientWidth,
          height: this.ptr[0].clientHeight
        };

        this.oninit.apply( this, arguments );

        this._events();
      }
    };

    Draggable.prototype._getPageCoords = function( event ){
      if( event.targetTouches && event.targetTouches[0] ){
        return { x: event.targetTouches[0].pageX, y: event.targetTouches[0].pageY };
      } else
      return { x: event.pageX, y: event.pageY };
    };

    Draggable.prototype._bindEvent = function( ptr, eventType, handler ){
      var self = this;

      if( this.supportTouches_ )
        ptr[0].addEventListener( this.events_[ eventType ], handler, false );

      else
        ptr.bind( this.events_[ eventType ], handler );
    };

    Draggable.prototype._events = function(){
      var self = this;

      this.supportTouches_ = 'ontouchend' in document;
      this.events_ = {
        "click": this.supportTouches_ ? "touchstart" : "click",
        "down": this.supportTouches_ ? "touchstart" : "mousedown",
        "move": this.supportTouches_ ? "touchmove" : "mousemove",
        "up"  : this.supportTouches_ ? "touchend" : "mouseup",
        "mousedown"  : this.supportTouches_ ? "mousedown" : "mousedown"
      };

      var documentElt = angular.element(window.document);

      this._bindEvent(documentElt, "move", function(event) {        
        if(self.is.drag) {
          event.stopPropagation();
          event.preventDefault();
          if (!self.parent.disabled) {
            self._mousemove(event);
          }  
        }
      });
      this._bindEvent(documentElt, "down", function(event) {
        if(self.is.drag) {
          event.stopPropagation();
          event.preventDefault();
        }
      });
      this._bindEvent(documentElt, "up", function(event) {        
        self._mouseup(event);        
      });

      this._bindEvent( this.ptr, "down", function(event) {
        self._mousedown( event );
        return false;
      });
      this._bindEvent( this.ptr, "up", function(event) {
        self._mouseup( event );
      });      
     
      this.events();
    };

    Draggable.prototype._mousedown = function( evt ){
      this.is.drag = true;
      this.is.clicked = false;
      this.is.mouseup = false;   

      var coords = this._getPageCoords( evt );
      this.cx = coords.x - this.ptr[0].offsetLeft;
      this.cy = coords.y - this.ptr[0].offsetTop;

      angular.extend(this.d, {
        left: this.ptr[0].offsetLeft,
        top: this.ptr[0].offsetTop,
        width: this.ptr[0].clientWidth,
        height: this.ptr[0].clientHeight
      });

      if( this.outer && this.outer.get(0) ){
        this.outer.css({ height: Math.max(this.outer.height(), $(document.body).height()), overflow: "hidden" });
      }

      this.onmousedown( evt );
    };

    Draggable.prototype._mousemove = function( evt ){

      if(this.uid==0)
        return;

      this.is.toclick = false;
      var coords = this._getPageCoords( evt );
      this.onmousemove( evt, coords.x - this.cx, coords.y - this.cy );
    };    

    Draggable.prototype._mouseup = function( evt ){
      var oThis = this;

      if( this.is.drag ){
        this.is.drag = false;

        if( this.outer && this.outer.get(0) ) {

          if( $.browser.mozilla ){
            this.outer.css({ overflow: "hidden" });
          } else {
            this.outer.css({ overflow: "visible" });
          }

          if( $.browser.msie && $.browser.version == '6.0' ){
            this.outer.css({ height: "100%" });
          } else {
            this.outer.css({ height: "auto" });
          }
        }

        this.onmouseup( evt );
      }
    };

    return Draggable;
  }])
.factory('slider', ['sliderPointer', 'sliderConstants', 'utils', function(SliderPointer, sliderConstants, utils) {

    /*
        The MIT License (MIT)
        Copyright (c) 2013 Julien Valéry
    */
    function Slider() {
      return this.init.apply( this, arguments );
    }

    Slider.prototype.init = function( inputNode, templateNode, settings ){
      this.settings = sliderConstants.SLIDER.settings;
      angular.extend(this.settings, angular.copy(settings));

      this.inputNode = inputNode;
      this.inputNode.addClass("ng-hide");

      this.settings.interval = this.settings.to-this.settings.from;
      
      if( this.settings.calculate && $.isFunction( this.settings.calculate ) )
        this.nice = this.settings.calculate;

      if( this.settings.onstatechange && $.isFunction( this.settings.onstatechange ) )
        this.onstatechange = this.settings.onstatechange;

      this.is = { init: false };
      this.o = {};

      this.create(templateNode);
    };

    Slider.prototype.create = function(templateNode){
      var $this = this;

      this.domNode = templateNode;

      var off = utils.offset(this.domNode);

      var offset = {
        left: off.left,
        top: off.top,
        width: this.domNode[0].clientWidth,
        height: this.domNode[0].clientHeight
      };      

      this.sizes = { domWidth: this.domNode[0].clientWidth, domOffset: offset };

      angular.extend(this.o, {
        pointers: {},
        labels: {
          0: {            
            o : angular.element(this.domNode.find('div')[5])
          },
          1: {            
            o : angular.element(this.domNode.find('div')[6])
          }
        },
        limits: {          
          0: angular.element(this.domNode.find('div')[3]),          
          1: angular.element(this.domNode.find('div')[5])
        }
      });

      angular.extend(this.o.labels[0], {
        value: this.o.labels[0].o.find("span")
      });

      angular.extend(this.o.labels[1], {
        value: this.o.labels[1].o.find("span")
      });

      if( !$this.settings.value.split(";")[1] ) {
        this.settings.single = true;
      }

      var clickPtr;

      var domNodeDivs = this.domNode.find('div');
      var pointers = [ angular.element(domNodeDivs[1]), angular.element(domNodeDivs[2]) ];

      angular.forEach(pointers, function(pointer, key ) {
        $this.settings = angular.copy($this.settings);
        var value = $this.settings.value.split(';')[key];
        if( value ) {
          $this.o.pointers[key] = new SliderPointer( pointer, key, $this.settings.vertical, $this );

          var prev = $this.settings.value.split(';')[key-1];
          if( prev && parseInt(value, 10) < parseInt(prev, 10 )) value = prev;

          var value1 = value < $this.settings.from ? $this.settings.from : value;
          value1 = value > $this.settings.to ? $this.settings.to : value;

          $this.o.pointers[key].set( value1, true );

          if (key === 0) {
            $this.domNode.bind('mousedown', $this.clickHandler.apply($this));
          }
        }
      });

      this.o.value = angular.element(this.domNode.find("i")[2]);
      this.is.init = true;

      angular.forEach(this.o.pointers, function(pointer, key){
        $this.redraw(pointer);
      });

    };

    Slider.prototype.clickHandler = function() {
      var self = this;
      return function(evt) {
        if (self.disabled)
          return;
        var className = evt.target.className;
        var targetIdx = 0;

        if (className.indexOf('jslider-pointer-to') > 0) {
          targetIdx = 1;
        }

        var _off = utils.offset(self.domNode);

        var offset = {
          left: _off.left,
          top: _off.top,
          width: self.domNode[0].clientWidth,
          height: self.domNode[0].clientHeight
        };              

        var targetPtr = self.o.pointers[targetIdx];
        targetPtr._parent = { offset: offset, width: offset.width, height: offset.height};
        targetPtr._mousemove(evt);
        targetPtr.onmouseup();
      
        return false;
      };
    };

    Slider.prototype.disable = function(bool) {   
      this.disabled = bool;
    };    

    Slider.prototype.nice = function( value ){
      return value;
    };

    Slider.prototype.onstatechange = function(){};

    Slider.prototype.limits = function( x, pointer ){

      if( !this.settings.smooth ){
        var step = this.settings.step*100 / ( this.settings.interval );
        x = Math.round( x/step ) * step;
      }

      var another = this.o.pointers[1-pointer.uid];
      if( another && pointer.uid && x < another.value.prc ) x = another.value.prc;
      if( another && !pointer.uid && x > another.value.prc ) x = another.value.prc;

      if( x < 0 ) x = 0;
      if( x > 100 ) x = 100;

      return Math.round( x*10 ) / 10;
    };

    Slider.prototype.setPointersIndex = function( i ){
      angular.forEach(this.getPointers(), function(pointer, i) {
        pointer.index( i );
      });
    };

    Slider.prototype.getPointers = function(){
      return this.o.pointers;
    };

    Slider.prototype.onresize = function(){
      var self = this;

      this.sizes = {
        domWidth: this.domNode[0].clientWidth,
        domHeight: this.domNode[0].clientHeight,
        domOffset: {
          left: this.domNode[0].offsetLeft,
          top: this.domNode[0].offsetTop,
          width: this.domNode[0].clientWidth,
          height: this.domNode[0].clientHeight
        }
      };

      angular.forEach(this.o.pointers, function(ptr, key) {
        self.redraw(ptr);
      });
    };

    Slider.prototype.update = function(){
      this.onresize();
      this.drawScale();
    };

    Slider.prototype.drawScale = function(){
      this.domNode.find(sliderConstants.SLIDER.selector + "scale span ins").each(function(){
        $(this).css({ marginLeft: -$(this).outerWidth()/2 });
      });
    };

    Slider.prototype.redraw = function( pointer ){
      if( !this.is.init ) return false;

      this.setValue();

      if(this.o.pointers[0] && this.o.pointers[1]) {
        var newPos = !this.settings.vertical ? 
          { left: this.o.pointers[0].value.prc + "%", width: ( this.o.pointers[1].value.prc - this.o.pointers[0].value.prc ) + "%" }
          :
          { top: this.o.pointers[0].value.prc + "%", height: ( this.o.pointers[1].value.prc - this.o.pointers[0].value.prc ) + "%" };
        
        this.o.value.css(newPos);
      }

      this.o.labels[pointer.uid].value.html(this.nice(pointer.value.origin));

      this.redrawLabels( pointer );
    };

    Slider.prototype.redrawLabels = function( pointer ) {

      function setPosition( label, sizes, prc ){
        sizes.margin = -sizes.label/2;
        var domSize = !self.settings.vertical ? self.sizes.domWidth : self.sizes.domHeight;

        var label_left = sizes.border + sizes.margin;
        if( label_left < 0 )
          sizes.margin -= label_left;

        if( sizes.border+sizes.label / 2 > domSize ){
          sizes.margin = 0;
          sizes.right = true;
        } else
        sizes.right = false;

        if (!self.settings.vertical)        
          label.o.css({ left: prc + "%", marginLeft: sizes.margin, right: "auto" });
        else
          label.o.css({ top: prc + "%", marginLeft: 20, bottom: "auto" });
        if( sizes.right ) label.o.css({ left: "auto", right: 0 });
        return sizes;
      }

      var self = this;
      var label = this.o.labels[pointer.uid];
      var prc = pointer.value.prc;

      var sizes = {
        label: label.o[0].offsetWidth,
        right: false,
        border: ( prc * domSize ) / 100
      };

      var another_label = null;
      var another = null;

      if (!this.settings.single){
        another = this.o.pointers[1-pointer.uid];
        another_label = this.o.labels[another.uid];

        switch( pointer.uid ){
          case 0:
          if( sizes.border+sizes.label / 2 > another_label.o[0].offsetLeft-this.sizes.domOffset.left ){
            another_label.o.css({ visibility: "hidden" });
            another_label.value.html( this.nice( another.value.origin ) );

            label.o.css({ visibility: "visible" });

            prc = ( another.value.prc - prc ) / 2 + prc;
            if( another.value.prc != pointer.value.prc ){
              label.value.html( this.nice(pointer.value.origin) + "&nbsp;&ndash;&nbsp;" + this.nice(another.value.origin) );
              sizes.label = label.o[0].clientWidth;
              sizes.border = ( prc * domSize ) / 100;
            }
          } else {
            another_label.o.css({ visibility: "visible" });
          }
          break;
          case 1:
          if( sizes.border - sizes.label / 2 < another_label.o[0].offsetLeft - this.sizes.domOffset.left + another_label.o[0].clientWidth ){
            another_label.o.css({ visibility: "hidden" });
            another_label.value.html( this.nice(another.value.origin) );

            label.o.css({ visibility: "visible" });

            prc = ( prc - another.value.prc ) / 2 + another.value.prc;
            if( another.value.prc != pointer.value.prc ){
              label.value.html( this.nice(another.value.origin) + "&nbsp;&ndash;&nbsp;" + this.nice(pointer.value.origin) );
              sizes.label = label.o[0].clientWidth;
              sizes.border = ( prc * domSize ) / 100;
            }
          } else {
            another_label.o.css({ visibility: "visible" });
          }
          break;
        }
      }

      sizes = setPosition( label, sizes, prc );

      var domSize = !self.settings.vertical ? self.sizes.domWidth : self.sizes.domHeight;

      if( another_label ){
        sizes = {
          label: another_label.o[0].clientWidth,
          right: false,
          border: ( another.value.prc * this.sizes.domWidth ) / 100
        };
        sizes = setPosition( another_label, sizes, another.value.prc );
      }

      this.redrawLimits();
    };

    Slider.prototype.redrawLimits = function() {
      if( this.settings.limits ) {

        var limits = [ true, true ];

        for( var key in this.o.pointers ){

          if( !this.settings.single || key === 0 ){

            var pointer = this.o.pointers[key];
            var label = this.o.labels[pointer.uid];
            var label_left = label.o[0].offsetLeft - this.sizes.domOffset.left;

            var limit = this.o.limits[0];
            if( label_left < limit[0].clientWidth )
              limits[0] = false;

            limit = this.o.limits[1];
            if( label_left + label.o[0].clientWidth > this.sizes.domWidth - limit[0].clientWidth )
              limits[1] = false;
          }
        }

        for( var i=0; i < limits.length; i++ ){
          if( limits[i] ) 
            angular.element(this.o.limits[i]).addClass("animate-show");          
          else
            angular.element(this.o.limits[i]).addClass("animate-hidde");          
        }
      }
    };

    Slider.prototype.setValue = function(){
      var value = this.getValue();
      this.inputNode.attr( "value", value );
      this.onstatechange.call( this, value, this.inputNode );
    };

    Slider.prototype.getValue = function(){
      if(!this.is.init) return false;
      var $this = this;

      var value = "";
      angular.forEach( this.o.pointers, function(pointer, key){
        if( pointer.value.prc !== undefined && !isNaN(pointer.value.prc) ) 
          value += (key > 0 ? ";" : "") + $this.prcToValue( pointer.value.prc );
      });
      return value;
    };

    Slider.prototype.getPrcValue = function(){
      if(!this.is.init) return false;
      var $this = this;

      var value = "";
      $.each( this.o.pointers, function(i){
        if( this.value.prc !== undefined && !isNaN(this.value.prc) ) value += (i > 0 ? ";" : "") + this.value.prc;
      });
      return value;
    };

    Slider.prototype.prcToValue = function( prc ){
      var value;
      if( this.settings.heterogeneity && this.settings.heterogeneity.length > 0 ){
        var h = this.settings.heterogeneity;

        var _start = 0;
        var _from = this.settings.from;

        for( var i=0; i <= h.length; i++ ){
          var v;
          if( h[i] ) 
            v = h[i].split("/");
          else
            v = [100, this.settings.to];        

          if( prc >= _start && prc <= v[0] ) {
            value = _from + ( (prc-_start) * (v[1]-_from) ) / (v[0]-_start);
          }

          _start = v[0];
          _from = v[1];
        }
      } 
      else {
        value = this.settings.from + ( prc * this.settings.interval ) / 100;
      }   

      return this.round( value );
    };

    Slider.prototype.valueToPrc = function( value, pointer ){
      var prc;
      if( this.settings.heterogeneity && this.settings.heterogeneity.length > 0 ){
        var h = this.settings.heterogeneity;

        var _start = 0;
        var _from = this.settings.from;

        for (var i=0; i <= h.length; i++) {
          var v;
          if(h[i])
            v = h[i].split("/");
          else
            v = [100, this.settings.to];        

          if(value >= _from && value <= v[1]){
            prc = pointer.limits(_start + (value-_from)*(v[0]-_start)/(v[1]-_from));
          }

          _start = v[0]; _from = v[1];
        }

      } else {
        prc = pointer.limits((value-this.settings.from)*100/this.settings.interval);
      }

      return prc;
    };

    Slider.prototype.round = function( value ){       
      value = Math.round( value / this.settings.step ) * this.settings.step;

      if( this.settings.round ) 
        value = Math.round( value * Math.pow(10, this.settings.round) ) / Math.pow(10, this.settings.round);
      else 
        value = Math.round( value );
      return value;
    };

    return Slider;

  }])
.directive('attStepSlider', [
      '$compile', '$templateCache','$timeout', '$window', 'slider',
      function(compile, templateCache, timeout, win, Slider) {

        /*
            The MIT License (MIT)
            Copyright (c) 2013 Julien Valéry
        */
        return {
          restrict : 'AE',
          require: '?ngModel',
          scope: { options:'=' },
          priority: 1,
          templateUrl: 'app/scripts/ng_js_att_tpls/slider/attStepSlider.html',
          link : function(scope, element, attrs, ngModel) {
            if(!ngModel) return;

          scope.mainSliderClass = 'step-slider';

          element.after(compile(templateCache.get('app/scripts/ng_js_att_tpls/slider/attStepSlider.html'))
            (scope, function(clonedElement, scope) {          
            scope.tmplElt = clonedElement;
          }));        

          ngModel.$render = function () {
            var singleValue = false;

            if(ngModel.$viewValue.split(";").length == 1){
                ngModel.$viewValue = '0;'+ngModel.$viewValue;
            }

            if (!ngModel.$viewValue && ngModel.$viewValue !== 0) {
              return;
            }

            if (typeof(ngModel.$viewValue) === 'number') {
              ngModel.$viewValue = ''+ngModel.$viewValue;
            }

            if (scope.slider) {
              scope.slider.getPointers()[0].set(ngModel.$viewValue.split(";")[0], true);
              if (ngModel.$viewValue.split(";")[1]) {
                scope.slider.getPointers()[1].set(ngModel.$viewValue.split(";")[1], true);
              }
            }
          };

          var init = function() {

            scope.from = ''+scope.options.from;
            scope.to = ''+scope.options.to;
            if (scope.options.calculate && typeof scope.options.calculate === 'function') {
              scope.from = scope.options.calculate(scope.from);
              scope.to = scope.options.calculate(scope.to);
            }

            var OPTIONS = {
              from: scope.options.from,
              to: scope.options.to,
              step: scope.options.step,
              smooth: scope.options.smooth,
              limits: true,
              round: scope.options.round || false,
              value: ngModel.$viewValue,
              dimension: "",
              scale: scope.options.scale,
              vertical: scope.options.vertical,
              callback: forceApply
            };
            
            OPTIONS.calculate = scope.options.calculate || undefined;
            OPTIONS.onstatechange = scope.options.onstatechange || undefined;
            
            timeout(function() {
              var scaleDiv = scope.tmplElt.find('div')[7];
              scope.slider = angular.element.slider(element, scope.tmplElt, OPTIONS);
              angular.element(scaleDiv).html(scope.generateScale());
              scope.drawScale(scaleDiv);

              initListener();
            });           
          };

          function initListener() {
            angular.element(win).bind('resize', function(event) {
              scope.slider.onresize();
            });
          }
     
          scope.generateScale = function(){
            if( scope.options.scale && scope.options.scale.length > 0 ){
              var str = "";
              var s = scope.options.scale;
              var position = scope.options.vertical ? 'top' : 'left';
              for(var i=0; i < s.length; i++){
                if(i != 0){
                    var scaledPosition = (s[i]/scope.to)*100;
                    str += '<span style="'+ position + ': ' +  scaledPosition+ '%"></span>';
                }
              }

              return str;
            } else return "";

            return "";
          };

          scope.drawScale = function(scaleDiv){
            angular.forEach(angular.element(scaleDiv).find('ins'), function(scaleLabel, key) {
              scaleLabel.style.marginLeft = - scaleLabel.clientWidth / 2;
            });
          };

          var forceApply = function(value) {
            scope.$apply(function() {
                ngModel.$setViewValue(value);
            });
            if (scope.options.callback){
              scope.options.callback(value.split(";")[1]);
            }
          };

          scope.$watch('options', function(value) {
              init();
          });

          scope.$watch('options.disable',function(val){
            if (scope.slider) {
              scope.tmplElt.toggleClass('disabled');              
              scope.slider.disable(val);
            }   
          });

          angular.element.slider = function( inputElement, element, settings) {
            if(!element.data('jslider'))
              element.data('jslider', new Slider( inputElement, element, settings ));
            return element.data('jslider');
          };

        }
      };
}]);
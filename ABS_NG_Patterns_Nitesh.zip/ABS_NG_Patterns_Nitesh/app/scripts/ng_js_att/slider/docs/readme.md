<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-slider directive** is built using angular library.
This can be used for rendering sliders in an application.

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>The slider are used when a user needs to select from a range.</li>
</ul>

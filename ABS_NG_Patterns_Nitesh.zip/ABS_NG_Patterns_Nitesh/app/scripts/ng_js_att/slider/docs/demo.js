var AbsSliderCtrl = function($scope){
    $scope.slider = {
        floor : 0,
        ceiling : 500,
        currentPosVal : 0,
        disabledSlider: 14
    };

    $scope.sliderValue = "20";
    $scope.sliderOptions = {
        from: 0,
        to: 100,
        step: 1,
        smooth: true,
        dimension: " Kps",
        scale: [0,10,20,30,40,50,60,70,80,90],
        callback: function(value) {
                console.log('slider value: '+value);
        }
    };
 };
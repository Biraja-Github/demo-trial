describe('formField', function() {
    var $scope, $compile;

    beforeEach(module('att.abs.helper'));
    beforeEach(module('att.abs.message'));
    beforeEach(module('att.abs.formField'));
    beforeEach(module('app/scripts/ng_js_att_tpls/formField/attFormFieldValidationAlert.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_, _$timeout_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileMarkup = function(markup) {
        var elem = angular.element(markup);
        elem = $compile(elem)($scope);
        $scope.$digest();
        return elem;
    };

    describe('attFormField', function() {
        it('initially label should be hidden', function() {
            var elem = compileMarkup('<input type="text" att-form-field placeholder="Email">');

            expect(elem.find('label')).not.toHaveClass('form-field__label--show');
            expect(elem.find('label')).not.toHaveClass('form-field__label--hide');
        });

        // it('on entering text, the label should show the text of placeholder', function() {
            // var elem = compileMarkup('<input type="text" att-form-field placeholder="Email">');

            // elem.val('abc').triggerHandler('keyup');

            // expect(elem.parent().parent().find('label').text()).toBe(elem.attr('placeholder'));
        // });

        it('on deleting the text after entering, the label should hide', function() {
            var elem = compileMarkup('<input type="text" att-form-field placeholder="Email">');

            elem.val('abc').triggerHandler('keyup');
            elem.val('').triggerHandler('keyup');

            expect(elem.parent().parent().find('label')).toHaveClass('form-field__label--hide');
            expect(elem.parent().parent().find('label')).not.toHaveClass('form-field__label--show');
        });

        it('on removing the focus with some text in the input, label should remain visible', function() {
            var elem = compileMarkup('<input type="text" att-form-field placeholder="Email">');

            elem.val('abc').triggerHandler('keyup');
            elem.triggerHandler('blur');

            expect(elem.parent().parent().find('label')).toHaveClass('form-field__label--show');
            expect(elem.parent().parent().find('label')).not.toHaveClass('form-field__label--hide');
        });

        it('on removing the focus with no text in the input, label should hide and all classes should be removed', function() {
            var elem = compileMarkup('<input type="text" att-form-field placeholder="Email">');

            elem.val('abc').triggerHandler('keyup');
            elem.val('').triggerHandler('keyup');
            elem.triggerHandler('blur');

            expect(elem.parent().parent().find('label')).not.toHaveClass('form-field__label--show');
            expect(elem.parent().parent().find('label')).not.toHaveClass('form-field__label--hide');
        });
    });

    describe('attFormFieldValidation', function() {
        it('initially there will be no errors', function() {
            $scope.password;
            var elem = compileMarkup('<input type="password" ng-model="password" password-strength att-form-field att-form-field-validation placeholder="Password">');

            expect(elem.parent().find('i').eq(0)).toHaveClass('ng-hide');
            expect(elem.parent().find('i').eq(1)).toHaveClass('ng-hide');
            expect(elem.parent().parent()).not.toHaveClass('form-field--error');
            expect(elem.parent().parent()).not.toHaveClass('form-field--success');
        });

        it('on entering password as a string, it will show error', function() {
            $scope.password;
            var elem = compileMarkup('<input type="password" ng-model="password" password-strength att-form-field att-form-field-validation placeholder="Password">');

            elem.val('password').triggerHandler('keyup');

            expect(elem.parent().find('i').eq(0)).not.toHaveClass('ng-hide');
            expect(elem.parent().find('i').eq(1)).toHaveClass('ng-hide');
            expect(elem.parent().parent()).toHaveClass('form-field--error');
            expect(elem.parent().parent()).not.toHaveClass('form-field--success');
        });

        it('on entering business as a string, it will show success', function() {
            $scope.password;
            var elem = compileMarkup('<input type="password" ng-model="password" password-strength att-form-field att-form-field-validation placeholder="Password">');

            elem.val('business').triggerHandler('keyup');

            expect(elem.parent().find('i').eq(0)).toHaveClass('ng-hide');
            expect(elem.parent().find('i').eq(1)).not.toHaveClass('ng-hide');
            expect(elem.parent().parent()).not.toHaveClass('form-field--error');
            expect(elem.parent().parent()).toHaveClass('form-field--success');
        });

        it('on entering abc as a string, nothing will happen', function() {
            $scope.password;
            var elem = compileMarkup('<input type="password" ng-model="password" password-strength att-form-field att-form-field-validation placeholder="Password">');

            elem.val('abc').triggerHandler('keyup');

            expect(elem.parent().find('i').eq(0)).toHaveClass('ng-hide');
            expect(elem.parent().find('i').eq(1)).toHaveClass('ng-hide');
            expect(elem.parent().parent()).not.toHaveClass('form-field--error');
            expect(elem.parent().parent()).not.toHaveClass('form-field--success');
        });
    });

    describe('attFormFieldValidationAlert', function() {


        it('on entering text, the label should show the text of placeholder', function() {
            $scope.email1;
            var elem = compileMarkup('<div att-form-field-validation-alert>' +
                    '<form name="userForm1">' +
                    '<input type="email" name="email1" ng-model="email1" placeholder="Email" required>' +
                    '<att-messages for="userForm1.email1.$error">' +
                    '<div class="form-field__message warning" att-message="required" type="warning"><i class="icon-information"></i><span>This field is require to continue.</span></div>' +
                    '<div class="form-field__message warning" att-message="email" type="error"><i class="icon-info-alert"></i><span>Please enter a valid email.</span></div>' +
                    '</att-messages>' +
                    '</form>' +
                    '</div>');

                elem.find('input').val('abc').triggerHandler('keyup');

                expect(elem.find('label').text()).toBe(elem.find('input').attr('placeholder'));
        });


        xit('initially field is required alert should be shown', function() {
            $scope.email1;
            var elem = compileMarkup('<div att-form-field-validation-alert>' +
                    '<form name="userForm1">' +
                    '<input type="email" name="email1" ng-model="email1" placeholder="Email" required>' +
                    '<att-messages for="userForm1.email1.$error">' +
                    '<div class="form-field__message warning" att-message="required" type="warning"><i class="icon-information"></i><span>This field is require to continue.</span></div>' +
                    '<div class="form-field__message warning" att-message="email" type="error"><i class="icon-info-alert"></i><span>Please enter a valid email.</span></div>' +
                    '</att-messages>' +
                    '</form>' +
                    '</div>');

                expect(elem).toHaveClass('form-field--warning');
                expect(elem).not.toHaveClass('form-field--error');
                expect(elem.find('att-messages').find('div').eq(0).attr('style').indexOf('display: block;') > -1).toBe(true);
                expect(elem.find('att-messages').find('div').eq(1).attr('style').indexOf('display: none;') > -1).toBe(true);
        });

        xit('on enterning invalid email, enter a valid email alert should be shown', function() {
            $scope.email1;
            var elem = compileMarkup('<div att-form-field-validation-alert>' +
                    '<form name="userForm1">' +
                    '<input type="email" name="email1" ng-model="email1" placeholder="Email" required>' +
                    '<att-messages for="userForm1.email1.$error">' +
                    '<div class="form-field__message warning" att-message="required" type="warning"><i class="icon-information"></i><span>This field is require to continue.</span></div>' +
                    '<div class="form-field__message warning" att-message="email" type="error"><i class="icon-info-alert"></i><span>Please enter a valid email.</span></div>' +
                    '</att-messages>' +
                    '</form>' +
                    '</div>');

                elem.find('input').val('abc').triggerHandler('keyup');
                $scope.$digest();

                expect(elem).toHaveClass('erro');
                expect(elem).not.toHaveClass('warning');
                expect(elem.find('att-messages').find('div').eq(0).attr('style').indexOf('display: none;') > -1).toBe(true);
                expect(elem.find('att-messages').find('div').eq(1).attr('style').indexOf('display: block;') > -1).toBe(true);
        });

        xit('on enterning valid email, no alert should be shown', function() {
            $scope.email1;
            var elem = compileMarkup('<div att-form-field-validation-alert>' +
                    '<form name="userForm1">' +
                    '<input type="email" name="email1" ng-model="email1" placeholder="Email" required>' +
                    '<att-messages for="userForm1.email1.$error">' +
                    '<div class="form-field__message warning" att-message="required" type="warning"><i class="icon-information"></i><span>This field is require to continue.</span></div>' +
                    '<div class="form-field__message warning" att-message="email" type="error"><i class="icon-info-alert"></i><span>Please enter a valid email.</span></div>' +
                    '</att-messages>' +
                    '</form>' +
                    '</div>');

                elem.find('input').val('abc@xyx.pq').triggerHandler('keyup');

                expect(elem).not.toHaveClass('form-field--error');
                expect(elem).not.toHaveClass('form-field--warning');
                expect(elem.find('att-messages').find('div').eq(0).attr('style').indexOf('display: none;') > -1).toBe(true);
                expect(elem.find('att-messages').find('div').eq(1).attr('style').indexOf('display: none;') > -1).toBe(true);
        });

        xit('on emptying the field, field is required alert should be shown', function() {
            $scope.email1;
            var elem = compileMarkup('<div att-form-field-validation-alert>' +
                    '<form name="userForm1">' +
                    '<input type="email" name="email1" ng-model="email1" placeholder="Email" required>' +
                    '<att-messages for="userForm1.email1.$error">' +
                    '<div class="form-field__message warning" att-message="required" type="warning"><i class="icon-information"></i><span>This field is require to continue.</span></div>' +
                    '<div class="form-field__message warning" att-message="email" type="error"><i class="icon-info-alert"></i><span>Please enter a valid email.</span></div>' +
                    '</att-messages>' +
                    '</form>' +
                    '</div>');

                elem.find('input').val('abc@xyx.pq').triggerHandler('keyup');
                elem.find('input').val('').triggerHandler('keyup');

                expect(elem).toHaveClass('form-field--warning');
                expect(elem).not.toHaveClass('form-field--error');
                expect(elem.find('att-messages').find('div').eq(0).attr('style').indexOf('display: block;') > -1).toBe(true);
                expect(elem.find('att-messages').find('div').eq(1).attr('style').indexOf('display: none;') > -1).toBe(true);
        });
    });
});

var formFieldController = function ($scope) {
    $scope.password;
    $scope.email1;
    $scope.email2;
	$scope.formRadio = [{'title':'Default','id':'Default'},
	{'title':'Disabled','id':'Disabled'}];
	$scope.formRadio.id = 'Default';
	
	$scope.validForm = [{'title':'Specific Error','id':'Specific'},
	{'title':'Generic Error','id':'Generic'},
	{'title':'Valid','id':'Valid'},
	{'title':'Warning','id':'Warning'}];
    $scope.validForm.id = 'Specific';
	
	$scope.loginForm = [{'title':'Default','id':'Login'},
	{'title':'Warning','id':'Warning'},
	{'title':'Error-incorrect user/pass','id':'Error'}];
    $scope.loginForm.id = 'Login';
	
	$scope.compoundForm = [{'title':'Default','id':'Default'},
	{'title':'Disabled','id':'Disabled'},
	{'title':'Specific Error','id':'Specific'},
	{'title':'Generic Error','id':'Generic'},
	{'title':'Valid','id':'Valid'},
	{'title':'Warning','id':'Warning'}];
    $scope.compoundForm.id = 'Default';
};


angular.module('att.abs.helper', [])

.directive('passwordStrength', ['$log', function ($log) {
    return {
        require: '?ngModel',
        link: function (scope, elem, attr, ctrl) {
            if (!ctrl) {
                $log.error("password-strength :: ng-model directive is required.");
                return;
            }

            ctrl.$valid = false;
            ctrl.$invalid = false;

            elem.bind('keyup', function () {
                if (this.value === "business") {
                    ctrl.$valid = true;
                } else if (this.value === "password") {
                    ctrl.$invalid = true;
                } else if (this.value === '') {
                    ctrl.$valid = false;
                    ctrl.$invalid = false;
                }
            });
        }
    };
}]);

angular.module('att.abs.formField', ['att.abs.message'])

.directive('attFormField',['$compile', function($compile) {
    return {
        priority: 101,
        restrict: 'A',
        controller: ['$scope', function($scope) {
        }],
        link: function(scope, elem, attr, ctrl) {
            elem.wrap('<div class="form-field"></div>');
             elem.parent().prepend($compile(angular.element('<label class="form-field__label">'+attr.placeholder+'<i class="icon-information" tooltip="'+attr.tooltipContent+'">&nbsp;</i></label>'))(scope));
            elem.wrap('<div class="form-field-input-container"></div>');

            elem.bind('keyup', function() {
                if (this.value !== '') {
                    elem.parent().parent().find('label').addClass('form-field__label--show').removeClass('form-field__label--hide');
                } else {
                    elem.parent().parent().find('label').addClass('form-field__label--hide').removeClass('form-field__label--show');                    
                }
            });

            elem.bind('blur', function() {
                if (this.value === '') {
                    elem.parent().parent().find('label').removeClass('form-field__label--hide');
                }
            });
        }
    };
}])

.directive('attFormFieldValidation', ['$compile', '$log', function($compile, $log) {
    return {
        priority: 102,
        scope: {},
        restrict: 'A',
        require: ['?ngModel', '?attFormField'],
        link: function(scope, elem, attr, ctrl) {
            var ngCtrl = ctrl[0];
            var attFormFieldCtrl = ctrl[1];
            scope.valid = "";
            
            if (!ngCtrl) {
                $log.error("att-form-field-validation :: ng-model directive is required.");
                return;
            }
            if (!attFormFieldCtrl) {
                $log.error("att-form-field-validation :: att-form-field directive is required.");
                return;
            }

            elem.parent().append($compile(angular.element('<i class="form-field--error" ng-show="valid===false">&nbsp;</i>'))(scope));
            elem.parent().append($compile(angular.element('<i class="form-field--success" ng-show="valid===true">&nbsp;</i>'))(scope));

            scope.$watch('valid', function(value) {
                if (value === true) {
                    elem.parent().parent().addClass('form-field--success');
                } else if (value === false) {
                    elem.parent().parent().addClass('form-field--error');
                } else {
                    elem.parent().parent().removeClass('form-field--success').removeClass('form-field--error');
                }
            });

            elem.bind('keyup', function() {
                if (ngCtrl.$valid === true) {
                    scope.valid = true;
                } else if (ngCtrl.$invalid === true) {
                    scope.valid = false;
                } else {
                    scope.valid = "";
                }
                scope.$apply();
            });
        }
    };
}])

.directive('attFormFieldValidationAlert', ['$timeout', function($timeout) {
        return {
        scope: {},
        restrict: 'EA',
        replace: true,
        transclude: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/formField/attFormFieldValidationAlert.html',
        link: function(scope, elem, attr, ctrl) {
            scope.showLabel = false;
            scope.hideLabel = false;
            scope.errorMessage = false;
            scope.warningMessage = false;
            
            var checkMessageType = function() {
                if (elem.find('att-messages').attr('message-type') === 'error') {
                    scope.errorMessage = true;
                    scope.warningMessage = false;
                } else if (elem.find('att-messages').attr('message-type') === 'warning') {
                    scope.errorMessage = false;
                    scope.warningMessage = true;
                } else {
                    scope.errorMessage = false;
                    scope.warningMessage = false;
                }
            };

          //  elem.find('label').text(elem.find('input').attr('placeholder'));
			scope.tooltipContent=elem.find('input').attr('tooltip-content');
			scope.placeholder=elem.find('input').attr('placeholder');
            elem.find('input').bind('keyup', function() {
                if (this.value !== '') {
                    scope.showLabel = true;
                    scope.hideLabel = false;
                } else {
                    scope.showLabel = false;
                    scope.hideLabel = true;
                }
                checkMessageType();
                scope.$apply();
            });

            elem.find('input').bind('blur', function() {
                if (this.value === '') {
                    scope.showLabel = false;
                    scope.hideLabel = false;
                }
                scope.$apply();
            });
            
            $timeout(function() {
                checkMessageType();
            }, 100);
        }
    };
}])
.constant("CoreFormsUiConfig", {
            phoneMask: '(___) ___-____'
        })
.directive('attPhoneMask', ['$parse', 'CoreFormsUiConfig', function($parse, CoreFormsUiConfig) {
                return {
                    require: 'ngModel',
                    link: function(scope, iElement, iAttrs, ctrl) {

                        var B = navigator.userAgent.toLowerCase(), C = B.indexOf("android") > -1;
                        var A = '';
                        if (C) {
                            A = "__________";

                        }
                        else {
                            A = CoreFormsUiConfig.phoneMask;
                        }
                        iElement.attr("maxlength", A.length);

                        var checkValidity = function(unmaskedValue) {
                            var valid = false;
                            if (unmaskedValue){
                                valid = (unmaskedValue.length === 10);}
                            ctrl.$setValidity("mask", valid);
                            return valid;
                        };

                        var doGetCaretPosition = function(C) {

                            var B = 0, A;
                            if (document.selection) {
                                A = document.selection.createRange();
                                if(C.value === null)
                                {                                   
                                    A.moveStart("character", 0);
                                }
                                else
                                {
                                    A.moveStart("character", C.value.length);
                                }
                                B = A.text.length;
                            }
                            else {
                                if (C.selectionStart || C.selectionStart === "0") {
                                    B = C.selectionStart;
                                }
                            }
                            return(B);

                        };

                        var setCaretPosition = function(B, C) {

                            if (B.setSelectionRange) {
                                B.setSelectionRange(C, C);
                            }
                            else {
                                if (B.createTextRange) {
                                    var A = B.createTextRange();
                                    A.collapse(true);
                                    A.moveEnd("character", C);
                                    A.moveStart("character", C);
                                    A.select();
                                }
                            }

                        };

                        var maskInput = function(unmaskedValue) {
                            var E, D = unmaskedValue;
                            if (!D.length) {
                                return "";
                            }
                            var H, L, K, G, J, I;
                            J = [];
                            G = A.split("");
                            I = G.length;
                            L = D.substring(0, A.length);
                            K = D.replace(/[^0-9]/g, "").split("");
                            for (E = 0; E < I; E++) {
                                J.push(G[E] === "_" ? K.shift() : G[E]);
                                if (K.length === 0) {
                                    break;
                                }
                            }
                            D = J.join("");
                            setCaretPosition(D, H + Math.abs(L.length - J.length));
                            return D;
                        };


                        var handleKeyup = function(e) {
                            var E, D = iElement.val();
                            if (!D.length) {
                                return;
                            }
                            var H, L, K, G, J, I;
                            J = [];
                            G = A.split("");
                            I = G.length;
                            H = doGetCaretPosition(iElement);
                            L = D.substring(0, A.length);
                            K = D.replace(/[^0-9]/g, "").split("");
                            for (E = 0; E < I; E++) {
                                J.push(G[E] === "_" ? K.shift() : G[E]);
                                if (K.length === 0) {
                                    break;
                                }
                            }
                            D = J.join("");
                            setCaretPosition(D, H + Math.abs(L.length - J.length));
                            if (D === '('){
                                D = '';}
                            ctrl.$setViewValue(D);
                            scope.$apply(ctrl.$render());
                        };


                        // since we are only allowing 0-9, why even let the keypress go forward?
                        // also added in delete... in case they want to delete :)
                        var handlePress = function(e) {
                            var event = e || {};
                            var whichevent = e.which;

                            if (e.which) {
                                if (e.which < 48 || e.which > 57) {

                                    if (e.which !== 8 && e.which !== 9 && e.which !== 46 && e.which !== 13 && e.which !== 37 && e.which !== 39){
                                        var temp = e.preventDefault ? e.preventDefault() : e.returnValue = false;}
                                }
                                /*else {
                                 var value = ctrl.$modelValue;
                                 if (value && value.length >= 10)
                                 {
                                 e.preventDefault ? e.preventDefault():e.returnValue = false;
                                 }
                                 }*/
                            }
                        };


                        // i moved this out because i thought i might need focus as well..
                        iElement.bind('keyup', handleKeyup);
                        iElement.bind('keydown', handlePress);


                        // to handle setting the model as the view changes
                        var parser = function(fromViewValue) {
                            var clean = "";
                            if (fromViewValue && fromViewValue.length > 0) {
                                clean = fromViewValue.replace(/[^0-9]/g, '');
                            }
                            checkValidity(clean);
                            return clean;
                        };

                        //to handle reading the model and formatting it
                        var formatter = function(fromModelView) {
                            var input = '';
                            checkValidity(fromModelView);
                            if (fromModelView){
                                input = maskInput(fromModelView);}
                            return input;
                        };

                        ctrl.$parsers.push(parser);
                        ctrl.$formatters.push(formatter);
                    }

                };

            }]);

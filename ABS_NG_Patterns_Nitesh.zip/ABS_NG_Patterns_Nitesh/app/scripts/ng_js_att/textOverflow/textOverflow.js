angular.module('att.abs.textOverflow', [])
        .constant('textDefaultOptions', {
            width: '50%'
        })
.directive('attTextOverflow', ['textDefaultOptions','$compile',function(textDefaultOptions,$compile)
{
    return {
        restrict: 'A',
        link: function(scope, elem, attrs, ctrl)
        {
            var tooltipText = elem.text();
            elem.addClass('text-ellipsis');
            attrs.$observe('attTextOverflow', function(val){
                if(val)
                    elem.css({"width":val});
                else
                    elem.css({"width":textDefaultOptions.width});
            });
            if(!(elem.attr('tooltip'))){
                elem.attr("tooltip", tooltipText);
                elem.attr("tooltip-placement", 'above');
                var newElem =  angular.element(elem);
                $compile(newElem)(scope);
            }
        }
    };
}]);

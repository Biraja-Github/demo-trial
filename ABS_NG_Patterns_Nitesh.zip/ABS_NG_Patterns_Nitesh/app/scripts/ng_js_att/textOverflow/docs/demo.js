var textOverflowController = function($scope){ 
   
};

angular.module('att.abs.table', ['att.abs.utilities'])
.constant('tableConfig', {
    defaultSortPattern: false, //true for descending & false for ascending
    highlightSearchStringClass: 'tablesorter-search-highlight'
})

.directive('attTable', ['$filter', function($filter) {
    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        scope: {
            tableData: "=",
            viewPerPage: "=",
            currentPage: "=",
            totalPage: "=",
            searchCategory: "=",
            searchString: "="
        },
        require: 'attTable',
        templateUrl: 'app/scripts/ng_js_att_tpls/table/attTable.html',
        controller: ['$scope', function($scope) {
            this.headers = [];
            this.currentSortIndex = null;
            this.setIndex = function(headerScope) {
                this.headers.push(headerScope);
            };
            this.getIndex = function(headerName) {
                for (var i = 0; i < this.headers.length; i++) {
                    if (this.headers[i].headerName === headerName) {
                        return this.headers[i].index;
                    }
                }
                return null;
            };
            this.sortData = function(columnIndex, reverse) {
                $scope.$parent.columnIndex = columnIndex;
                $scope.$parent.reverse = reverse;
                this.currentSortIndex = columnIndex;
                $scope.currentPage = 1;
            };
            this.getSearchString = function() {
                return $scope.searchString;
            };
        }],
        link: function(scope, elem, attr, ctrl) {
            scope.searchCriteria = {};
            scope.$watchCollection('tableData', function(value) {
                if(value && !isNaN(value.length)) {
                    scope.totalRows = value.length;
                }
            });
            var showRows = function(rowIndex) {
                rowIndex = rowIndex + 1;
                if (((rowIndex >= ((scope.currentPage - 1) * scope.viewPerPage + 1)) && (rowIndex <= ((scope.currentPage) * scope.viewPerPage)))) {
                    return true;
                } else {
                    return false;
                }
            };
            scope.$parent.showRows = showRows;
            scope.$watch('currentPage', function(val) {
                scope.$parent.currentPage = val;
            });
            scope.$watch('viewPerPage', function(val) {
                scope.$parent.viewPerPage = val;
            });
            scope.$watch(function() {
                return scope.totalRows / scope.viewPerPage;
            }, function(value) {
                if(!isNaN(value)) {
                    scope.totalPage = Math.ceil(value);
                    scope.currentPage = 1;
                }
            });
            var resetSearchCriteria = function() {
                scope.searchCriteria = {};
            };
            scope.$watch('searchCategory', function(value) {
                if (angular.isDefined(value) && value !== null && value !== "" && angular.isDefined(scope.searchString) && scope.searchString !== null && scope.searchString !== "") {
                    var index = ctrl.getIndex(value);
                    if (index !== null) {
                        resetSearchCriteria();
                        scope.searchCriteria[index] = scope.searchString;
                    } else {
                        resetSearchCriteria();
                    }
                } else if (angular.isDefined(scope.searchString) && scope.searchString !== null && scope.searchString !== "" && (!angular.isDefined(value) || value === null || value === "")) {
                    scope.searchCriteria = {
                        $: scope.searchString
                    };
                } else {
                    resetSearchCriteria();
                }
            });
            scope.$watch('searchString', function(value) {
                if (angular.isDefined(value) && value !== null && value !== "" && angular.isDefined(scope.searchCategory) && scope.searchCategory !== null && scope.searchCategory !== "") {
                    var index = ctrl.getIndex(scope.searchCategory);
                    if (index !== null) {
                        resetSearchCriteria();
                        scope.searchCriteria[index] = value;
                    } else {
                        resetSearchCriteria();
                    }
                } else if (angular.isDefined(value) && value !== null && value !== "" && (!angular.isDefined(scope.searchCategory) || scope.searchCategory === null || scope.searchCategory === "")) {
                    scope.searchCriteria = {
                        $: value
                    };
                } else {
                    resetSearchCriteria();
                }
            });
            scope.$watchCollection('searchCriteria', function(val) {
                scope.$parent.searchCriteria = val;
                scope.totalRows = ($filter('filter')(scope.tableData, val, false)).length;
                scope.currentPage = 1;
            });
        }
    };
}])

.directive('attTableRow', [function() {
    return {
        restrict: 'EA',
        compile: function (elem, attr) {
            if (attr.type === 'header') {
                elem.find('tr').eq(0).addClass('tablesorter-headerRow');
            } else if (attr.type === 'body') {
                var html = elem.children();
                html.attr('ng-repeat', attr.rowRepeat.concat(" | orderBy : columnIndex : reverse | filter : searchCriteria : false"));
                html.attr('ng-class', "{'alt-row': $even,'normal-row': $odd}");
                html.attr('ng-show', 'showRows($index)');
                elem.append(html);
            }
        }
    };
}])

.directive('attTableHeader', ['tableConfig', function(tableConfig) {
    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        scope: {
            sortable: '@',
            defaultSort: '@',
            index: '@key'
        },
        require: '^attTable',
        templateUrl: 'app/scripts/ng_js_att_tpls/table/attTableHeader.html',
        link: function(scope, elem, attr, ctrl) {
            var reverse = tableConfig.defaultSortPattern;
            scope.headerName = elem.text();
            scope.sortPattern = null;
            ctrl.setIndex(scope);
            scope.$watch(function() {
                return elem.text();
            }, function(value) {
                scope.headerName = value;
            });
            scope.sort = function(sortType) {
                if(sortType === true || sortType === false) {
                    reverse = sortType;
                }
                ctrl.sortData(scope.index, reverse);
                scope.sortPattern = reverse ? 'desc' : 'asc';
                reverse = !reverse;
            };
            scope.$watch(function() {
                return ctrl.currentSortIndex;
            }, function(value) {
                if (value !== scope.index) {
                    scope.sortPattern = null;
                }
            });
            if(scope.sortable !== 'false') {
                if(scope.defaultSort === 'A' || scope.defaultSort === 'a') {
                    scope.sort(false);
                } else if(scope.defaultSort === 'D' || scope.defaultSort === 'd') {
                    scope.sort(true);
                }
            }
            elem.bind('blur', function() {
                reverse = tableConfig.defaultSortPattern;
                scope.$apply();
            });
        }
    };
}])

.directive('attTableBody', ['$filter', '$timeout', 'tableConfig', function($filter, $timeout, tableConfig) {
    return {
        restrict: 'EA',
        require: '^attTable',
        replace: true,
        transclude: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/table/attTableBody.html',
        link: function (scope, elem, attr, ctrl) {
            var highlightSearchStringClass = tableConfig.highlightSearchStringClass;
            var searchString = "";
            $timeout(function () {
                var actualHtml = elem.children();
                scope.$watch(function () {
                    return ctrl.getSearchString();
                }, function (val) {
                    searchString = val;
                    clearWrap(elem);
                    if (actualHtml.length > 0) {
                        traverse(elem);
                    } else {
                        wrapElement(elem);
                    }
                });
            }, 100);

            var traverse = function (elem) {
                var innerHtml = elem.children();
                if (innerHtml.length > 0) {
                    for (var i = 0; i < innerHtml.length; i++) {
                        traverse(innerHtml.eq(i));
                    }
                } else {
                    wrapElement(elem);
                    return;
                }
            };

            var wrapElement = function (elem) {
                var text = elem.text();
                elem.html('');
                elem.append($filter('highlight')(text, searchString, highlightSearchStringClass));
            };

            var clearWrap = function (elem) {
                var elems = elem.find('*');
                for (var i = 0; i < elems.length; i++) {
                    if (elems.eq(i).attr('class') && elems.eq(i).attr('class').indexOf(highlightSearchStringClass) !== -1) {
                        var text = elems.eq(i).text();
                        elems.eq(i).replaceWith(text);
                    }
                }
            };
        }
    };
}]);

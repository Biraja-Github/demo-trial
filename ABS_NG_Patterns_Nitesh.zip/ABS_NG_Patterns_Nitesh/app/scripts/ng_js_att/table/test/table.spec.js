describe("attTable", function() {
    var scope, compile;
    var markup = '<table att-table table-data="tableData" view-per-page="viewPerPage" current-page="currentPage" search-category="searchCategory" search-string="searchString" total-page="totalPage"><thead att-table-row type="header"><tr><th att-table-header key="requestId">{{tableHeader[0]}}</th><th att-table-header key="requestType" sortable="false">{{tableHeader[1]}}</th><th att-table-header key="requestor" sortable="false">{{tableHeader[2]}}</th><th att-table-header key="user">{{tableHeader[3]}}</th><th att-table-header key="date" sortable="true">{{tableHeader[4]}}</th></tr></thead><tbody att-table-row type="body" row-repeat="rowData in tableData"><tr><td att-table-body><a href="#">{{rowData[\'requestId\']}}</a></td><td att-table-body>{{rowData[\'requestType\']}}</td><td att-table-body>{{rowData[\'requestor\']}}</td><td att-table-body>{{rowData[\'user\']}}</td><td att-table-body>{{rowData[\'date\']}}</td></tr></tbody></table>';

    beforeEach(module("att.abs.table"));
    beforeEach(module('app/scripts/ng_js_att_tpls/table/attTable.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/table/attTableHeader.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/table/attTableBody.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));

    function htmlcomilemarkup(htmlmarkup) {
        scope.tableHeader = ["Request Id", "Request Type", "Requestor", "User", "Date"];
        scope.tableData = [
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"}
        ];
        var elem = angular.element(htmlmarkup);
        elem = compile(elem)(scope);
        scope.$digest();
        return elem;
    };

    it("should sort the table on the request-id column, on clicking, to desc or asc order", function() {
        var compiletablesort = htmlcomilemarkup(markup);
        //normal table
        var getdata = compiletablesort.find('tbody').children();
        expect(getdata.eq(0).children().eq(0).text()).toBe("10391004172");
        expect(getdata.eq(1).children().eq(0).text()).toBe("10391004170");
        expect(getdata.eq(2).children().eq(0).text()).toBe("10391004179");
        expect(getdata.eq(3).children().eq(0).text()).toBe("10391004171");
        expect(getdata.eq(4).children().eq(0).text()).toBe("10391004173");
        expect(getdata.eq(5).children().eq(0).text()).toBe("10391004180");
        expect(getdata.eq(6).children().eq(0).text()).toBe("10391004174");
        var getheader = compiletablesort.find('thead').find('th').eq(0);
        // descending order for integer
        getheader.click();
        var getdata = compiletablesort.find('tbody').find('tr');
        expect(getdata.eq(0).find('td').eq(0).text()).toBe("10391004170");
        expect(getdata.eq(1).find('td').eq(0).text()).toBe("10391004171");
        expect(getdata.eq(2).find('td').eq(0).text()).toBe("10391004172");
        expect(getdata.eq(3).find('td').eq(0).text()).toBe("10391004173");
        expect(getdata.eq(4).find('td').eq(0).text()).toBe("10391004174");
        expect(getdata.eq(5).find('td').eq(0).text()).toBe("10391004179");
        expect(getdata.eq(6).find('td').eq(0).text()).toBe("10391004180");
        // ascending order for integer
        getheader.click();
        var getdata = compiletablesort.find('tbody').find('tr');
        expect(getdata.eq(0).find('td').eq(0).text()).toBe("10391004180");
        expect(getdata.eq(1).find('td').eq(0).text()).toBe("10391004179");
        expect(getdata.eq(2).find('td').eq(0).text()).toBe("10391004174");
        expect(getdata.eq(3).find('td').eq(0).text()).toBe("10391004173");
        expect(getdata.eq(4).find('td').eq(0).text()).toBe("10391004172");
        expect(getdata.eq(5).find('td').eq(0).text()).toBe("10391004171");
        expect(getdata.eq(6).find('td').eq(0).text()).toBe("10391004170");

    });
    it("should sort the table on the user-name column, on clicking, to desc or asc order", function() {
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody').children();
        expect(getdata.eq(0).children().eq(3).text()).toBe("Frank Castle");
        expect(getdata.eq(1).children().eq(3).text()).toBe("Abigail Miller");
        expect(getdata.eq(2).children().eq(3).text()).toBe("Ashley Hall");
        expect(getdata.eq(3).children().eq(3).text()).toBe("Derek Santos");
        expect(getdata.eq(4).children().eq(3).text()).toBe("Diana Taylor");
        expect(getdata.eq(5).children().eq(3).text()).toBe("George Hines");
        expect(getdata.eq(6).children().eq(3).text()).toBe("Johnson Rhodes");
        var getheader = compiletablesort.find('thead').find('th').eq(3);
        //descending order for integer
        getheader.click();
        var getdata = compiletablesort.find('tbody').find('tr');
        expect(getdata.eq(0).find('td').eq(3).text()).toBe("Abigail Miller");
        expect(getdata.eq(1).find('td').eq(3).text()).toBe("Ashley Hall");
        expect(getdata.eq(2).find('td').eq(3).text()).toBe("Derek Santos");
        expect(getdata.eq(3).find('td').eq(3).text()).toBe("Diana Taylor");
        expect(getdata.eq(4).find('td').eq(3).text()).toBe("Frank Castle");
        expect(getdata.eq(5).find('td').eq(3).text()).toBe("George Hines");
        expect(getdata.eq(6).find('td').eq(3).text()).toBe("Johnson Rhodes");
        //ascending order or alphapets
        getheader.click();
        var getdata = compiletablesort.find('tbody').find('tr');
        expect(getdata.eq(0).find('td').eq(3).text()).toBe("Johnson Rhodes");
        expect(getdata.eq(1).find('td').eq(3).text()).toBe("George Hines");
        expect(getdata.eq(2).find('td').eq(3).text()).toBe("Frank Castle");
        expect(getdata.eq(3).find('td').eq(3).text()).toBe("Diana Taylor");
        expect(getdata.eq(4).find('td').eq(3).text()).toBe("Derek Santos");
        expect(getdata.eq(5).find('td').eq(3).text()).toBe("Ashley Hall");
        expect(getdata.eq(6).find('td').eq(3).text()).toBe("Abigail Miller");
    });
    it("should check that the alternate rows are having different color classes", function() {
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody').children();
        expect(getdata.eq(0)).toHaveClass('alt-row');
        expect(getdata.eq(1)).toHaveClass('normal-row');
        expect(getdata.eq(2)).toHaveClass('alt-row');
        expect(getdata.eq(3)).toHaveClass('normal-row');
        expect(getdata.eq(4)).toHaveClass('alt-row');
        expect(getdata.eq(5)).toHaveClass('normal-row');
        expect(getdata.eq(6)).toHaveClass('alt-row');
    });
    it("should check that number of hidden rows are 5 when view per page is 2 and total number of rows are 7", function() {
        scope.viewPerPage = 2;
        scope.currentPage = 1;
        scope.$digest();
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody');
        expect(getdata.find('tr.ng-hide').length).toBe(5);
    });
    it("should check the number of hidden rows, when total number rows are < =10", function() {
        //when view per page is 10
        scope.viewPerPage = 10;
        scope.currentPage = 1;
        scope.$digest();
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody');       
        expect(getdata.find('tr').length).toBe(7);
        expect(getdata.find('tr.ng-hide').length).toBe(0);
        //when view per page is 20
        scope.viewPerPage = 20;
        scope.currentPage = 1;
        scope.$digest();
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody');
        expect(getdata.find('tr').length).toBe(7);
        expect(getdata.find('tr.ng-hide').length).toBe(0);
        //when view per page is All       
        scope.viewPerPage = scope.tableData.length;
        scope.currentPage = 1;
        scope.$digest();
        var compiletablesort = htmlcomilemarkup(markup);
        var getdata = compiletablesort.find('tbody');
        expect(getdata.find('tr').length).toBe(7);
        expect(getdata.find('tr.ng-hide').length).toBe(0);
    });
    it("should check the number of hidden rows, when total number rows are > 10 and <=20", function() {
        scope.tableHeader = ["Request Id", "Request Type", "Requestor", "User", "Date"];
        scope.tableData = [
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"}
        ];
        var compiletablesort = markup;
        var elem = angular.element(compiletablesort);
        elem = compile(elem)(scope);
        scope.$apply(elem);
        //when view per page is 10
        scope.$digest();
        scope.viewPerPage = 10;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr').length).toBe(19);
        expect(getdata.find('tr.ng-hide').length).toBe(9);
        //when view per page is 20
        scope.viewPerPage = 20;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr.ng-hide').length).toBe(0);
        //when view per page is All       
        scope.viewPerPage = scope.tableData.length;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr.ng-hide').length).toBe(0);
    });
    it("should check the number of hidden rows, when total number rows are > 20", function() {
        scope.tableHeader = ["Request Id", "Request Type", "Requestor", "User", "Date"];
        scope.tableData = [
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
            {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
            {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
            {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
            {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
            {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
            {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
            {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"}
        ];
        var compiletablesort = markup;
        var elem = angular.element(compiletablesort);
        elem = compile(elem)(scope);
        scope.$apply(elem);
        //when view per page is 10
        scope.$digest();
        scope.viewPerPage = 10;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr').length).toBe(24);// 23 + one extra empty row at the top.
        expect(getdata.find('tr.ng-hide').length).toBe(14);
        //when view per page is 20
        scope.viewPerPage = 20;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr').length).toBe(24);// 23 + one extra empty row at the top.
        expect(getdata.find('tr.ng-hide').length).toBe(4);// 20 shown, 3 hidden
        //when view per page is All       
        scope.viewPerPage = scope.tableData.length;
        scope.currentPage = 1;
        scope.$digest();
        var getdata = elem.find('tbody');
        expect(getdata.find('tr').length).toBe(24);// 23 + one extra empty row at the top.
        expect(getdata.find('tr.ng-hide').length).toBe(0);// All 23 shown
    });
});

function attTableCtrl($scope) {
    $scope.tableHeader = ["Request Id", "Request Type", "Requestor", "User", "Date"];
    $scope.tableData = [
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"},
        {requestId: "10391004172", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Frank Castle", date: "Today"},
        {requestId: "10391004170", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Abigail Miller", date: "Today"},
        {requestId: "10391004179", requestType: "Update IMEI", requestor: "BAN_Admin", user: "Ashley Hall", date: "Yesterday"},
        {requestId: "10391004171", requestType: "Update rate plan with device", requestor: "BAN_Admin", user: "Derek Santos", date: "2 days"},
        {requestId: "10391004173", requestType: "Update features", requestor: "BAN_Admin", user: "Diana Taylor", date: "3 days"},
        {requestId: "10391004180", requestType: "Update IMEI", requestor: "BAN_Admin", user: "George Hines", date: "Today"},
        {requestId: "10391004174", requestType: "Modify mobile share group", requestor: "BAN_Admin", user: "Johnson Rhodes", date: "Today"}
    ];
    $scope.viewPerPage = 5;
    $scope.currentPage = 2;
    $scope.totalPage;
    $scope.searchCategory = "";
    $scope.searchString = "";
    $scope.radio = {
        value: ""
    };
}

 var CarouselDemoCtrl = function($scope){
  $scope.myInterval = 50000;
$scope.slides = [
    {
      image: '../images/uielements/carousel-slide1.jpg'
    },   
    {
      image: '../images/uielements/carousel-slide2.jpg'
    },
    {
      image: '../images/uielements/carousel-slide3.jpg'
    }
  ];
 
};
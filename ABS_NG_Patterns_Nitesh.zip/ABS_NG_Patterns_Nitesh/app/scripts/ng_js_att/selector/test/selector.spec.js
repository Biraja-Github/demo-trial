describe('selector', function() {
    var scope, compile;
    beforeEach(module('att.abs.selector'));
    beforeEach(module('att.abs.tooltip'));
    beforeEach(module('app/scripts/ng_js_att_tpls/selector/selector.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/selector/colorselector.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/selector/storageselector.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/tooltip/tooltip-popup.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));
    var compileMarkup = function(markup) {
        var elem = angular.element(markup);
        elem = compile(elem)(scope);
        scope.$digest(elem);
        return elem;
    };
    it("should select while click the color icon and return the color value to scope model", function() {
        scope.color = {
            selectedcolor: '#44c7f4'
        };
        var elesteptracker = compileMarkup("<selector type='color'><color-selector ng-model='color.selectedcolor'colors='#c3d72d'></color-selector><color-selector ng-model='color.selectedcolor' colors='#44c7f4'></color-selector><color-selector ng-model='color.selectedcolor' colors='#ffee00'></color-selector><color-selector ng-model='color.selectedcolor' colors='#ee5000'></color-selector><color-selector ng-model='color.selectedcolor' colors='#fff'></color-selector></selector>");
        expect(scope.color.selectedcolor).toBe('#44c7f4');
        var tragetclass = elesteptracker.children().children().eq(0).click();
        expect(scope.color.selectedcolor).toBe('#c3d72d');
        var tragetclass = elesteptracker.children().children().eq(1).click();
        expect(scope.color.selectedcolor).toBe('#44c7f4');
        var tragetclass = elesteptracker.children().children().eq(2).click();
        expect(scope.color.selectedcolor).toBe('#ffee00');
        var tragetclass = elesteptracker.children().children().eq(3).click();
        expect(scope.color.selectedcolor).toBe('#ee5000');
        var tragetclass = elesteptracker.children().children().eq(4).click();
        expect(scope.color.selectedcolor).toBe('#fff');
        expect(tragetclass).toHaveClass('att-radio--on');
    });
    it("should select while click the storage icon and return the storage value to the scope model", function() {
        scope.storage = {
            selectedvalue: '16'
        };
        var elesteptracker = compileMarkup("<selector type='storage'><storage-selector ng-model='storage.selectedvalue' storage-unit='GB' storage-value='8'></storage-selector><storage-selector ng-model='storage.selectedvalue' storage-unit='GB' storage-value='16'></storage-selector><storage-selector ng-model='storage.selectedvalue' storage-unit='GB' storage-value='32'></storage-selector><storage-selector ng-model='storage.selectedvalue' storage-unit='GB' storage-value='64'></storage-selector><storage-selector ng-model='storage.selectedvalue' storage-unit='GB' storage-value='128'></storage-selector></selector>	");
        expect(scope.storage.selectedvalue).toBe('16');
        var tragetclass = elesteptracker.children().children().eq(0).click();
        expect(scope.storage.selectedvalue).toBe('8');
        var tragetclass = elesteptracker.children().children().eq(1).click();
        expect(scope.storage.selectedvalue).toBe('16');
        var tragetclass = elesteptracker.children().children().eq(2).click();
        expect(scope.storage.selectedvalue).toBe('32');
        var tragetclass = elesteptracker.children().children().eq(3).click();
        expect(scope.storage.selectedvalue).toBe('64');
        var tragetclass = elesteptracker.children().children().eq(4).click();
        expect(scope.storage.selectedvalue).toBe('128');
        expect(tragetclass).toHaveClass('att-radio--on');
    });
    it("should support outofstock in storage selector", function() {
        var elesteptracker = compileMarkup("<selector type='storage'><storage-selector ng-model='selectedvalue' outofstock='true' storage-unit='GB' storage-value='64'></storage-selector></selector>");
        var tragetclass = elesteptracker.children().children();
        tragetclass.click();
        expect(tragetclass).toHaveClass('att-radio--on');
        expect(tragetclass).toHaveClass('att-radio--disabled');
    });
    it("should support outofstock in color selector", function() {
        var elesteptracker = compileMarkup("<selector type='color'><color-selector ng-model='selectedcolor' outofstock='true' colors='yellow'></color-selector></selector>");
        var tragetclass = elesteptracker.children().children();
        tragetclass.click();
        expect(tragetclass).toHaveClass('att-radio--on');
        expect(tragetclass).toHaveClass('att-radio--disabled');
    });

});
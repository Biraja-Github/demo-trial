angular.module('att.abs.selector', ['att.abs.position', 'att.abs.tooltip'])
    .directive("selector", ['$isElement', '$document', function($isElement, $document) {
        return {
            replace: true,
            restrict: 'AE',
            replace: true,
            transclude: true,
            scope: {
                type: '@',
                selectorClass: '@'
            },
            templateUrl: 'app/scripts/ng_js_att_tpls/selector/selector.html',
            link: function(scope, elem, attrs) {			
               
            }
        };
    }])
    .directive("colorSelector", ['$compile', function($compile) {
        return {
            scope: {
                selected: '=ngModel',
                colors: '@',
                outofstock: '@',
                tooltipLabel: '@'
            },
            restrict: 'AE',
            replace: true,
            templateUrl: 'app/scripts/ng_js_att_tpls/selector/colorselector.html',
            link: function(scope, elem, attrs) {
                scope.applycolor = {
                    'background-color': scope.colors
                };
                scope.selectedcolor = function(iconColor) {
                    scope.selected = iconColor;
                };
				scope.focused = function(focuscolor){
					if(scope.selected == focuscolor) return true; else return false;
				};
                var wrapcont = angular.element('<span class="colorselector_tooltip" tooltip="{{tooltipLabel}}" tooltip-placement="above" tooltip-style="light">' + elem.prop('outerHTML') + '</span>');
                var newWrapcont = $compile(wrapcont)(scope);
                elem.replaceWith(newWrapcont);
			}
        }
    }])
    .directive("storageSelector", ['$compile', function($compile) {
        return {
            scope: {
                storageValue: '@',
                storageUnit: '@',
                selected: '=ngModel',
                outofstock: '@',
                tooltipLabel: '@'
            },
            restrict: 'AE',
            replace: true,
            templateUrl: 'app/scripts/ng_js_att_tpls/selector/storageselector.html',
            link: function(scope, elem, attr) {
                scope.selectedvalue = function(value) {
                    scope.selected = value;                 
                };
				scope.focused = function(focusvalue){
					if(scope.selected == focusvalue) return true; else return false;
				};
                var wrapcont = angular.element('<span style="display:inline-block" tooltip="{{tooltipLabel}}" tooltip-placement="above" tooltip-style="light">' + elem.prop('outerHTML') + '</span>');
                var newWrapcont1 = $compile(wrapcont)(scope);
                elem.replaceWith(newWrapcont1);				
            }
        }
    }]);
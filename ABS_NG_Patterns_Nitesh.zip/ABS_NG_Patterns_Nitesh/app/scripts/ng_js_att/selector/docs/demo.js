//ABSSBA
var colorselectorCtrl = function($scope) {
    $scope.color = {
        selectedcolor: '#44c7f4'
    };
};
//ABSSBA
var valueselectorCtrl = function($scope) {
    $scope.storage = {
        selectedvalue: '16'
    };

};
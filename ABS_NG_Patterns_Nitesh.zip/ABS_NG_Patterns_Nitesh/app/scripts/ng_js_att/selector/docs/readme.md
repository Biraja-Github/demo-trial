<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

Some products might have different colors and we can allow the user to choose one. For this we'll use a color selector. It behaves as a group of radio buttons, but each as a diferent color.

We can control various parameters like type, colors, ng-model, tooltip-label, using this directive.

#### `<Attribute level configuration for rendering tags>` ####

 * `type`: The attr flag to render the selector type. It will allow two vlaues `color`,`storage`.
 
 * `colors` : The attr flag to pass the colors. need to pass the color values in this attribute.
 
 * `ng-model`: The attr serves model value(Default Selected value).
 
 * `tooltip-label` : Pass tool tip value in this attribute.
 
 * `outofstock="true"` : if out of stock attribute  is ture the product is not available.
 

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

Some products might have different values  and we can allow the user to choose one. For this we'll use a value selector. It behaves as a group of radio buttons, but each as a diferent color.

We can control various parameters like type, storage-value,storage-unit, ng-model, tooltip-label, using this directive.

#### `<Attribute level configuration for rendering tags>` ####

 * `type`: The attr flag to render the selector type. It will allow two vlaues `color`,`storage`.
 
 * `storage-value` : The attr flag to pass the Value. need to pass the value in this attribute.
 
 * `storage-unit` : The attr flag to pass the Unit. need to pass the Unit values in this attribute.
 
 * `ng-model`: The attr serves model value(Default Selected value).
 
 * `tooltip-label` : Pass tool tip value in this attribute.
 
 * `outofstock="true"` : if out of stock attribute  is ture the product is not available.
 




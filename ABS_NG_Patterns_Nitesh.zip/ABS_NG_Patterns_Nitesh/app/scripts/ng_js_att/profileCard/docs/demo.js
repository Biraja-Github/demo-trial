  var profileCardController = function($scope) {
                            $scope.profiles = [
                                {
                                    img: "",
                                    name: "John Christopher",
                                    userName:"JohnChristopher123",
                                    role:"Company Administrator",
                                    lastLogin:"01/19/2015",
                                    state:"Active",
                                    email:"JohnChristopher123@cocacola.com"
                                },                              
                                {
                                    img: "",
                                    name: "Arka Chak",
                                    userName:"ArkaChak123",
                                    role:"Company Administrator",
                                    lastLogin:"01/08/2015",
                                    state:"Idle",
                                    email:"ArkaChak123@cocacola.com"
                                },
                                {
                                    img: "",
                                    name: "Jey S",
                                    userName:"JeyS123",
                                    role:"Company Administrator",
                                    lastLogin:"",
                                    state:"Pending",
                                    email:"JeyS123@cocacola.com"
                                },
                                {
                                    img: "",
                                    name: "venky R",
                                    userName:"venkyR123",
                                    role:"Company Administrator",
                                    lastLogin:"01/20/2014",
                                    state:"Locked",
                                    email:"JohnChristopher123@cocacola.com"
                                },
                                {
                                    img: "",
                                    name: "Kishan Rathore",
                                    userName:"KishanRathore123",
                                    role:"Company Administrator",
                                    lastLogin:"01/07/2015",
                                    state:"Deactivated",
                                    email:"KishanRathore123@cocacola.com"
                                }
                            ];
                        };
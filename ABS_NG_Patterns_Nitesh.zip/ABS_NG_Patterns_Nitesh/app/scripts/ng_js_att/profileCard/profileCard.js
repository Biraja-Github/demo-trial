angular.module('att.abs.profileCard', [])
           
            .constant('profileStatus',{
                status:{
                    ACTIVE:{status:"Active",color:"green"},
                    DEACTIVATED:{status:"Deactivated",color:"red"},
                    LOCKED:{status:"Locked",color:"red"},
                    IDLE:{status:"Idle",color:"yellow"},
                    PENDING:{status:"Pending",color:"blue"}
                    },
                role:"COMPANY ADMINISTRATOR"
                })
           
            .directive('profileCard',['$http','$q','profileStatus', function($http,$q,profileStatus) {
               return  {  
                    restrict: 'EA',
                    replace:'true',
                    templateUrl:function(element, attrs) {
                        if(!attrs.addUser){
                            return 'app/scripts/ng_js_att_tpls/profileCard/profileCard.html';
                        }
                        else{
                            return 'app/scripts/ng_js_att_tpls/profileCard/addUser.html';
                        }
                    },
                    scope:{
                        profile:'='
                    },
                    link: function(scope, elem, attr){

                        scope.image=true;
                        function isImage(src) {
                           
                            var deferred = $q.defer();

                            var image = new Image();
                            image.onerror = function() {
                                deferred.reject(false);
                            };
                            image.onload = function() {
                                deferred.resolve(true);
                            };
                            
                            if(src!==undefined && src.length>0 ){
                                image.src = src;                                
                            }else{
                                 deferred.reject(false);
                            }

                            return deferred.promise;
                        }
                        if(!attr.addUser){
                        scope.image=false;
                        isImage(scope.profile.img).then(function(img) {
                            console.log(img);
                                scope.image=img;
                        });
                       var splitName=(scope.profile.name).split(' ');
						scope.initials='';
						for(var i=0;i<splitName.length;i++){
							scope.initials += splitName[i][0];
						}
                        if(scope.profile.role.toUpperCase()===profileStatus.role){
                            scope.badge=true;
                        }
                        var profileState=profileStatus.status[scope.profile.state.toUpperCase()];
                        if(profileState) {
                            scope.profile.state=profileStatus.status[scope.profile.state.toUpperCase()].status;
                            scope.colorIcon=profileStatus.status[scope.profile.state.toUpperCase()].color;
                            if(scope.profile.state.toUpperCase()===profileStatus.status.PENDING.status.toUpperCase()||scope.profile.state.toUpperCase()===profileStatus.status.LOCKED.status.toUpperCase())
                                if(scope.profile.state.toUpperCase()===profileStatus.status.LOCKED.status.toUpperCase()){
                                    scope.profile.lastLogin=scope.profile.state;
                                }
                                else{
                                    scope.profile.lastLogin=scope.profile.state;
                                }
                        }
                        var today=new Date().getTime();
                        var lastlogin=new Date(scope.profile.lastLogin).getTime();
                        var diff=(today-lastlogin)/(1000*60*60*24);
                        if(diff<=1){
                            scope.profile.lastLogin="Today";
                        }
                        else if(diff<=2){
                            scope.profile.lastLogin="Yesterday";
                        }
                        } 
                     }                     
                };              
            }]);
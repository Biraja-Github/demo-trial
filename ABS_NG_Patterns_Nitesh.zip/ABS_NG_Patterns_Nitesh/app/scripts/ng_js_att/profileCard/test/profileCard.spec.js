describe('Profile Cards', function() {
    var $scope, $compile;
    beforeEach(module('att.abs.profileCard'));
    beforeEach(module('app/scripts/ng_js_att_tpls/profileCard/profileCard.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/profileCard/addUser.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        scope.profiles = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Company Administrator",
                lastLogin:"01/19/2015",
                state:"Active",
                email:"JohnChristopher123@cocacola.com"
            };
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };

        it('should show an empty profile card', function() {
            var elem = compileElement('<profile-card add-user="addUser"></profile-card>', $scope);
            expect(elem).toHaveClass('add-user');
            expect(elem).not.toHaveClass('profile-image');
            expect(elem).not.toHaveClass('profile-details');
          
        });
        it('should show profile card of an User', function() {
            var elem = compileElement('<profile-card  profile="profiles"></profile-card>', $scope);
            expect(elem).not.toHaveClass('add-user');
            expect(elem.find(".profile-image").length>0);
            expect(elem.find(".profile-details").length>0);
        });
        it('should show initials of the user name if user profile doesnot have an image', function() {
            var elem = compileElement('<profile-card  profile="profiles"></profile-card>', $scope);
             expect(elem.find(".default-img").eq(0).text()).toBe('JC');
        });
        it('should show Admin in the status badge for role Company Administrator', function() {
            var elem = compileElement('<profile-card  profile="profiles"></profile-card>', $scope);
            expect(elem.find(".status-badge").eq(0).text()).toBe('Admin');
        });
        it('should not show Admin in the status badge for role other than Company Administrator', function() {
            $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:"01/19/2015",
                state:"Active",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find(".status-badge").length===0);
        });
        it('should show icon color corresponding to profile status', function() {
            $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:"01/19/2015",
                state:"Active",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find(".icon-green").length>1);
            $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:"01/19/2015",
                state:"Pending",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find(".icon-blue").length>1);
            expect(elem.find("p").eq(5).text()).toBe('Pending');
   
        $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:"01/19/2015",
                state:"Locked",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find(".icon-red").length>1);
            expect(elem.find("p").eq(5).text()).toBe('Locked');
        });  


     it('should show Admin in the status badge for role Company Administrator', function() {
         $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:new Date(new Date() - 86400000),
                state:"Active",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find("p").eq(5).text()).toBe('Yesterday');
        });
        it('should show Admin in the status badge for role Company Administrator', function() {
            
         $scope.profile = 
            {
                img: "images/venky1.png",
                name: "John Christopher",
                userName:"JohnChristopher123",
                role:"Angular Developer",
                lastLogin:new Date(),
                state:"Active",
                email:"JohnChristopher123@cocacola.com"
            };
            $scope.$digest();
            var elem = compileElement('<profile-card  profile="profile"></profile-card>', $scope);
            expect(elem.find("p").eq(5).text()).toBe('Today');
        });
});
xdescribe('Search', function() {
    
    var $scope, $compile;
    beforeEach(module('att.abs.search'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        $scope.options = [
            {index: 0, value: 'SelectOption', title: 'Select a Option', selected: 'selected'},
            {index: 1, value: 'FirstName', title: 'First Name'},
            {index: 2, value: 'LastName', title: 'Last Name'},
            {index: 3, value: 'Gender', title: 'Gender'},
            {index: 4, value: 'Phone', title: 'Phone'},
            {index: 5, value: 'City', title: 'City'}
        ];             
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
   
    it("should create number of dropdown options as provided in data list", function() {                    
        var optionList = compileElement('<div class="form-field" att-search="options" ng-model="selectValue" show-input-filter="false"></div>', $scope);        
        expect(optionList.find('select').find('option').length).toBe(6);
        expect(optionList.find('select').find('option')[0].innerHTML).toBe('Select a Option');
        expect(optionList.find('select').find('option')[1].innerHTML).toBe('First Name');
        expect(optionList.find('select').find('option')[2].innerHTML).toBe('Last Name');
        expect(optionList.find('select').find('option')[3].innerHTML).toBe('Gender');
        expect(optionList.find('select').find('option')[4].innerHTML).toBe('Phone');
        expect(optionList.find('select').find('option')[5].innerHTML).toBe('City');       
    });    

    it("Initially only item marked 'selected:selected' in list must be selected", function() {                    
        var countryList = compileElement('<div class="form-field" att-search="options" ng-model="selectValue" show-input-filter="false"></div>', $scope);                
        expect(countryList.find('select').find('option[selected]')[0].innerHTML).toBe('Select a Option');        
    });
    
    it("Selected item must have a tick mark next to it", function() {                    
        var optionList = compileElement('<div class="form-field" att-search="options" ng-model="selectValue" show-input-filter="false"></div>', $scope);                
        expect(optionList.find('ul').find('li')).toHaveClass('select2-result-current');        
    });    
    
    it("Initially Input box must be empty", function() {                    
        var optionList = compileElement('<input type="text" style="width:270px" ng-model="searchValue" placeholder="Enter value to search">', $scope);                
        expect(optionList.val().length).toBe(0);        
    }); 

});


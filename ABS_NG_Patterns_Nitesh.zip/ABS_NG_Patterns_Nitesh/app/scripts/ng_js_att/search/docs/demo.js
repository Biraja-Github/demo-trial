var searchController = function($scope) 
{
    $scope.options = [        
        {index: 0, value: 'FirstName', title: 'First Name', alias:'Name'},
        {index: 1, value: 'LastName', title: 'Last Name', alias:'Name2'},
        {index: 2, value: 'Gender', title: 'Gender', alias:'Sex'},
        {index: 3, value: 'Phone', title: 'Phone', alias:'Contact'},
        {index: 4, value: 'City', title: 'City', alias:'Address'},
        {index: 5, value: 'Mobile', title: 'Mobile', alias:'Contact'},
        {index: 6, value: 'Email', title: 'Email', alias:'Address'},
        {index: 7, value: 'Landmark', title: 'Landmark', alias:'Address'},
        {index: 8, value: 'Pincode', title: 'Pincode', alias:'Address'},
        {index: 9, value: 'Country', title: 'Country', alias:'Address'}
    ];
};

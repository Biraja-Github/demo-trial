'use strict';
angular.module('att.abs.search', [])

.filter('highlight', function() {
    function escapeRegexp(queryToEscape) {
      return queryToEscape.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
    }
    return function(matchItem, query) {      
      return query && matchItem ? matchItem.replace(new RegExp(escapeRegexp(query), 'gi'), '<span class=\"select2-match\">$&</span>') : matchItem;
    };
})

.directive('attSearch', ["$document", "$filter", function($document,$filter){
    return{
        restrict: 'A',
        scope:{cName: '=attSearch',
        selCategory: "=ngModel"},
        transclude: false,
        replace: false,
        require:'ngModel',
        templateUrl: 'app/scripts/ng_js_att_tpls/search/search.html',
        link: function(scope, element, attr, ctrl) {
        scope.selectedIndex = 0;        
        scope.selectedOption = attr.placeholder;               
        
        if(attr.placeholderAsOption === "false")
        {            
            scope.selectMsg = "";
           // scope.selCategory = {index:-1,value:scope.selectMsg, title:scope.selectMsg};   
        }
        else
        {
            scope.selectMsg = attr.placeholder;
           // scope.selCategory = {index:-1,value:scope.selectMsg, title:scope.selectMsg};   
        }

        if(attr.showInputFilter === "true")
        {scope.showSearch = true;}
        else
        {scope.showSearch = false;}
                  
        scope.showDropdown = function()
        {
            scope.showlist =! scope.showlist;            
        };
                  
        scope.dofilter = function(e){                 
            if(scope.showSearch === false)
            {                
                if ([8, 9, 13,16,17,18, 27, 37, 38, 39, 40].indexOf(e.which) > -1)                
                {          
                    if(scope.title === "")
                    {
                        scope.showlist = false;
                    }
                    scope.title = "";
                }                
                else
                {                
                    scope.showlist = true;
                    scope.title = scope.title ? scope.title + String.fromCharCode(e.which):String.fromCharCode(e.which);
                }
            }            
        };
        
        scope.selectOption = function(sItem,sIndex)
        {            
            if(sIndex === "-1"){
               scope.selCategory = "";                
            }
            else
            {                                           
                scope.selCategory = scope.cName[sIndex];            
            }
            scope.selectedOption = sItem; 
            scope.showlist = false;
            scope.title = "";
        };
        
        
        element.bind('mouseleave', function(){
            scope.showlist = false;
        }); 
        
        if(attr.disabled)
        {
           scope.distyle = "none";           
           scope.bgdistyle = "#e4e4e4";
           scope.brdistyle = "1px solid #d4d4d4";
           scope.txdistyle = "#c4c4c4";
        }
                 
        scope.updateSelection = function(sItem)
        {
            scope.selectedOption = sItem;
            scope.showlist = false;
            scope.title = "";            
        };            
                        
        scope.$watch('selCategory',function(value)
        {
            console.log(value);  
            if(value)
            { scope.updateSelection(value.title);};
        });        
        
       
        }
    };
}]);

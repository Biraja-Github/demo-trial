/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
'use strict';
angular.module('att.abs.devNotes', [])

  .directive('attDevNotes', ['$document', '$window', function($document, $window) {
    return {
      restrict: 'EA',
      transclude: true,
      scope: {
          isOpen : '@'
      },
      
      controller: function($scope, $element){
        var panes = $scope.panes = [];
        $scope.select = function(pane) 
        {           
            angular.forEach(panes, function(pane) 
            {
                pane.selected = false;
            });
            pane.selected = true;                     
        };

        this.addPane = function(pane) {
          if (panes.length === 0) $scope.select(pane);
          panes.push(pane);
        };
      },
      
      link: function(scope, elem, attr) {
            scope.$watch('isOpen', function(val) {
                if (val === 'true') {
                    scope.display = 'block';
                }
                else{
                    scope.display = 'none';
                }
            });
            scope.selectAll = function(){
                var activeContainer = elem[0].querySelector(".tab_container .tabs__pane--active"),
                    doc = $document[0];
                
                if (doc.body.createTextRange) { // ms
                    var range = doc.body.createTextRange();
                    range.moveToElementText(activeContainer);
                    range.select();
                }
                else if ($window.getSelection) {
                    var selection = $window.getSelection();
                    var range = doc.createRange();
                    range.selectNodeContents(activeContainer);
                    selection.removeAllRanges();
                    selection.addRange(range);
                }
                
            };
      },
      template:'<div class="dev-box" ng-style="{display: display}" >'+
        '<ul class="tabs-dev">' +
            '<li ng-repeat="pane in panes" ng-class="{\'tabs__item--active\':pane.selected}">'+
              '<a href="javascript:void(0)" ng-click="select(pane)">{{pane.title}}</a>' +
            '</li>' +
            '<li style="float:right"><a ng-click="selectAll()">Select All</a></li>'+
          '</ul>' +
          '<div class="tab_container" ng-transclude></div>'+
          '</div>',
      replace: true
    };
  }])

  .directive('pane', function() {
    return {
      require: '^attDevNotes',
      restrict: 'EA',
      transclude: true,
      scope: {
          title: '@'
      },
      link: function(scope, element, attrs, tabsCtrl) {
        tabsCtrl.addPane(scope);
      },
      template:
        '<div class="tabs__pane" ng-class="{\'tabs__pane--active\': selected}">' + 
        '<pre ng-class="{\'language-markup\':title==\'HTML\',\'language-javascript\':title==\'JavaScript\'}"  class="box ">' +
         '<code ng-transclude></code>' +
         '</pre>' +
        '</div>',
      replace: true
    };
  })
  
  .directive('attAbsSection', function() {
    return {
      restrict: 'EA',
      transclude: true,
      templateUrl: 'app/scripts/ng_js_att_tpls/devNotes/attAbsSection.html',
      replace: true,
      scope: {},
      link: function(scope, element, attrs, ctrl) {
          scope.sectionId = attrs.sectionId;
          scope.sectionName = attrs.sectionName;
      }
    };
  })
  
  .directive('attAbsMainSection', function() {
    return {
      restrict: 'EA',
      templateUrl: 'app/scripts/ng_js_att_tpls/devNotes/attAbsMainSection.html',
      replace: true,
      scope: {},
      link: function(scope, element, attrs, ctrl) {
          scope.sectionId = attrs.sectionId;
          scope.sectionName = attrs.sectionName;
      }
    };
  });

describe('DevNotes', function() {

    var $scope, $compile;
    beforeEach(module('att.abs.devNotes'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {       
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    };
    
    it('it should generate two tabs initially for HTML & JavaScript and one extra for Select All', function(){       
        var devtabs = compileElement('<att-dev-notes><pane title="HTML">HTML code will be avialable in this section</pane><pane title="JS">JavaScript code will be avialable in this section</pane></att-dev-notes>', $scope);                       
        expect(devtabs.find('li').length).toBe(3);
        expect(devtabs.find('li')[0].innerHTML).toContain('HTML');
        expect(devtabs.find('li')[1].innerHTML).toContain('JS');
    });
        
    it('it should generate two panes initially for HTML & JavaScript', function(){       
        var devtabs = compileElement('<att-dev-notes><pane title="HTML">HTML code will be avialable in this section</pane><pane title="JavaScript">JavaScript code will be avialable in this section</pane></att-dev-notes>', $scope);                       
        expect(devtabs.find('.tab_container').children().length).toBe(2);
        expect(devtabs.find('.tabs__pane').eq(0)).toHaveClass('tabs__pane--active');
    });    
    
    it('it should toggle active class on click', function() {       
        var devtabs = compileElement('<att-dev-notes><pane title="HTML">HTML code will be avialable in this section</pane><pane title="JavaScript">JavaScript code will be avialable in this section</pane></att-dev-notes>', $scope);                              
        expect(devtabs.find('li').eq(0)).toHaveClass('ng-scope tabs__item--active');                 
        devtabs.find('li').eq(1).find('a').click();
        expect(devtabs.find('li').eq(1)).toHaveClass('ng-scope tabs__item--active');
        expect(devtabs.find('li').eq(0)).not.toHaveClass('tabs__item--active');               
    });
           
    it('it should switch panes according to click of tabs', function() {       
        var devtabs = compileElement('<att-dev-notes><pane title="HTML">HTML code will be avialable in this section</pane><pane title="JavaScript">JavaScript code will be avialable in this section</pane></att-dev-notes>', $scope);                                      
        expect(devtabs.find('li').eq(0)).toHaveClass('ng-scope tabs__item--active');                 
        expect(devtabs.find('.tabs-dev').children().eq(0)).toHaveClass('tabs__item--active');         
        devtabs.find('li').eq(1).find('a').click();                       
        expect(devtabs.find('li').eq(1)).toHaveClass('ng-scope tabs__item--active');
        expect(devtabs.find('.tabs-dev').children().eq(1)).toHaveClass('tabs__item--active');   
    });
        
 });    



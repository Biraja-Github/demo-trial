angular.module('att.abs.verticalNavigation',[])
.directive('attVerticalNav',function(){
	return{
        restrict: 'EA',  
        scope:{
            itemList:"="
        },
       controller: ['$scope', function($scope) {
                        this.getList = function() {
                            return $scope.itemList;
                        };
                        this.onClick = function(item) {
                            
                            return $scope.currentItem = item.url;
                        };
                        this.isActiveItem = function(item) {
                            return item === $scope.currentItem;
                            
                        };
                    }],
        link:   function (scope,elem,attrs,ctrl){
            }
     };
 })
.directive('standard', function() {
            return {
                require: '^attVerticalNav',
                restrict: 'EA',
                transclude: false,
                replace: true,
                templateUrl: 'app/scripts/ng_js_att_tpls/verticalNavigation/standard.html',
                link: function(scope,elem,attrs,attVerticalNavCtrl){
                    scope.list = attVerticalNavCtrl.getList();
                    scope.clickItem = attVerticalNavCtrl.onClick;
                    scope.isActive = attVerticalNavCtrl.isActiveItem;
                }
            };
        })
.directive('simplified', function() {
            return {
                require: '^attVerticalNav',
                restrict: 'EA',
                transclude: false,
                replace: true,
                templateUrl: 'app/scripts/ng_js_att_tpls/verticalNavigation/simplified.html',
                link: function(scope,elem,attrs,attVerticalNavCtrl){
                    scope.list = attVerticalNavCtrl.getList();
                    scope.clickItem = attVerticalNavCtrl.onClick;
                    scope.isActive = attVerticalNavCtrl.isActiveItem;
                    
                }
            };
        })
        .directive('withoutTabbedItems', function() {
            return {
                require: '^attVerticalNav',
                restrict: 'EA',
                transclude: false,
                replace: true,
                templateUrl: 'app/scripts/ng_js_att_tpls/verticalNavigation/withoutTabbed.html',
                link: function(scope,elem,attrs,attVerticalNavCtrl){
                }
            };
        })   
;
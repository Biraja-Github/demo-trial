var navigationCtrl = function($scope){
    $scope.navList = [{
        'title': "Overview",
        'url': '#overview'
    },{
        'title': "Features",
        'url': '#features'
    },{
        'title': "Equipments",
        'url': '#equipment'
    },{
        'title': "Requirements",
        'url': '#requirements'
    },{
        'title': "FAQ's",
        'url': '#faq'
    },{
        'title': "Ratings",
        'url': '#ratings'
    }];
};
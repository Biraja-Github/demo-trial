describe('Unit Test- Vertical Navigation', function() {
    var scope,compile;
    beforeEach(module('att.abs.verticalNavigation'));
    beforeEach(module('app/scripts/ng_js_att_tpls/verticalNavigation/simplified.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/verticalNavigation/standard.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/verticalNavigation/withoutTabbed.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_, _$q_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
        $q = _$q_;
    }));

        var compileMarkup = function(markup, scope) {
            var el = $compile(markup)(scope);
            scope.$digest();
            return el;
        };
    
    // check for standard vertical navigatiion
    it('should render standard vertical list', function() {
        $scope.navList = [{
                'title': "Overview",
                'url': '#overview'
            }, {
                'title': "Features",
                'url': '#features'
            }];
        var markUp = compileMarkup('<att-vertical-nav item-list="navList" standard></att-vertical-nav>', $scope);
        expect(markUp.children().eq(0)).toHaveClass('att-quick-nav--expanded');
    });
    
    // check for simplified vertical navigatiion
    it('should render simplified vertical navigation', function() {
        $scope.navList = [{
                'title': "Overview",
                'url': '#overview'
            }, {
                'title': "Features",
                'url': '#features'
            }];
        var markUp = compileMarkup('<att-vertical-nav item-list="navList" simplified></att-vertical-nav>', $scope);
        expect(markUp.children().eq(0)).toHaveClass('att-quick-nav--collapsed');
        expect(markUp.children().children().children().eq(0)).toHaveClass('att-quick-nav__control icon-arrow-up');
        expect(markUp.children().children().children().eq(1).children().eq(0)).toHaveClass('att-quick-nav__control icon-list');
    });
  
    // check for vertical navigatiion without tabbed items
    it('should render list without tabbed items', function() {
        $scope.navList = [{
                'title': "Overview",
                'url': '#overview'
            }, {
                'title': "Features",
                'url': '#features'
            }];
        var markUp = compileMarkup('<att-vertical-nav item-list="navList" without-tabbed-items></att-vertical-nav>', $scope);
        expect(markUp.children().eq(0)).toHaveClass('att-quick-nav--collapsed');
        expect(markUp.children().children().eq(0)).toHaveClass('icon-arrow-up-top visible');
        expect(markUp.children().children().eq(0)).toHaveClass('visible');
        expect(markUp.children().children().eq(1).children().eq(0)).toHaveClass('att-quick-nav__control icon-arrow-up');
        expect(markUp.children().children().eq(1).children().eq(1)).toHaveClass('att-quick-nav__control icon-arrow-down');
    });
 

});


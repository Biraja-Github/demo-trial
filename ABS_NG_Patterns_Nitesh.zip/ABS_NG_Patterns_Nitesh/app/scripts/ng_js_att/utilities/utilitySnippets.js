(function () {
    String.prototype.toSnakeCase = function () {
        return this.replace(/([A-Z])/g, function ($1) {
            return "-" + $1.toLowerCase();
        });
    };

    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function (val) {
            for (var index = 0; index < this.length; index++) {
                if (this[index] === val) {
                    return index;
                }
            }
            return -1;
        };
    }
})();

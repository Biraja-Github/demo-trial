angular.module('att.abs.utilities', [])

.filter('highlight', function () {
    function escapeRegexp(queryToEscape) {
        return queryToEscape.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
    }
    return function (matchItem, query, className) {
        return query && matchItem ? matchItem.replace(new RegExp(escapeRegexp(query), 'gi'), '<span class=\"' + className + '\">$&</span>') : matchItem;
    };
})

.directive('attInputDeny', [function() {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attr, ctrl) {
            var regexExpression = null;
            attr.$observe('attInputDeny', function (value) {
                if (value) {
                    regexExpression = new RegExp(value, 'g');
                }
            });
            elem.bind('input', function () {
                var inputString = ctrl.$viewValue.replace(regexExpression, '');
                if (inputString !== ctrl.$viewValue) {
                    ctrl.$setViewValue(inputString);
                    ctrl.$render();
                    scope.$apply();
                }
            });
        }
    };
}])

.directive('attAccessibilityClick', [function() {
    return {
        restrict: 'A',
        link: function (scope, elem, attr, ctrl) {
            var keyCode = [];
            attr.$observe('attAccessibilityClick', function (value) {
                if (value) {
                    keyCode = value.split(',');
                }
            });
            elem.bind('keydown', function (ev) {
                if(keyCode.length > 0 && ((ev.charCode && keyCode.indexOf(ev.charCode.toString()) > -1) || (ev.keyCode && keyCode.indexOf(ev.keyCode.toString()) > -1) || (ev.which && keyCode.indexOf(ev.which.toString()) > -1))) {
                    elem[0].click();
                    ev.preventDefault();
                }
            });
        }
    };
}])

.directive('attElementFocus', [function() {
    return {
        restrict: 'A',
        link: function(scope, elem, attr, ctrl) {
            scope.$watch(attr.attElementFocus, function (value) {
                if (value === true) {
                    elem[0].focus();
                }
            });
        }
    };
}])

.factory('$documentBind', ['$document', '$timeout', function($document, $timeout) {
    var _click = function (flag, callbackFunc, scope) {
        scope.$watch(flag, function (val) {
            $timeout(function () {
                if (val) {
                    $document.bind('click', callbackFunc);
                } else {
                    $document.unbind('click', callbackFunc);
                }
            });
        });
    };

    return {
        click: _click
    };
}]);

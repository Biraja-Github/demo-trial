describe('PopOvers', function() {

    var $scope, $compile, $templateCache, $document;
    var localElm, elmScope;
    
    // load the popOvers code
    beforeEach(module('att.abs.popOvers'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/popOvers/popOvers.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_, _$templateCache_, _$document_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
        $templateCache = _$templateCache_;
        $document = _$document_;
    }));
    
    beforeEach(function() {
        
        $templateCache.put('popOverContent.html', '<div>Content</div>');
        
        localElm = compileElement('<button popover="popOverContent.html">Pop Over</button>', $scope, $compile);
        elmScope = localElm.scope();
    });
    
    afterEach(function() {
        angular.element('[popover]').remove();
        angular.element('div.att-popover').remove();
    });
    
    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };
    
    it('should not be open initially', inject(function() {
        expect(elmScope.tt_isOpen).toBe(false);
        
        // We can only test *that* the popover-popup element was created and append
        // to the body tag, instead of the element itself
        expect(localElm.children().length).toBe(0);
        
        expect($document.find('body').find('div.att-popover').length).toBe(0);
    }));
    
    it('should open on click', inject(function() {
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(true);

        // We can only test *that* the popover-popup element was created and append
        // to the body tag, instead of the element itself
        expect(localElm.children().length).toBe(0);
        
        expect($document.find('body').find('div.att-popover')).toHaveClass('att-tooltip att-popover att-tooltip--on popover-demo');
    }));
    
    it('should close on clicking again', inject(function() {
        localElm.trigger('click');
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(false);
    }));
    
    it('should have default placement of "above"', inject(function() {
        localElm.trigger('click');
        expect(elmScope.tt_placement).toBe("above");
        expect($document.find('body').find('div.att-popover')).toHaveClass('att-tooltip--above');
    }));
    
    it('should allow specification of placement', inject(function() {
        localElm = compileElement('<button popover="popOverContent.html" popover-placement="below">Pop Over</button>', $scope, $compile);
        elmScope = localElm.scope();
        localElm.trigger('click');
        expect(elmScope.tt_placement).toBe("below");
        expect($document.find('body').find('div.att-popover')).toHaveClass('att-tooltip--below');
    }));
    
    it('should have default style of "white"', inject(function() {
        localElm.trigger('click');
        expect($document.find('body').find('div.att-popover')).not.toHaveClass('att-tooltip--grey');
    }));
    
    it('should allow specification of style', inject(function() {
        localElm = compileElement('<button popover="popOverContent.html" popover-style="grey">Pop Over</button>', $scope, $compile);
        elmScope = localElm.scope();
        
        localElm.trigger('click');
        expect($document.find('body').find('div.att-popover')).toHaveClass('att-tooltip--grey');
    }));
    
    it('should allow specification of style', inject(function() {
        localElm = compileElement('<button popover="popOverContent.html" popover-style="grey">Pop Over</button>', $scope, $compile);
        elmScope = localElm.scope();
        
        localElm.trigger('click');
        expect($document.find('body').find('div.att-popover')).toHaveClass('att-tooltip--grey');
    }));
    
    it('should work inside an ngRepeat', inject(function($compile) {
        
        var htmlMarkup =  
                '<ul>' +
                    '<li ng-repeat="item in items">' +
                        '<button popover="{{item.content}}">{{item.name}}</button>' +
                    '</li>' +
                '</ul>';

        $scope.items = [
            {
                name: "Pop Over One", 
                content: "popOverContent.html"
            },
            {
                name: "Pop Over Two", 
                content: "popOverContent.html"
            }
        ];
        
        localElm = compileElement(htmlMarkup, $scope, $compile);

        var po = angular.element(localElm.find("li > button")[0]);

        po.trigger('click');

        expect(po.text()).toBe($scope.items[0].name);
        expect(po.scope().tt_content).toBe($scope.items[0].content);

        po.trigger('click');
    }));
    
    it('should not show popover if there is nothing to show', inject(function() {
        localElm = compileElement('<button popover="">Pop Over</button>', $scope, $compile);
        elmScope = localElm.scope();
        
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(false);
    }));
    
    it('should close the popover when its trigger element is destroyed', inject(function() {
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(true);

        localElm.remove();
        elmScope.$destroy();
        expect(elmScope.tt_isOpen).toBe(false);
    }));
    
    it('should close the popover when X mark is clicked inside the generated popover', inject(function() {
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(true);
        
        $document.find('body').find('a.att-popover__close').click();
        expect(elmScope.tt_isOpen).toBe(false);
    }));
    
    it('should close the popover when ESC key is pressed', inject(function() {
        localElm.trigger('click');
        expect(elmScope.tt_isOpen).toBe(true);
        
        var eventObj = $.Event('keydown', {which: 27, keyCode: 27});
        $document.trigger(eventObj);
        expect(elmScope.tt_isOpen).toBe(false);
    }));
    
});
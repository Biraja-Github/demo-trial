angular.module('att.abs.popOvers', ['att.abs.tooltip', 'att.abs.utilities', 'ngSanitize'])
        .directive('popover', ['$tooltip', function($tooltip) {
                return $tooltip('popover', 'popover', 'click');
            }])
        .directive('popoverPopup', ['$document', '$documentBind', function($document, $documentBind) {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/popOvers/popOvers.html',
                    scope: {content: '@', placement: '@', animation: '&', isOpen: '=', stylett: '@'},
                    link: function(scope, elem, attr, ctrl) {
                        
                        var flag = false;
                        
                        scope.$watch("isOpen", function(value) {
                            flag = scope.isOpen;
                        });
                        
                        scope.$watch("stylett", function(value) {
                            scope.popOverStyle = value;
                        });

                        scope.$watch("placement", function(value) {
                            scope.popOverPlacement = value;
                        });
                        
                        scope.closeMe = function(){
                           scope.isOpen = false;
                        };
                        
                        elem.bind('click', function (e) {
                            e.stopPropagation();
                        });
                        
                        var outsideClick = function(e) {
                            if (!flag) {
                                scope.$apply(function() {
                                    scope.isOpen = false;
                                });
                            }
                            flag = false;
                        };

                        $documentBind.click('isOpen', outsideClick, scope);
                        
                        $document.bind('keydown', function (evt) {
                            if (evt.which === 27 || evt.keyCode === 27) {
                                scope.isOpen = false;
                                scope.$apply();
                            }
                        });
                    }
                };
            }]);

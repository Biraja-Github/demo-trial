var popOversController = function($scope) {
    $scope.color = {
        selectedColor : '#444'
    };
    $scope.popOverColor='grey';
    
    $scope.bgDemoColorClass = 'bg-white';
    
    $scope.$watch('color.selectedColor', function(backgroundColor) {
        if(backgroundColor === '#fff'){ //Background white
            $scope.bgDemoColorClass = 'bg-white';
            $scope.popOverColor='grey'; //Pop-Over grey
        }
        else if(backgroundColor === '#f2f2f2'){ //Background grey
            $scope.bgDemoColorClass = 'bg-standard';
            $scope.popOverColor='white'; //Pop-Over white
        };
    });
};
var verticalSteptrackerCtrl = function($scope){
    $scope.varsteps = [
        {title: "Tickets Active",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Active"},
        {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
        {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
        {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
        {title: "Tickets Cleared",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Cleared"}

    ];
};
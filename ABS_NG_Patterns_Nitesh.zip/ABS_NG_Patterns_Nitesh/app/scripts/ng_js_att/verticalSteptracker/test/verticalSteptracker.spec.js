describe('verticalSteptracker', function() {
    var scope, compile, $timeout;
    beforeEach(module('att.abs.verticalSteptracker'));
    beforeEach(module('app/scripts/ng_js_att_tpls/verticalSteptracker/vertical-step-tracker.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_,_$timeout_) {
        scope = _$rootScope_;
        compile = _$compile_;
        $timeout = _$timeout_;
    }));
 
    var compileMarkup = function(markup) {        
        var elem = angular.element(markup);      
        elem = compile(elem)(scope);      
        scope.$digest();
        return elem;
    };
    it("should create number steps in total as you pass inside your controller", function() { 

        scope.varsteps = [
            {title: "Tickets Active",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Active"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Tickets Cleared",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Cleared"}

        ]; 
        var verticalDemo = 
                '<vertical-steptracker>'+
                '<vertical-steptracker-step ng-repeat="varstep in varsteps" type ="varstep.type" id ="varstep.id">'+
                                '<span ng-class="ticket-title">{{varstep.title}}</span>'+
                                '<span class="ticket-timestamp">{{varstep.timestamp}}</span>'+
                '</vertical-steptracker-step>'+
                '</vertical-steptracker>';
        var eleversteptracker = compileMarkup(verticalDemo); 
        var steps = eleversteptracker.children().children().children();
        expect(steps.length).toBe(5);        
    });
    
    it("should show proper String as it is being passed inside controller",function(){
        scope.varsteps = [
            {title: "Tickets Active",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Active"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Progress Comments",timestamp: "9/2/2014, 2:00 pm",type:"progress",id:"In Progress"},
            {title: "Tickets Cleared",timestamp: "9/2/2014, 2:00 pm",type:"actual",id:"Cleared"}

        ];
        var verticalDemo = 
                '<vertical-steptracker>'+
                '<vertical-steptracker-step ng-repeat="varstep in varsteps" type ="varstep.type" id ="varstep.id">'+
                                '<span ng-class="ticket-title">{{varstep.title}}</span>'+
                                '<span class="ticket-timestamp">{{varstep.timestamp}}</span>'+
                '</vertical-steptracker-step>'+
                '</vertical-steptracker>';
        var eleversteptracker = compileMarkup(verticalDemo);       
        var steps = eleversteptracker.children().children().children().children().eq(0).children().eq(1).children().eq(0).text();
        expect(steps).toBe('Tickets Active');
    });
    
});
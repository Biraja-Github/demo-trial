angular.module('att.abs.verticalSteptracker', [])
    .directive('verticalSteptracker', [
    function() {
        return {
        restrict: 'EA',
        transclude: true,
        replace: false,
        scope: {
        },
        template: '<div class="vertical-nav"><ul ng-transclude class="tickets-list-height"></ul></div>',
        link:function(scope,elem,attribute,ctrl)  {

        }   
    };
     }
 ])
     .directive('verticalSteptrackerStep',[
        function() {
        return {            
            restrict: 'EA',
            transclude: true,
            replace: false,
            scope: {
                type: "=type",
                id: "=id"
            },
            templateUrl: 'app/scripts/ng_js_att_tpls/verticalSteptracker/vertical-step-tracker.html',
            link: function(scope, elem, attr, ctrl) {

                
            }
         };
     }
     ])
     
        .directive('attAbsLink',[function(){
                return{
                    restrict: 'EA',
                    transclude: true,
                    replace: false,                    
                    template: '<span ng-transclude class="view-log"></span>',
                    link: function(scope, elem, attr, ctrl) {
                
            }
                };
        }])



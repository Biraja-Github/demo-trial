<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **Scrollbar directive** is built using angular library.
This can be used for rendering custom scrollbar in an application.

We can control various parameters like att-scrollbar while using this directive.

#### `<Attribute level configuration for rendering scrollbar>` ####

 * `att-scrollbar`: Need to add att-scrollbar to  Any block level element then the scrollbar will be available  
describe('Scorllbar', function() {
    var scope, compile, controller;
    beforeEach(module("att.abs.scrollbar"));
    beforeEach(module('att.abs.position'));
    beforeEach(module("app/scripts/ng_js_att_tpls/scrollbar/scrollbar.html"));
    beforeEach(inject(function(_$rootScope_, _$compile_, _$controller_, $window, $timeout, $parse, $animate,$position) {
        scope = _$rootScope_;
        compile = _$compile_;

    }));
    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };
    it("should Check DOM manipulation", function() {
        var markup = compileMarkup("<div att-scrollbar></div>");
        var scrollbar = markup.children();
        var scrollthumb = markup.children().eq(0).children();
        var viewport = markup.children().eq(1);
        var overview = markup.children().eq(1).children();
        expect(scrollbar).toHaveClass('scroll-bar');
        expect(scrollthumb).toHaveClass('scroll-thumb');
        expect(viewport).toHaveClass('scroll-viewport');
        expect(overview).toHaveClass('scroll-overview');
    });
    it("should Check content is less then height add disable class", function() {
        var markup = compileMarkup("<div id='content' att-scrollbar>" +
                "<h3>Scroll me down!</h3>" +
                "</div>");
        var scrollbar = markup.children().eq(0);
        expect(scrollbar).toHaveClass('disable');
    });    

});
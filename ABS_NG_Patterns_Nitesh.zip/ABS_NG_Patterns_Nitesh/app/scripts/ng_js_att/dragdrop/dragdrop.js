angular.module('att.abs.dragdrop', [])
        .directive('attFileDrop', ['$parse', function($parse) {
                return {
                    restrict: 'A',
                    scope: {
                        fileModel : '=',
                        onDrop : '&',
                        attFileDrop : '&'
                    },
                    controller: ['$scope', '$attrs', function($scope, $attrs){
                        if($attrs.attFileDrop!==""){
                            $scope.onDrop=$scope.attFileDrop;
                        }
                            
                        this.onDrop = $scope.onDrop;
                    }],
                    link: function(scope, element, attr, ctrl) {
                        
                        element.addClass('dragdrop');
                        
                        element.bind(
                            'dragover',
                            function(e) {
                                
                                if(e.originalEvent){
                                    e.dataTransfer = e.originalEvent.dataTransfer;
                                }
                                
                                e.dataTransfer.dropEffect = 'move';
                                // allows us to drop
                                if (e.preventDefault) e.preventDefault();
                                element.addClass('dragdrop-over');
                                return false;
                            }
                        );
                        
                        element.bind(
                            'dragenter',
                            function(e) {
                                // allows us to drop
                                if (e.preventDefault) e.preventDefault();
                                element.addClass('dragdrop-over');
                                return false;
                            }
                        );

                        element.bind(
                            'dragleave',
                            function(e) {
                                element.removeClass('dragdrop-over');
                                return false;
                            }
                        );
                        
                        element.bind(
                            'drop',
                            function(e) {
                                // Stops some browsers from redirecting.
                                if(e.preventDefault) { e.preventDefault(); } ;
                                if (e.stopPropagation) { e.stopPropagation(); };
                                
                                if(e.originalEvent){
                                    e.dataTransfer = e.originalEvent.dataTransfer;
                                }
                                
                                element.removeClass('dragdrop-over');
                                
                                if(e.dataTransfer.files && e.dataTransfer.files.length > 0){
                                    scope.fileModel = e.dataTransfer.files[0];
                                    scope.$apply();
                                    
                                    if(typeof scope.onDrop === "function"){
                                        scope.onDrop = $parse(scope.onDrop);
                                        scope.onDrop();
                                    }
                                }
                                return false;
                            }
                        );
                    }
                };
            }])
        .directive('attFileLink', [ function() {
                return {
                    restrict: 'EA',
                    require: '^?attFileDrop',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/dragdrop/fileUpload.html',
                    scope: {
                        fileModel : '=?',
                        onFileSelect : '&',
                        attFileLink : '&'
                    },
                    controller: ['$scope', '$parse', function($scope, $parse){
                        
                        this.setFileModel= function(fileModel){
                            if($scope.takeFileModelFromParent){
                                $scope.$parent.fileModel = fileModel;
                                $scope.$parent.$apply();
                            }
                            else{
                                $scope.fileModel = fileModel;
                                $scope.$apply();
                            }
                        };
                        
                        this.callbackFunction= function(){
                            if(typeof $scope.onFileSelect === "function"){
                                $scope.onFileSelect = $parse($scope.onFileSelect);
                                $scope.onFileSelect();
                            }
                        };
                        
                    }],
                    link: function(scope, element, attr, attFileDropCtrl) {
                        
                        scope.takeFileModelFromParent = false;
                        
                        if(!(attr.fileModel)){
                            if(attFileDropCtrl){
                                scope.takeFileModelFromParent = true;
                            }
                        }
                        
                        if(attr.attFileLink!==""){
                            scope.onFileSelect=scope.attFileLink;
                        }
                        else if(!(attr.onFileSelect)){
                            if(attFileDropCtrl){
                                scope.onFileSelect = attFileDropCtrl.onDrop;
                            }
                        }
                        
                    }
                };
            }])
        .directive('attFileChange', ['$parse', function($parse) {
                return {
                    restrict: 'A',
                    require: '^attFileLink',
                    link: function(scope, element, attr, attFileLinkCtrl) {
                        element.bind(
                            "change", 
                            function (e) {
                                if(e.target.files && e.target.files.length > 0){
                                    attFileLinkCtrl.setFileModel(e.target.files[0]);
                                    attFileLinkCtrl.callbackFunction();
                                }
                                else{
                                    var strFileName = e.target.value;
                                    var objFSO = new ActiveXObject("Scripting.FileSystemObject");
                                    
                                    attFileLinkCtrl.setFileModel(objFSO.getFile(strFileName));
                                    attFileLinkCtrl.callbackFunction();
                                }
                            }
                        );
                    }
                };
            }]);
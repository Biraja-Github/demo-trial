<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-file-drop directive** is built using angular library.
This can be used for rendering a drop area in an application. It gives a handle
object which refers to the dropped file.

We need to pass following parameters while using this directive:

#### `<Attribute level configuration for rendering Drag and Drop>` ####

 * `file-model`
 	:
 	This attr holds the reference object for file model.

 * `on-drop`
 	:
 	The attr serves as an option to specify a callback function, as soon as the file is dropped.

<br/>

The **att-file-link directive** is built using angular library.
This can be used for rendering a link text in an application.
When clicked, it opens a file dialog to access the local file system and select any particular file. 
It gives a handle object which refers to the selected file.

We need to pass following parameters while using this directive:

#### `<Attribute level configuration for rendering File Select>` ####

 * `file-model`
 	:
 	This attr holds the reference object for file model.

 * `on-file-select`
 	:
 	The attr serves as an option to specify a callback function, as soon as the file is selected.

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>It enables the user to drag a file and drop it in the Drag and Drop area and trigger a drop event, give file object in form of model, so that the developer can catch it and read the file.</li>
    <li>IE9 and IE8 users would need to follow below steps:<br>
        a) Go to Tools-->Internet Options <br>
        b) Select security tab <br>
        c) Click on Trusted Sites (or "Local Intranet" depending on whether your site is trusted or not) <br>
        d) Click on Custom Level <br>
        e) Ensure that "Initialize and script ActiveX controls not marked safe for scripting" is Enabled - this comes under Activex controls and plug-ins section towards 1/4th of the scroll bar. <br>
        f) Click OK, OK.<br>
        <br>
        Once this is completed, clear the browser cookies and cache. Close all your browser sessions. Reopen the IE to launch your site.
    </li>
</ul>
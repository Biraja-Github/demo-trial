var dragDropController = function($scope) {
    $scope.fileModel={};
    $scope.theMethodToBeCalled = function(data) {
        if(undefined!==data)
            alert(data);
        
        var file = $scope.fileModel;
        var name = file.name;
        var type = file.type;
        var size = file.size;
        alert('name='+name+' ; type='+type+' ; size='+size+' bytes');
    };
};
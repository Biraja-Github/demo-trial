describe('attFileDrop', function() {

    var $scope, $compile;

    // load the attDragDrop code
    beforeEach(module('att.abs.dragdrop'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    beforeEach(function() {
        $scope.fileModel={};
        $scope.theMethodToBeCalled = function(data) {};
    });
    
    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        $('body').append(elmBody);
        scope.$digest();
        return elmBody;
    };
    
    afterEach(function() {
      $('div[att-file-drop]').remove();
    });
    
    it('should render the div area with drag and drop look and feel when the attr att-file-drop is applied', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        expect(localElm).toHaveClass('dragdrop');
    });
    
    it('should append appropriate class when dragover event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragover', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        expect(localElm).toHaveClass('dragdrop-over');
    });
    
    it('should append appropriate class when dragenter event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragenter', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        expect(localElm).toHaveClass('dragdrop-over');
    });
    
    it('should remove appropriate class when dragleave event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragenter', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        
        eventObj = $.Event('dragleave', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        expect(localElm).not.toHaveClass('dragdrop-over');
    });
    
    it('should remove appropriate class when drop event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragover', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        
        eventObj = $.Event('drop', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        expect(localElm).not.toHaveClass('dragdrop-over');
    });
    
    it('should call the callback function, if defined, if a valid file drop event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragover', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        
        spyOn($scope,"theMethodToBeCalled");
        
        eventObj = $.Event('drop', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        expect($scope.theMethodToBeCalled).toHaveBeenCalled();
    });
    
    it('should assign the reference object of the file to the scope model provided, if a valid file drop event is fired', function() {
        var localElm = compileElement('<div att-file-drop file-model="fileModel" on-drop="theMethodToBeCalled(\'Dropped...!!\')">DragAndDrop</div>', $scope, $compile);
        
        var eventObj = $.Event('dragover', { dataTransfer: { files: [{}] } });
        localElm.trigger(eventObj);
        
        eventObj = $.Event('drop', { dataTransfer: { files: [{name: "test.jpeg", size: 12345, type: "image/jpeg"}] } });
        localElm.trigger(eventObj);
        expect($scope.fileModel.name).toBe("test.jpeg");
        expect($scope.fileModel.size).toBe(12345);
        expect($scope.fileModel.type).toBe("image/jpeg");
    });
});

describe('attFileLink', function() {

    var $scope, $compile;

    // load the attDragDrop code
    beforeEach(module('att.abs.dragdrop'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/dragdrop/fileUpload.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    beforeEach(function() {
        $scope.fileModel={};
        $scope.theMethodToBeCalled = function(data) {};
    });
    
    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        $('body').append(elmBody);
        scope.$digest();
        return elmBody;
    };
    
    afterEach(function() {
      $('.fileContainer').remove();
    });

    it('should render the component area with correct look and feel when the attr att-file-link is applied', function() {
        var localElm = compileElement('<span att-file-link file-model="fileModel" on-file-select="theMethodToBeCalled(\'Selected...!!\')">click here to select from your computer</span>', $scope, $compile);
        
        expect(localElm).toHaveClass('fileContainer');
        expect(localElm.find('input').eq(0).attr('type')).toBe('file');
    });
    
    it('should transclude whatever is applied inside directive', function() {
        var localElm = compileElement('<span att-file-link file-model="fileModel" on-file-select="theMethodToBeCalled(\'Selected...!!\')">click here to select from your computer</span>', $scope, $compile);
        
        expect(localElm.find('span').eq(0).text()).toBe('click here to select from your computer');
    });
        
    it('should call the callback function, if defined, if a valid file change event is fired', function() {
        var localElm = compileElement('<span att-file-link file-model="fileModel" on-file-select="theMethodToBeCalled(\'Selected...!!\')">click here to select from your computer</span>', $scope, $compile);
        
        spyOn($scope,"theMethodToBeCalled");
        
        var eventObj = $.Event('change', { target: { files: [{}] } });
        localElm.find('input').eq(0).trigger(eventObj);
        expect($scope.theMethodToBeCalled).toHaveBeenCalled();
    });
    
    it('should assign the reference object of the file to the scope model provided, if a valid file change event is fired', function() {
        var localElm = compileElement('<span att-file-link file-model="fileModel" on-file-select="theMethodToBeCalled(\'Selected...!!\')">click here to select from your computer</span>', $scope, $compile);
        
        var eventObj = $.Event('change', { target: { files: [{name: "test.jpeg", size: 12345, type: "image/jpeg"}] } });
        localElm.find('input').eq(0).trigger(eventObj);
        expect($scope.fileModel.name).toBe("test.jpeg");
        expect($scope.fileModel.size).toBe(12345);
        expect($scope.fileModel.type).toBe("image/jpeg");
    });
    
});
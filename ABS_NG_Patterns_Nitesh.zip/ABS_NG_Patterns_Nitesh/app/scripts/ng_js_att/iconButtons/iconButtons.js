angular.module('att.abs.iconButtons', ['att.abs.utilities'])
           
            .directive('attIconBtns', function() {
                return {  
                    restrict: 'EA',
                    replace:true,
                    transclude: true,
                    templateUrl:'app/scripts/ng_js_att_tpls/iconButtons/iconButtons.html'              
                   
                };
            })
            .directive('attIconBtn',['$document', '$documentBind', function($document, $documentBind) {
                return {  
                    restrict: 'EA',
                    transclude: true,
                    replace: true,
                    scope:{
                        attIconBtn:"@",
                        dropdown:"@",
                        buttonIcon:"@"
                    },
                    templateUrl:'app/scripts/ng_js_att_tpls/iconButtons/iconButton.html',
                    link: function(scope, elem, attr) {
                        scope.isDropDownOpen = false;
                        var flag = false;
                        if(attr.btnSize==="small"){
                            scope.btnSize=true;
                        };
                        scope.toggleDropdown = function() {
                            if (scope.dropdown === 'true') {
                                flag = scope.isDropDownOpen = !scope.isDropDownOpen;
                            }
                        };
                        var outsideClick = function(e) {
                            if (!flag) {
                                scope.$apply(function() {
                                    scope.isDropDownOpen = false;
                                });
                            }
                            flag = false;
                        };

                        $documentBind.click('isDropDownOpen', outsideClick, scope);
                    }
                };
            }])
             .directive('attIconBtnLink', function() {
                return {  
                    replace: true,
                    restrict: 'EA',
                    transclude: true,
                    templateUrl:'app/scripts/ng_js_att_tpls/iconButtons/iconButtonLink.html'                
                };
            })
        ;

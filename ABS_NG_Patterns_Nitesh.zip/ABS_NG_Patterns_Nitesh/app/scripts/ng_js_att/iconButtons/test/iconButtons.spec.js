describe('Icon buttons', function() {

    var $scope, $compile;

    beforeEach(module('att.abs.iconButtons'));
    beforeEach(module('app/scripts/ng_js_att_tpls/iconButtons/iconButton.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/iconButtons/iconButtonLink.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    describe('checkbox radio check', function() {

        var compileButton = function(markup, scope) {
            $scope.select = [
                "Archive",
                "Save History",
                "Send Email",
                "Delete"
            ];
            var el = $compile(markup)(scope);
            scope.$digest();
            return el;
        };

        it('should not show dropdown when dropdown attribute is not set', function() {
            var elem = compileButton('<button att-icon-btn="icon-filters"></button>', $scope);
            expect(elem).not.toHaveClass('button--active');
            elem.click();
            expect(elem).not.toHaveClass('button--active');
        });
        it('should show dropdown when attribute dropdown="true" is used', function() {
            var elem = compileButton("<button att-icon-btn=\"icon-more-options\" dropdown=\"true\"><att-icon-btn-link ng-repeat=\"options in select\"><a href=\"javascript:void(0);\" class=\"dropdown__menu-link\">\{{options}}</a></att-icon-btn-link></button>", $scope);
            expect(elem).not.toHaveClass('button--active');
            elem.click();
            expect(elem).toHaveClass('button--active');
        });
        it('should have the button--small class when attribute btn-size="small" is used', function() {
            var elem = compileButton("<button att-icon-btn=\"icon-more-options\" dropdown=\"true\" btn-size=\"small\"><att-icon-btn-link ng-repeat=\"options in select\"><a href=\"javascript:void(0);\" class=\"dropdown__menu-link\">\{{options}}</a></att-icon-btn-link></button>", $scope);
            expect(elem).not.toHaveClass('button--active');
            expect(elem).toHaveClass('button--small');
            elem.click();
            expect(elem).toHaveClass('button--active');
            expect(elem).toHaveClass('button--small');
        });
        it('should have li elements as many as options are passed', function() {
            var elem = compileButton("<button att-icon-btn=\"icon-more-options\" dropdown=\"true\"><att-icon-btn-link ng-repeat=\"options in select\"><a href=\"javascript:void(0);\" class=\"dropdown__menu-link\">\{{options}}</a></att-icon-btn-link></button>", $scope);
            var list=elem.find('li');
            expect(list.length).toBe(4);
        });
       it('should select the list element on hovering the element', function() {
            var elem = compileButton("<button att-icon-btn=\"icon-more-options\" dropdown=\"true\"><att-icon-btn-link ng-repeat=\"options in select\"><a href=\"javascript:void(0);\" class=\"dropdown__menu-link\">\{{options}}</a></att-icon-btn-link></button>", $scope);
            var list=elem.find('li');
            list.trigger( 'mouseenter' );
            expect(list).toHaveClass('dropdown__menu-item--active');
            list.trigger( 'mouseleave' );
            expect(list).not.toHaveClass('dropdown__menu-item--active');
        });
    });
   
});
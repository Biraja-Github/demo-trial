 var iconButtonsController = function($scope) {
        $scope.icon=[
        {
           iconClass:"icon-filters" 
        },
        {
           iconClass:"icon-search"
        },
        {
           iconClass:"icon-settings"
        }];
    
    $scope.select=[
        "Archive",
        "Save History",
        "Send Email",
        "Delete"
        ];
    };
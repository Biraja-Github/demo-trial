angular.module('att.abs.splitButtonDropdown', ['att.abs.utilities'])
        .directive('attButtonDropdown', ['$document', '$parse', '$documentBind', function($document, $parse, $documentBind) {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/splitButtonDropdown/splitButtonDropdown.html',
                    scope: {
                        btnText: "@",
                        btnType: "@",
                        btnLink: "@",
                        btnClick: "&"
                    },
                    link: function(scope, element, attr) {
                        scope.isSmall = false;
                        scope.isDropDownOpen = false;
                        scope.isActionDropdown = false;
                        var flag = false;

                        if (attr.small === "") {
                            scope.isSmall = true;
                        }

                        if (!(scope.btnText)) {
                            scope.isActionDropdown = true;
                        }
                        
                        scope.clickFxn = function() {
                            if(typeof scope.btnClick === "function" && !scope.btnLink){
                                scope.btnClick = $parse(scope.btnClick);
                                scope.btnClick();
                            }
                        };

                        scope.toggleDropdown = function() {
                            if (!(scope.btnType === 'disabled')) {
                                flag = scope.isDropDownOpen = !scope.isDropDownOpen;
                            }
                        };
						
                        scope.btnTypeSelector = function(directiveValue, attrValue){
                            if(directiveValue!==""){
                                scope.btnTypeFinal=directiveValue;
                            }
                            else{
                                scope.btnTypeFinal=attrValue;
                            }
                        };
						
                        scope.showDropdown = function() {
                            if (!(scope.btnType === 'disabled')) {
                                scope.isDropDownOpen = true;
                                flag = true;
                            }
                        };

                        scope.hideDropdown = function() {
                            if (!(scope.btnType === 'disabled')) {
                                scope.isDropDownOpen = false;
                                flag = false;
                            }
                        };

                        var outsideClick = function(e) {
                            if (!flag) {
                                scope.$apply(function() {
                                    scope.isDropDownOpen = false;
                                });
                            }
                            flag = false;
                        };

                        $documentBind.click('isDropDownOpen', outsideClick, scope);

                        attr.$observe('btnType', function(val) {
                            scope.btnType = val;
                        });
                        attr.$observe('attButtonDropdown', function(val) {
                            attr.attButtonDropdown=val;
                            scope.btnTypeSelector(attr.attButtonDropdown, scope.btnType);
                        });
                    }
                };

            }])
.constant('iconStateConstants', {
    MIDDLE: 'middle',
    LEFT: 'left',
    RIGHT: 'right',
    NEXT_TO_DROPDOWN:'next-to-dropdown',
    LEFT_NEXT_TO_DROPDOWN:'left-next-to-dropdown',
    DIR_TYPE: {
        LEFT: 'left',
        RIGHT:  'right',
        BUTTON: 'button'
    }
})
.directive('expandableLine', ['$document',function($document){
    return {
        restrict: 'EA',
        replace: true,
        priority: 300,
        require: ['^attSplitIconButton', 'expandableLine'],
        controller: ['$scope', function($scope){
            $scope.isActive = false;
            this.setActiveState = function(isActive){
                $scope.isActive = isActive;
            }
            this.isActive = $scope.isActive;
            this.dirType = $scope.dirType;
        }],
        template: '<div ng-class="{\'expand-line-container\': !isActive, \'expand-line-container-active\': isActive}"> <div ng-class="{\'hovered-line\':isActive, \'vertical-line\':!isActive}"> </div></div>',
        scope:{
            dirType: '@'
        },
        link: function(scope,element,attr,ctrls){
            var attSplitIconButtonCtrl = ctrls[0];
            var expandableLineCtrl = ctrls[1];
            attSplitIconButtonCtrl.addSubCtrl(expandableLineCtrl);
        }
    }
}])
.directive('attSplitIcon', ['$document', '$timeout','iconStateConstants','$documentBind', function($document,$timeout,iconStateConstants,$documentBind){
    return {
        restrict: 'EA',
        replace: true,
        priority: 200,
        transclude: true,
        require: ['^attSplitIconButton','attSplitIcon'],
        templateUrl: 'app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIcon.html',
        scope:{
            icon: '@',
            hoverWatch: '=',
            dropDownWatch: '=',
            dirType: '@'
        },
        controller: ['$scope', function($scope){
            this.setType = function(type){
                $scope.type = type;
            };
            this.isDropdown = function(isDropdown){
                $scope.isDropdown = isDropdown;
            };
            this.dirType = $scope.dirType;
        }],
        link: function(scope,element,attr,ctrls){

            var attSplitIconButtonCtrl = ctrls[0];
            var attSplitIconCtrl = ctrls[1];
            attSplitIconButtonCtrl.addSubCtrl(attSplitIconCtrl);

            scope.iconStateConstants = iconStateConstants;
            var isMyElement = false;
            scope.isDropdown = false;
            scope.isDropdownOpen = false;

            scope.$watch('isIconHovered', function(val){
                scope.hoverWatch = val;
            });

            scope.$watch('type', function(val){

                function toggleValues(isMiddle,isNextToDropDown,isRight,isLeft,isLeftNextDropdown){
                    scope['isMiddle']  = isMiddle;
                    scope['isNextToDropDown'] = isNextToDropDown;
                    scope['isRight']  = isRight;
                    scope['isLeft'] = isLeft;
                    scope['isLeftNextDropdown'] = isLeftNextDropdown;
                };

                if(val == scope.iconStateConstants.MIDDLE){
                    toggleValues(true,false,false,true,false);
                }
                else if(val ==  scope.iconStateConstants.LEFT){
                    toggleValues(false,false,false,true,false);
                }
                else if(val == scope.iconStateConstants.RIGHT){
                    toggleValues(false,false,true,false,false);
                }else if(val == scope.iconStateConstants.NEXT_TO_DROPDOWN){
                    toggleValues(false,true,true,true,false);
                }else  if(val == scope.iconStateConstants.LEFT_NEXT_TO_DROPDOWN){
                    toggleValues(false,false,false,true,true);
                }
            });

            if(attr.dropDownId && attr.dropDownId != ''){
                scope.dropDownId = attr.dropDownId;
                scope.isDropdown = true;
            }

            scope.dropDownClicked = function(){
                isMyElement = true;
            };

            scope.toggleDropdown = function(val) {

                if(val != undefined)
                    scope.isDropDownOpen=val;
                else
                    scope.isDropDownOpen = !scope.isDropDownOpen; 

                scope.dropDownWatch = scope.isDropDownOpen;
            };

            var outsideClick = function(e) {
                if(scope.isDropdown){
                    if (isMyElement) {
                        isMyElement = false;
                        scope.toggleDropdown();
                    }else{
                        scope.toggleDropdown(false);
                    }
                    scope.$apply();
                }
            };

            $documentBind.click('isDropdown', outsideClick, scope);
        }
    }
}])
.controller('AttSplitIconButtonCtrl',['$scope', 'iconStateConstants',function($scope,iconStateConstants){

    this.subCtrls = [];

    $scope.isLeftLineShown=true;
    $scope.isRightLineShown=true;
    $scope.childrenScopes = [];

    var origLeftLineShown = $scope.isLeftLineShown;
    var origRightLineShown = $scope.isRightLineShown;

    var that = this;

    function getDirIndex(dirType){
        var index = -1;
        for(var c in that.subCtrls){
            var ctrl = that.subCtrls[c];
            if(ctrl.dirType==dirType){
                index = c;
                break;
            }
        }
        return index;
    }

    this.addSubCtrl =  function(sub){
        this.subCtrls.push(sub);
    };

    this.isLeftLineShown = function(isShown){
        if(isShown == undefined)
            return $scope.isLeftLineShown;
        else
            $scope.isLeftLineShown = isShown;
    };

    this.isRightLineShown = function(isShown){
        if(isShown == undefined)
            return $scope.isRightLineShown;
        else
            $scope.isRightLineShown = isShown;
    };

    this.setLeftLineHover = function(isHovered){
        var leftLineIndex = getDirIndex(iconStateConstants.DIR_TYPE.LEFT);

        if($scope.isLeftLineShown){
            if(this.subCtrls[leftLineIndex] && this.subCtrls[leftLineIndex].setActiveState){
                this.subCtrls[leftLineIndex].setActiveState(isHovered);
            }
        }
    };

    this.setRightLineHover = function(isHovered){
        var rightLineIndex = getDirIndex(iconStateConstants.DIR_TYPE.RIGHT);
        if($scope.isRightLineShown){
            if(this.subCtrls[rightLineIndex]  && this.subCtrls[rightLineIndex].setActiveState){
                this.subCtrls[rightLineIndex].setActiveState(isHovered);
            }
        }
    };

    this.toggleLines = function(isHovered,buttonGroupCtrl,buttonCtrl,isDropDownOpen){  

        var subIconButtons = buttonGroupCtrl.subIconButtons;
        var subIconButtonsLength = subIconButtons.length;

        var leftLineIndex =  getDirIndex(iconStateConstants.DIR_TYPE.LEFT);
        var rightLineIndex =  getDirIndex(iconStateConstants.DIR_TYPE.RIGHT);

        function noVerticalLineToggle(){
            for(var i =0; i < subIconButtonsLength; i++){
                if(subIconButtons[i] == buttonCtrl){
                    if(i + 1 <= subIconButtonsLength - 1){
                        if(subIconButtons[i+1].isLeftLineShown() && subIconButtons[i+1].subCtrls[leftLineIndex] 
                            && subIconButtons[i+1].subCtrls[leftLineIndex].setActiveState)
                            subIconButtons[i+1].subCtrls[leftLineIndex].setActiveState(isHovered);
                    }
                    if(i - 1 >= 0){
                        if(subIconButtons[i-1].isRightLineShown() && subIconButtons[i-1].subCtrls[rightLineIndex] 
                            && subIconButtons[i-1].subCtrls[rightLineIndex].setActiveState)
                            subIconButtons[i-1].subCtrls[rightLineIndex].setActiveState(isHovered);
                    }
                    break;
                }
            }
        }   

        if(isDropDownOpen){
            /*
              If the button is next to the dropdown button then just keep the 
              buttons left line or its left neighbors right line toggled on
              If the button is the dropdown button don't do anything
              else do things normally witht the button
            */
            if(subIconButtons[subIconButtonsLength-1] == buttonCtrl){

            }
            else if(subIconButtons[subIconButtonsLength-2]==buttonCtrl){
                if(subIconButtons[subIconButtonsLength-2].isLeftLineShown())
                    subIconButtons[subIconButtonsLength-2].subCtrls[leftLineIndex].setActiveState(isHovered);
                else if(subIconButtonsLength  - 3 >= 0){
                    if(subIconButtons[subIconButtonsLength-3].isRightLineShown())
                        subIconButtons[subIconButtonsLength-3].subCtrls[rightLineIndex].setActiveState(isHovered);
                }
            }else{
               
                noVerticalLineToggle();

                if($scope.isLeftLineShown){
                    this.subCtrls[leftLineIndex].setActiveState(isHovered);
                }

                if($scope.isRightLineShown){
                    this.subCtrls[rightLineIndex].setActiveState(isHovered);
                }
            }
        }
        else{
            //Handle Special cases where they aren't showing any vertical lines
            //and the dropdown isn't down
            if(!$scope.isLeftLineShown && !$scope.isRightLineShown){
                noVerticalLineToggle();
            }   

            if($scope.isLeftLineShown){
                if(this.subCtrls[leftLineIndex].setActiveState)
                this.subCtrls[leftLineIndex].setActiveState(isHovered);
            }

            if($scope.isRightLineShown){
                if(this.subCtrls[rightLineIndex].setActiveState)
                this.subCtrls[rightLineIndex].setActiveState(isHovered);
            }
        }
    };
  
    this.setButtonType = function(type){
        var buttonIndex = getDirIndex(iconStateConstants.DIR_TYPE.BUTTON);
        if(this.subCtrls[buttonIndex] && this.subCtrls[buttonIndex].setType)
            this.subCtrls[buttonIndex].setType(type);
    };

}])
.directive('attSplitIconButton', ['$document', 'iconStateConstants',function($document,iconStateConstants){
    return {
        restrict: 'EA',
        replace: true,
        priority: 100,
        transclude: true,
        require: ['^attSplitIconButtonGroup', 'attSplitIconButton'],
        controller: 'AttSplitIconButtonCtrl',
        templateUrl: 'app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIconButton.html',
        scope:{
            icon: '@',
            dropDownId: '@'
        },
        link: function(scope,element,attr,ctrls){
            var attSplitButtonGroupCtrl = ctrls[0];
            var attSplitIconButtonCtrl = ctrls[1];
            attSplitButtonGroupCtrl.addIconButton(attSplitIconButtonCtrl);
            scope.dropDownWatch = false;

            scope.iconStateConstants = iconStateConstants;

            scope.clickHandler = function(){
                attSplitButtonGroupCtrl.hideLeftLineRightButton(attSplitIconButtonCtrl);
            };
            
            scope.$watch('isHovered', function(val){
                if(val){
                    attSplitIconButtonCtrl.toggleLines(val,attSplitButtonGroupCtrl,attSplitIconButtonCtrl,attSplitButtonGroupCtrl.isDropDownOpen);
                }else{
                    attSplitIconButtonCtrl.toggleLines(val,attSplitButtonGroupCtrl,attSplitIconButtonCtrl,attSplitButtonGroupCtrl.isDropDownOpen);
                }
            });

            scope.$watch('dropDownWatch', function(val){
                attSplitButtonGroupCtrl.isDropDownOpen = val;
                attSplitButtonGroupCtrl.toggleDropdownState(val);
            });
        }
    }
}])
.controller('AttSplitIconButtonGroupCtrl',   ['$scope','iconStateConstants',function($scope,iconStateConstants){
    
    this.subIconButtons = [];
    this.addIconButton = function(iconButton){
       this.subIconButtons.push(iconButton);
    };

    this.isDropDownOpen = false;

    this.hideLeftLineRightButton = function(btn){
        var numButtons = this.subIconButtons.length;
        var buttonLeftOfRightMost = this.subIconButtons[numButtons - 2];
        var rightMostButton = this.subIconButtons[numButtons -1];

        if (btn != buttonLeftOfRightMost && btn != rightMostButton ){
            rightMostButton.setLeftLineHover(false);
        }
    };

    this.toggleDropdownState = function(isDropDownOpen){

        var numButtons = this.subIconButtons.length;
   
        if(numButtons > 2){
            
            if(isDropDownOpen){

                if(this.subIconButtons[numButtons - 2].isRightLineShown())
                    this.subIconButtons[numButtons - 2].setRightLineHover(true);
                else
                    this.subIconButtons[numButtons - 1].setLeftLineHover(true);

                this.subIconButtons[numButtons - 2].setButtonType(iconStateConstants.NEXT_TO_DROPDOWN);
            }else{
                this.subIconButtons[numButtons - 2].setButtonType(iconStateConstants.MIDDLE);
            }

        }else{

            if(isDropDownOpen){
                this.subIconButtons[0].setRightLineHover(true);
                this.subIconButtons[0].setButtonType(iconStateConstants.LEFT_NEXT_TO_DROPDOWN);
            }else{
                this.subIconButtons[0].setButtonType(iconStateConstants.LEFT);
            }
        }

    };

}])
.directive('attSplitIconButtonGroup', ['$document', '$timeout',  'iconStateConstants' ,function($document,$timeout,iconStateConstants){
    return {
        restrict: 'EA',
        replace: true,
        priority: 50,
        transclude: true,
        require: 'attSplitIconButtonGroup',
        controller: 'AttSplitIconButtonGroupCtrl',
        templateUrl: 'app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIconButtonGroup.html',
        scope:{},
        link: function(scope,element,attr,ctrls){

            $timeout(initialize,100);
         
            function initialize(){
                var subIconButtonCtrls = ctrls.subIconButtons;
                var leftMostButtonIndex = 0;
                var rightMostButtonIndex =subIconButtonCtrls.length-1;

                //left most button config
                subIconButtonCtrls[leftMostButtonIndex].setButtonType(iconStateConstants.LEFT);
                subIconButtonCtrls[leftMostButtonIndex].isLeftLineShown(false);
                subIconButtonCtrls[leftMostButtonIndex].isRightLineShown(true);

                //right most button config
                subIconButtonCtrls[rightMostButtonIndex].setButtonType(iconStateConstants.RIGHT);
                subIconButtonCtrls[rightMostButtonIndex].isRightLineShown(false);
                subIconButtonCtrls[rightMostButtonIndex].isLeftLineShown(false);

                //middle buttons config
                if(rightMostButtonIndex >= 2){
                    var index = 1;
                    while(index < rightMostButtonIndex){
                        subIconButtonCtrls[index].setButtonType(iconStateConstants.MIDDLE);
                        subIconButtonCtrls[index].isRightLineShown(false);
                        subIconButtonCtrls[index].isLeftLineShown(false);
                        index++;
                    }

                    var skipIndex = 2;
                    while(skipIndex <= rightMostButtonIndex){
                        if(skipIndex == rightMostButtonIndex){
                            subIconButtonCtrls[skipIndex].isLeftLineShown(true);
                        }else{
                            subIconButtonCtrls[skipIndex].isRightLineShown(true);
                            subIconButtonCtrls[skipIndex].isLeftLineShown(true); 
                        } 
                        skipIndex = skipIndex + 2;
                    }
                }

                //reposition the dropdown
                var ulElem = element.find('ul');
                if(ulElem.length > 0){
                    var numButtons = rightMostButtonIndex+1;
                    if(numButtons > 2){
                        var offset = (numButtons)*34-70+(numButtons/1.5) + 0.5;
                        var offSetStr = offset+'px';
                        angular.element(ulElem).css('left',offSetStr);
                        angular.element(ulElem).css('border-top-left-radius','0px');
                    }else{
                        angular.element(ulElem).css('left','0px');
                    }
                }
            }
        }
    }
}])
 .directive('attButtonDropdownItem', [function() {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/splitButtonDropdown/splitButtonDropdownItem.html',
                    scope: {
                        itemLink: "@"
                    },
                    link: function(scope, element, attr) {
                        element.bind('mouseenter', function(){
                            element.addClass('dropdown__menu-item--active');
                        }).bind('mouseleave', function(){
                            element.removeClass('dropdown__menu-item--active');
                        });
                        
                        if(attr.attButtonDropdownItem!==""){
                            scope.itemLink=attr.attButtonDropdownItem;
                        }
                        
                        scope.itemLinkSelector = function(directiveValue, attrValue){
                            if(directiveValue!==""){
                                scope.itemLinkFinal=directiveValue;
                            }
                            else{
                                scope.itemLinkFinal=attrValue;
                            }
                        };
                        
                        attr.$observe('itemLink', function(val) {
                            scope.itemLink=val;
                            scope.itemLinkSelector(attr.attButtonDropdownItem, scope.itemLink);
                        });
                        
                        attr.$observe('attButtonDropdownItem', function(val) {
                            attr.attButtonDropdownItem=val;
                            scope.itemLinkSelector(attr.attButtonDropdownItem, scope.itemLink);
                        });
                    }
                };
            }]);

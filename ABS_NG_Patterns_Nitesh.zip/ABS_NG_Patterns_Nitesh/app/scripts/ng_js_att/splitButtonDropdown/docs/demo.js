var AbsSplitButtonDropdownCtrl = function($scope) {
    $scope.splitButtonDropdownOptions = [
        "Option Line 1",
        "Another Option 2",
        "Option Line 3"
    ];
    
    $scope.theMethodToBeCalled = function(data) {
        alert(data);
    };
    
    $scope.function1 = function(){
        console.log('function1');
    };

    $scope.function2 = function(){
        console.log('function2');
    };

    $scope.function3 = function(){
        console.log('function3');
    };

    $scope.function4 = function(){
        console.log('function4');
    };

    $scope.function5 = function(){
        console.log('function5');
    };

    $scope.options1 = [
        'option1',
        'option2',
        'option3'
    ];

    $scope.options2 = [
        'option21',
        'option22',
        'option32'
    ];
};
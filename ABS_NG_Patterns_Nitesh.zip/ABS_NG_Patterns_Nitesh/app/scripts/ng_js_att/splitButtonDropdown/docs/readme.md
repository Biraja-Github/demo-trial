<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button-dropdown directive** is built using angular library.
This att-button-dropdown is used as an parent directive to att-button-dropdown-item to create splitButtons.

We can control various parameters like small, btn-text, btn-type, btn-click while using this directive.

#### `<Attribute level configuration for rendering splitButtonDropdown>` ####

 * `small`
 	:
 	The attr flag to render the split-button of small size. No values required.

 * `btn-text`
 	:
 	The attr to indicate the text on split-button.

 * `btn-type`
 	:
 	The attr to indicate the type of Button. primary,disabled,secondary.
    
* `btn-click`
 	:
 	The attr serves as an option to specify a callback function.
    
        Sample Callback function :
        $scope.theMethodToBeCalled = function(data) {
            alert(data);
        }; 

<p class="guideline-title">Directives</p>

The **att-button-dropdown-item directive** is built using angular library.
This att-button-dropdown-item acts as a dropdown. The options in dropdown are clickable links.

We can control the parameter item-link while using this directive.

#### `<Attribute level configuration for rendering splitButtonDropdown>` ####

 * `item-link`
 	:
 	The attr is used to provide the link for the options in dropdown.        

<br/><br/>

<p class="guideline-title">Red Lines</p>
<div class="guidelines-button-split-large"></div>

<br/><br/>

<p class="guideline-title">Red Lines</p>
<div class="guidelines-button-split-small"></div>  

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button-dropdown directive** is built using angular library.
This att-button-dropdown is used as an parent directive to att-button-dropdown-item to create splitButtons.

We can control various parameters like small, btn-text, btn-type, btn-click while using this directive.

#### `<Attribute level configuration for rendering splitButtonDropdown>` ####

 * `small`
 	:
 	The attr flag to render the split-button of small size. No values required.

 * `btn-text`
 	:
 	The attr to indicate the text on split-button.

 * `btn-type`
 	:
 	The attr to indicate the type of Button. primary,disabled,secondary.
    
* `btn-click`
 	:
 	The attr serves as an option to specify a callback function.
    
        Sample Callback function :
        $scope.theMethodToBeCalled = function(data) {
            alert(data);
        }; 

<p class="guideline-title">Directives</p>

The **att-button-dropdown-item directive** is built using angular library.
This att-button-dropdown-item acts as a dropdown. The options in dropdown are clickable links.

We can control the parameter item-link while using this directive.

#### `<Attribute level configuration for rendering splitButtonDropdown>` ####

 * `item-link`
 	:
 	The attr is used to provide the link for the options in dropdown. 

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button-dropdown directive** is built using angular library.
This att-button-dropdown is used as an parent directive to att-button-dropdown-item to create splitButtons.

We can control various parameters like small, btn-text, btn-type, btn-click while using this directive.

#### `<Attribute level configuration for rendering actionButtonDropdown>` ####

 * `small`
 	:
 	The attr flag to render the split-button of small size. No values required.

 * `btn-text`
 	:
 	The attr to indicate the text on split-button.

 * `btn-type`
 	:
 	The attr to indicate the type of Button. primary,disabled,secondary.
    
* `btn-click`
 	:
 	The attr serves as an option to specify a callback function.
    
        Sample Callback function :
        $scope.theMethodToBeCalled = function(data) {
            alert(data);
        }; 

<p class="guideline-title">Directives</p>

The **att-button-dropdown-item directive** is built using angular library.
This att-button-dropdown-item acts as a dropdown. The options in dropdown are clickable links.

We can control the parameter item-link while using this directive.

#### `<Attribute level configuration for rendering actionButtonDropdown>` ####

 * `item-link`
 	:
 	The attr is used to provide the link for the options in dropdown. 

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-split-icon-button-group directive** is built using angular library.
This att-split-icon-button-group is used as an parent directive to att-split-icon-button to create splitIconButtons.

We can control various parameters like icon, ng-click while using this directive.

#### `<Attribute level configuration for rendering tags>` ####

 * `icon`
 	:
 	The attr icon to indiacte the icon on button.
    
* `ng-click`
 	:
 	The attr serves as an option to specify a callback function.
    
        Sample Callback function :
        $scope.theMethodToBeCalled = function(data) {
            alert(data);
        };
       
<p class="guideline-title">Directives</p>
The **att-split-icon-button directive** is built using angular library.
This att-split-icon-button acts as a dropdown. The options in dropdown are clickable links.

We can control various parameters like icon, drop-down-id while using this directive.

#### `<Attribute level configuration for rendering splitIconButtons>` ####

 * `icon`
 	:
 	The attr icon to indiacte the icon on button.
    
* `drop-down-id`
 	:
 	The attr makes the button act as an dropdown.    
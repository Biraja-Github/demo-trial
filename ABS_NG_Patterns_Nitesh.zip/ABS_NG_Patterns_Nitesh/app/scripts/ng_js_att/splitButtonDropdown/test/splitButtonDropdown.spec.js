describe('splitButtonDropdown', function() {
    
    var $scope, $compile;

    // load the tagBadges code
    beforeEach(module('att.abs.splitButtonDropdown'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/splitButtonDropdown/splitButtonDropdownItem.html'));
	beforeEach(module('app/scripts/ng_js_att_tpls/splitButtonDropdown/splitButtonDropdown.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));
    
    beforeEach(inject(function(_$rootScope_) {
        _$rootScope_.splitButtonDropdownOptions = [
            "Option Line 1",
            "Another Option 2",
            "Option Line 3"
        ];
    }));

    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };
    
   it('should be rendered default primary when the att-button-dropdown attr is applied', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"></div>', $scope, $compile);

       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0)).toHaveClass('button');
       expect(localElm.find('button').eq(0).text()).toBe('Primary');
       expect(localElm.find('div').eq(0)).toHaveClass('button button--dropdown');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });
   
   it('should be rendered primary type when the att-button-dropdown attr is applied with btn-type="primary"', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary" btn-type="primary"></div>', $scope, $compile);

       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0).text()).toBe('Primary');
       expect(localElm.find('button').eq(0)).toHaveClass('button--primary');
       expect(localElm.find('div').eq(0)).toHaveClass('button--primary');

   });

   it('should be rendered secondary type when the att-button-dropdown attr is applied with btn-type="secondary"', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Secondary" btn-type="secondary"></div>', $scope, $compile);

       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0).text()).toBe('Secondary');
       expect(localElm.find('button').eq(0)).toHaveClass('button--secondary');
       expect(localElm.find('div').eq(0)).toHaveClass('button--secondary');
   });
   
   it('should be rendered disabled type when the att-button-dropdown attr is applied with btn-type="disabled"', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Disable" btn-type="disabled"></div>', $scope, $compile);

       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0).text()).toBe('Disable');
       expect(localElm.find('button').eq(0)).toHaveClass('button--disabled');
       expect(localElm.find('div').eq(0)).toHaveClass('button--disabled');
   });
   
   it('should be rendered small when the att-button-dropdown attr is applied with attr small', function() {
       var localElm = compileElement('<div att-button-dropdown small btn-text="Primary"></div>', $scope, $compile);

       expect(localElm).toHaveClass('button-group');
       expect(localElm).toHaveClass('split-button--small');
       expect(localElm.find('button').eq(0)).toHaveClass('button--small');
       expect(localElm.find('div').eq(0)).toHaveClass('button button--dropdown');
       expect(localElm.find('div').eq(0)).toHaveClass('button--small');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });

   it('should open dropdown menu when dropdown arrow is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"></div>', $scope, $compile);
	   
       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
   });

   it('should close dropdown menu when dropdown menu is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">{{option}}</div></div>', $scope, $compile);      
	   
       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
       localElm.find('ul').eq(0).click();
       expect(localElm.find('div').eq(0)).not.toHaveClass('button--active');
   });

   it('should close dropdown menu when any of dropdown menu item is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">{{option}}</div></div>', $scope, $compile);
	   
        localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
       localElm.find('li').eq(0).click();
       expect(localElm).not.toHaveClass('button--active');
   });
   
   it('the dropdown menu should have the defined select options', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">{{option}}</div></div>', $scope, $compile);
	   
       localElm.find('div').eq(0).click();	 
       var temp = angular.element(localElm.find("ul > li > a")[0]);
       expect(temp.text()).toBe('Option Line 1');
      temp = angular.element(localElm.find("ul > li > a")[1]);
       expect(temp.text()).toBe('Another Option 2');
       temp = angular.element(localElm.find("ul > li > a")[2]);
       expect(temp.text()).toBe('Option Line 3');
   });
   
   it('should be rendered as action dropdown type primary when the att-button-dropdown attr is applied with no btn-text defined', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">{{option}}</div></div>', $scope, $compile);
	   
       expect(localElm).toHaveClass('button-group');	 
		expect(localElm.find('button').eq(0)).toHaveClass('button');
		expect(localElm.find('button').eq(0)).toHaveClass('button--primary');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });

   it('should be rendered as action dropdown type primary small when the att-button-dropdown attr is applied with attr small and no btn-text defined', function() {
       var localElm = compileElement('<div att-button-dropdown small btn-text="Primary"><li><a href="#" ng-repeat="options in select">{{options}}</a></li></div>', $scope, $compile);
       
       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0)).toHaveClass('button');
       expect(localElm.find('button').eq(0)).toHaveClass('button--small');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });
   
   it('should be rendered as action dropdown type secondary when the att-button-dropdown attr is applied with btn-type="secondary" and no btn-text defined', function() {
       var localElm = compileElement('<div att-button-dropdown btn-type="secondary" btn-text="Primary"><li><a href="#" ng-repeat="options in select">{{options}}</a></li></div>', $scope, $compile);
	   
       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0)).toHaveClass('button--secondary');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });
   
   it('should be rendered as action dropdown type secondary small when the att-button-dropdown attr is applied with btn-type="secondary" and attr small and btn-text defined as blank', function() {
       var localElm = compileElement('<div att-button-dropdown small btn-type="secondary" btn-text="Primary"><li><a href="#" ng-repeat="options in select">{{options}}</a></li></div>', $scope, $compile);
	   
       expect(localElm).toHaveClass('button-group');
       expect(localElm.find('button').eq(0)).toHaveClass('button--small');
       expect(localElm.find('ul').eq(0)).toHaveClass('dropdown__menu');
   });

   it('should open action dropdown menu when dropdown arrow is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">\{{option}}</div></div>', $scope, $compile);
	   
        localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
   });
   
   it('should close action dropdown menu when dropdown arrow is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">\{{option}}</div></div>', $scope, $compile);
	   
       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).not.toHaveClass('button--active');
   });
   
   it('should close action dropdown menu when dropdown menu is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">\{{option}}</div></div>', $scope, $compile);

       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
       localElm.find('ul').eq(0).click();
       expect(localElm.find('div').eq(0)).not.toHaveClass('button--active');
   });
   
   it('should close action dropdown menu when any of dropdown menu item is clicked', function() {
       var localElm = compileElement('<div att-button-dropdown btn-text="Primary"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">\{{option}}</div></div>', $scope, $compile);
	   
       localElm.find('div').eq(0).click();
       expect(localElm.find('div').eq(0)).toHaveClass('button--active');
       localElm.find('li').eq(0).click();
       expect(localElm.find('div').eq(0)).not.toHaveClass('');
   });
   
   it('should execute btn-click function when the main button is clicked', function() {
       $scope.theMethodToBeCalled = function(data) {
            //alert(data);
       };
       var localElm = compileElement('<div att-button-dropdown small btn-text="Primary" btn-type="primary" btn-click="theMethodToBeCalled(\'Clicked...!!\')"><div att-button-dropdown-item ng-repeat="option in splitButtonDropdownOptions" item-link="javascript:void(0);">\{{option}}</div></div>', $scope, $compile);
	   
       spyOn($scope,"theMethodToBeCalled");
       localElm.find('button').eq(0).click();
       expect($scope.theMethodToBeCalled).toHaveBeenCalled();
   });
});

describe('iconSplitButtonGroup', function() {

    var $scope, $compile;
    var markUp = '<div att-split-icon-button-group><div att-split-icon-button icon=\'icon-print\' ng-click=\'function1()\'></div><div att-split-icon-button icon=\'icon-print\' ng-click=\'function2()\'></div><div att-split-icon-button icon=\'icon-download\' drop-down-id=\'dropdownone\' ng-click=\'function3()\'><li ng-repeat=\'o in options1\'><a href="#" ng-bind=\'o\'></a></li></div></div>';

    // load the tagBadges code
    beforeEach(module('att.abs.splitButtonDropdown'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIcon.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIconButton.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/splitButtonDropdown/splitIconButtonGroup.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };

    it('should create the correct number of icon buttons', function(){
        $scope.options1 = [
            'option1',
            'option2',
            'option3'
        ];

        var element = compileElement(markUp,$scope,$compile);
        var divs = element.find('div');

        var myClass = 'split-icon-button';
        expect(divs.eq(4)).toHaveClass(myClass);
        expect(divs.eq(11)).toHaveClass(myClass);
        expect(divs.eq(18)).toHaveClass(myClass);

    });

    it('should be clickable', function(){
        var toggle =false;
        $scope.function1 = function(){
            toggle = true;
        };

        var element = compileElement(markUp,$scope,$compile);
        var divs = element.find('div');

        var myClass = 'split-icon-button';
        divs.eq(4).click();
        expect(toggle).toBe(true);
    });

});

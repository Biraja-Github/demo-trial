describe('datepicker directive', function() {
    var rootScope, element;
    beforeEach(module('att.abs.datepicker'));
    beforeEach(module('app/scripts/ng_js_att_tpls/datepicker/datepicker.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/datepicker/datepickerPopup.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/datepicker/dateFilter.html'));
    beforeEach(inject(function(_$compile_, _$rootScope_) {
        var $compile = _$compile_;
        rootScope = _$rootScope_;

        rootScope.dt = new Date("March 10, 2014 00:00:00");
        rootScope.dueDate = "2014-05-21";
        rootScope.minDate = "2014-01-02";
        rootScope.maxDate = "2014-06-26";

        element = angular.element('<div><input id="datepicker1" name="datepicker1" type="text" ng-model="dt" att-datepicker min="minDate" max="maxDate"></div>');
        element = $compile(element)(rootScope);
        rootScope.$digest();
    }));

    function getTitle() {
        return element.find('table').eq(0).find('thead').find('tr').eq(0).find('th').eq(0).text();
    }

    function clickPreviousButton(times) {
        var el = element.find('table').eq(0).find('thead').find('tr').eq(0).find('th').eq(1);
        for (var i = 0, n = times || 1; i < n; i++) {
            el.click();
        }
    }

    function clickNextButton(times) {
        var el = element.find('table').eq(0).find('thead').find('tr').eq(0).find('th').eq(2);
        for (var i = 0, n = times || 1; i < n; i++) {
            el.click();
        }
    }

    function getLabelsRow() {
        return element.find('table').eq(0).find('thead').find('tr').eq(1);
    }

    function getLabels() {
        var els = getLabelsRow().find('th');

        var labels = [];
        for (var i = 0, n = els.length; i < n; i++) {
            labels.push(els.eq(i).text().substr(0, 3));
        }
        return labels;
    }

    function getOptions() {
        var tr = element.find('table').eq(1).find('tbody').find('tr');
        var rows = [];

        for (var j = 0, numRows = tr.length; j < numRows; j++) {
            var cols = tr.eq(j).find('td'), days = [];
            if(cols.length < 7) {
                break;
            }
            for (var i = 0, n = cols.length; i < n; i++) {
                days.push(cols.eq(i).text());
            }
            rows.push(days);
        }
        return rows;
    }

    function _getOptionEl(rowIndex, colIndex) {
        return element.find('table').eq(1).find('tbody').find('tr').eq(rowIndex).find('td').eq(colIndex);
    }

    function clickOption(rowIndex, colIndex) {
        _getOptionEl(rowIndex, colIndex).click();
    }

    function getAllOptionsEl() {
        var tr = element.find('table').eq(1).find('tbody').find('tr'), rows = [];
        for (var i = 0; i < tr.length; i++) {
            var td = tr.eq(i).find('td'), cols = [];
            if(td.length < 7) {
                break;
            }
            for (var j = 0; j < td.length; j++) {
                cols.push(td.eq(j));
            }
            rows.push(cols);
        }
        return rows;
    }

    function expectSelectedElement(row, col) {
        var options = getAllOptionsEl();
        for (var i = 0, n = options.length; i < n; i++) {
            var optionsRow = options[i];
            for (var j = 0; j < optionsRow.length; j++) {
                expect(optionsRow[j].hasClass('active')).toBe(i === row && j === col);
            }
        }
    }

    it('shows the correct title', function() {
        expect(getTitle()).toBe('March 2014');
    });

    it('shows the label row & the correct day labels', function() {
        expect(getLabels()).toEqual(['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']);
    });

    it('renders the calendar days correctly', function() {
        var dates = [['23',
                '24',
                '25',
                '26',
                '27',
                '28',
                '1'],
            ['2',
                '3',
                '4',
                '5',
                '6',
                '7',
                '8'],
            ['9',
                '10',
                '11',
                '12',
                '13',
                '14',
                '15'],
            ['16',
                '17',
                '18',
                '19',
                '20',
                '21',
                '22'],
            ['23',
                '24',
                '25',
                '26',
                '27',
                '28',
                '29'],
            ['30',
                '31',
                '1',
                '2',
                '3',
                '4',
                '5']];
        expect(getOptions()).toEqual(dates);
    });

    it('value is correct', function() {
        expect(rootScope.dt).toEqual(new Date("March 10, 2014 00:00:00"));
    });

    it('has `selected` only the correct day', function() {
        expectSelectedElement(2, 1);
    });

    it('updates the model when a day is clicked', function() {
        clickOption(2, 4);
        expect(rootScope.dt).toEqual(new Date("March 13, 2014 00:00:00"));
    });

    it('moves to the previous month & renders correctly when `previous` button is clicked', function() {
        clickPreviousButton();

        var dates = [['26',
                '27',
                '28',
                '29',
                '30',
                '31',
                '1'],
            ['2',
                '3',
                '4',
                '5',
                '6',
                '7',
                '8'],
            ['9',
                '10',
                '11',
                '12',
                '13',
                '14',
                '15'],
            ['16',
                '17',
                '18',
                '19',
                '20',
                '21',
                '22'],
            ['23',
                '24',
                '25',
                '26',
                '27',
                '28',
                '1']];
        expect(getTitle()).toBe('February 2014');
        expect(getLabels()).toEqual(['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']);
        expect(getOptions()).toEqual(dates);
        expectSelectedElement(null, null);
    });

    it('updates the model only when a day is clicked in the `previous` month', function() {
        clickPreviousButton();
        expect(rootScope.dt).toEqual(new Date("March 10, 2014 00:00:00"));

        clickOption(2, 3);
        expect(rootScope.dt).toEqual(new Date("February 12, 2014 00:00:00"));
    });

    it('moves to the next month & renders correctly when `next` button is clicked', function() {
        clickNextButton();

        var dates = [['30',
                '31',
                '1',
                '2',
                '3',
                '4',
                '5'],
            ['6',
                '7',
                '8',
                '9',
                '10',
                '11',
                '12'],
            ['13',
                '14',
                '15',
                '16',
                '17',
                '18',
                '19'],
            ['20',
                '21',
                '22',
                '23',
                '24',
                '25',
                '26'],
            ['27',
                '28',
                '29',
                '30',
                '1',
                '2',
                '3']];
        expect(getTitle()).toBe('April 2014');
        expect(getLabels()).toEqual(['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']);
        expect(getOptions()).toEqual(dates);
        expectSelectedElement(null, null);
    });

    it('updates the model only when when a day is clicked in the `next` month', function() {
        clickNextButton();
        expect(rootScope.dt).toEqual(new Date("March 10, 2014 00:00:00"));

        clickOption(2, 3);
        expect(rootScope.dt).toEqual(new Date("April 16, 2014 00:00:00"));
    });
});

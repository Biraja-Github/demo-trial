var DatepickerCtrl = function ($scope) {
    $scope.dt = new Date("October 10, 2014 00:00:00");

    $scope.minDate = "2014-09-10";
    $scope.maxDate = "2014-11-10";
};

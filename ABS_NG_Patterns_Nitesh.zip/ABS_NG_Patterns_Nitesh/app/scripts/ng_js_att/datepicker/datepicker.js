angular.module('att.abs.datepicker', ['att.abs.position', 'att.abs.utilities'])

.constant('datepickerConfig', {
    dateFormat: 'MM/dd/yyyy',
    dayFormat: 'd',
    monthFormat: 'MMMM',
    yearFormat: 'yyyy',
    dayHeaderFormat: 'EEEE',
    dayTitleFormat: 'MMMM yyyy',
    disableWeekend: false,
    disableSunday: false,
    disableDates: null,
    startingDay: 0,
    minDate: null,
    maxDate: null,
    dateFilter: {
        defaultText: 'Select from list'
    },
    datepickerAttributes: ['dateFormat', 'dayFormat', 'monthFormat', 'yearFormat', 'dayHeaderFormat', 'dayTitleFormat', 'disableWeekend', 'disableSunday', 'disableDates', 'startingDay', 'min', 'max']
})

.factory('datepickerService', ['datepickerConfig', 'dateFilter', function (datepickerConfig, dateFilter) {
    var setAttributes = function (attr, elem) {
        if (angular.isDefined(attr) && attr !== null && angular.isDefined(elem) && elem !== null) {
            var attributes = datepickerConfig.datepickerAttributes;
            for (var key in attr) {
                var val = attr[key];
                if (attributes.indexOf(key) !== -1 && angular.isDefined(val)) {
                    elem.attr(key.toSnakeCase(), key);
                }
            }
        }
    };

    var bindScope = function (attr, scope) {
        if (angular.isDefined(attr) && attr !== null && angular.isDefined(scope) && scope !== null) {
            var watchFunction = function (key, val) {
                scope.$parent.$watch(val, function (value) {
                    scope[key] = value;
                });
                scope.$watch(key, function (value) {
                    scope.$parent[val] = value;
                });
            };

            var attributes = datepickerConfig.datepickerAttributes;
            for (var key in attr) {
                var val = attr[key];
                if (attributes.indexOf(key) !== -1 && angular.isDefined(val)) {
                    watchFunction(key, val);
                }
            }
        }
    };

    var validateDateString = function (dateString, dateFormat) {
        if(dateString && dateFormat) {
            var actualDateString = dateFilter(new Date(dateString), dateFormat);
            if(dateString === actualDateString) {
                return true;
            } else {
                return false;
            }
        }
    };

    return {
        setAttributes: setAttributes,
        bindScope: bindScope,
        validateDateString: validateDateString
    };
}])

.controller('DatepickerController', ['$scope', '$attrs', 'dateFilter', 'datepickerConfig', function($scope, $attrs, dateFilter, dtConfig) {
    var format = {
        date: getValue($attrs.dateFormat, dtConfig.dateFormat),
        day: getValue($attrs.dayFormat, dtConfig.dayFormat),
        month: getValue($attrs.monthFormat, dtConfig.monthFormat),
        year: getValue($attrs.yearFormat, dtConfig.yearFormat),
        dayHeader: getValue($attrs.dayHeaderFormat, dtConfig.dayHeaderFormat),
        dayTitle: getValue($attrs.dayTitleFormat, dtConfig.dayTitleFormat),
        disableWeekend: getValue($attrs.disableWeekend, dtConfig.disableWeekend),
        disableSunday: getValue($attrs.disableSunday, dtConfig.disableSunday),
        disableDates: getValue($attrs.disableDates, dtConfig.disableDates)
    },
    startingDay = getValue($attrs.startingDay, dtConfig.startingDay);

    $scope.minDate = dtConfig.minDate ? $scope.resetTime(dtConfig.minDate) : null;
    $scope.maxDate = dtConfig.maxDate ? $scope.resetTime(dtConfig.maxDate) : null;

    function getValue(value, defaultValue) {
        return angular.isDefined(value) ? $scope.$parent.$eval(value) : defaultValue;
    }

    function getDaysInMonth(year, month) {
        return new Date(year, month, 0).getDate();
    }

    function getDates(startDate, n) {
        var dates = new Array(n);
        var current = startDate, i = 0;
        while (i < n) {
            dates[i++] = new Date(current);
            current.setDate(current.getDate() + 1);
        }
        return dates;
    }
    
    function isSelected(dt) {
        if (dt && angular.isDate($scope.currentDate) && compare(dt, $scope.currentDate) === 0) {
            return true;
        }
        return false;
    }
    
    function isFromDate(dt) {
        if (dt && angular.isDate($scope.fromDate) && compare(dt, $scope.fromDate) === 0) {
            return true;
        }
        return false;
    }

    function isToDate(dt) {
        if (dt && angular.isDate($scope.fromDate) && angular.isDate($scope.currentDate) && compare(dt, $scope.currentDate) === 0) {
            return true;
        }
        return false;
    }

    function isDateRange(dt) {
        if (dt && angular.isDate($scope.fromDate) && angular.isDate($scope.currentDate) && (compare(dt, $scope.fromDate) >= 0) && (compare(dt, $scope.currentDate) <= 0)) {
            return true;
        }
        return false;
    }

    function isWeekend(date) {
        if (dateFilter(date, format.dayHeader) === "Saturday" || dateFilter(date, format.dayHeader) === "Sunday") {
            return true;
        }
        return false;
    }

    function isToday(date) {
        if (compare(date, $scope.resetTime(new Date())) === 0) {
            return true;
        }
        return false;
    }
    
    function isFocused(date) {
        if (date && angular.isDate($scope.focusedDate) && compare(date, $scope.focusedDate) === 0) {
            return true;
        }
        return false;
    }

    var isDisabled = function(date) {
        if (format.disableWeekend === true && (dateFilter(date, format.dayHeader) === "Saturday" || dateFilter(date, format.dayHeader) === "Sunday")) {
            return true;
        }
        if (format.disableSunday === true && (dateFilter(date, format.dayHeader) === "Sunday")) {
            return true;
        }
        return (($scope.minDate && compare(date, $scope.minDate) < 0) || ($scope.maxDate && compare(date, $scope.maxDate) > 0) || (format.disableDates && format.disableDates({date: date})));
    };
    
    var compare = this.compare = function(date1, date2) {
        return (new Date(date1.getFullYear(), date1.getMonth(), date1.getDate()) - new Date(date2.getFullYear(), date2.getMonth(), date2.getDate()));
    };
    
    function isMinDateAvailable(startDate, endDate) {
        if(($scope.minDate && $scope.minDate.getTime() > startDate.getTime()) && ($scope.minDate.getTime() < endDate.getTime())) {
            $scope.disablePrev = true;
        }
        else {
            $scope.disablePrev = false;
        }
    }
    
    function isMaxDateAvailable(startDate, endDate) {
        if(($scope.maxDate && $scope.maxDate.getTime() > startDate.getTime()) && ($scope.maxDate.getTime() < endDate.getTime())) {
            $scope.disableNext = true;
        }
        else {
            $scope.disableNext = false;
        }
    }

    function getLabel(label) {
        if (label)
        {
            var labelObj = {
                pre: label.substr(0, 3),
                post: label
            };
            return labelObj;
        }
        return;
    }

    function makeDate(date, dayFormat, dayHeaderFormat, isFocused, isSelected, isFromDate, isToDate, isDateRange, isOld, isNew, isDisabled, isToday, isWeekend) {
        return {date: date, label: dateFilter(date, dayFormat), header: dateFilter(date, dayHeaderFormat), focused: !!isFocused, selected: !!isSelected, from: !!isFromDate, to: !!isToDate, dateRange: !!isDateRange, oldMonth: !!isOld, nextMonth: !!isNew, disabled: !!isDisabled, today: !!isToday, weekend: !!isWeekend};
    }

    this.modes = [
        {
            name: 'day',
            getVisibleDates: function(date, calendar) {
                var year = date.getFullYear(), month = date.getMonth(), firstDayOfMonth = new Date(year, month, 1);
                var difference = startingDay - firstDayOfMonth.getDay(),
                        numDisplayedFromPreviousMonth = (difference > 0) ? 7 - difference : -difference,
                        firstDate = new Date(firstDayOfMonth), numDates = 0;

                if (numDisplayedFromPreviousMonth > 0) {
                    firstDate.setDate(-numDisplayedFromPreviousMonth + 1);
                    numDates += numDisplayedFromPreviousMonth; // Previous
                }
                numDates += getDaysInMonth(year, month + 1); // Current
                numDates += (7 - numDates % 7) % 7; // Next

                var days = getDates(firstDate, numDates), labels = new Array(7);
                for (var i = 0; i < numDates; i++) {
                    var dt = new Date(days[i]);
                    days[i] = makeDate(dt,
                                format.day,
                                format.dayHeader,
                                isFocused(dt),
                                isSelected(dt),
                                isFromDate(dt),
                                isToDate(dt),
                                isDateRange(dt),
                                (new Date(dt.getFullYear(), dt.getMonth(), 1, 0, 0, 0).getTime() < new Date(year, month, 1, 0, 0, 0).getTime()),
                                (new Date(dt.getFullYear(), dt.getMonth(), 1, 0, 0, 0).getTime() > new Date(year, month, 1, 0, 0, 0).getTime()),
                                isDisabled(dt),
                                isToday(dt),
                                isWeekend(dt));
                }
                for (var j = 0; j < 7; j++) {
                    labels[j] = getLabel(dateFilter(days[j].date, format.dayHeader));
                }
                if (calendar === 'top') {
                    isMinDateAvailable(days[0].date, days[days.length - 1].date);
                } else if (calendar === 'bottom') {
                    isMaxDateAvailable(days[0].date, days[days.length - 1].date);
                } else {
                    isMinDateAvailable(days[0].date, days[days.length - 1].date);
                    isMaxDateAvailable(days[0].date, days[days.length - 1].date);
                }
                return {objects: days, title: dateFilter(date, format.dayTitle), labels: labels};
            },            
            split: 7,
            step: {months: 1}
        }
    ];    
}])

.directive('datepicker', ['$timeout', function ($timeout) {
    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/datepicker/datepicker.html',
        scope: {
            currentDate: "=?current",
            fromDate: "=?from"
        },
        require: 'datepicker',
        controller: 'DatepickerController',
        link: function(scope, element, attrs, ctrl) {
            var datepickerCtrl = ctrl;
            var mode = 0, selected, calendarSelected = false;
            scope.focusedDate;
            
            scope.resetTime = function(date) {
                var dt;
                if (!isNaN(new Date(date))) {
                    dt = new Date(date);
                } else {
                    return null;
                }
                return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
            };

            if (attrs.min) {
                scope.$parent.$watch(attrs.min, function(value) {
                    scope.minDate = value ? scope.resetTime(value) : null;
                    refill();
                });
            }
            if (attrs.max) {
                scope.$parent.$watch(attrs.max, function(value) {
                    scope.maxDate = value ? scope.resetTime(value) : null;
                    refill();
                });
            }
            
            // Split array into smaller arrays
            function split(arr, size) {
                var arrays = [];
                while (arr.length > 0) {
                    arrays.push(arr.splice(0, size));
                }
                return arrays;
            }

            function refill(updateSelected, date) {
                if (date) {
                    if (!angular.isDate(date) || isNaN(date)) {
                        if (updateSelected) {
                            selected = new Date();
                        }
                    } else {
                        if (updateSelected) {
                            selected = new Date(date);
                        }
                    }
                } else if (date === null) {
                    if (updateSelected) {
                        selected = new Date();
                    }
                }

                if (selected) {
                    var currentMode = datepickerCtrl.modes[mode];

                    var currentData = currentMode.getVisibleDates(selected, 'top');
                    scope.currentRows = split(currentData.objects, currentMode.split);
                    scope.currentTitle = currentData.title;
                    scope.labels = currentData.labels || [];

                    var nextData = currentMode.getVisibleDates(moveMonth(angular.copy(selected), 1), 'bottom');
                    scope.nextRows = split(nextData.objects, currentMode.split);
                    scope.nextTitle = nextData.title;
                }
            }
        
            scope.select = function(date) {
                calendarSelected = true;
                if(attrs.from) {
                    if(!(angular.isDate(scope.fromDate) && angular.isDate(scope.currentDate))) {
                        if(angular.isDate(scope.fromDate)) {
                            selectCurrentDate(date);
                        } else if(!angular.isDate(scope.fromDate)) {
                            selectFromDate(date);
                        }
                    }
                } else {
                    selectCurrentDate(date);
                }
                scope.focusedDate = date;
            };
            
            var selectCurrentDate = function(date) {
                var dt = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                scope.currentDate = dt;
            };
            
            var selectFromDate = function(date) {
                var dt = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                scope.fromDate = dt;
            };

            var swapDate = function(fromDate, currentDate) {
                selectCurrentDate(fromDate);
                $timeout(function () {
                    calendarSelected = true;
                    selectFromDate(currentDate);
                });
            }

            var moveMonth = function(selectedDate, direction) {
                var step = datepickerCtrl.modes[mode].step;
                selectedDate.setDate(1);
                selectedDate.setMonth(selectedDate.getMonth() + direction * (step.months || 0));
                selectedDate.setFullYear(selectedDate.getFullYear() + direction * (step.years || 0));

                return selectedDate;
            };

            scope.move = function(direction) {
                selected = moveMonth(angular.copy(selected), direction);
                refill();
            };

            scope.$watch('currentDate', function (value) {
                if (attrs.from) {
                    if (!isNaN(value) && !isNaN(scope.fromDate) && datepickerCtrl.compare(value, scope.fromDate) < 0) {
                        swapDate(scope.fromDate, value);
                        return;
                    }
                }
                if (calendarSelected) {
                    refill();
                    calendarSelected = false;
                } else {
                    if (angular.isDefined(value) && value !== null) {
                        refill(true, value);
                    } else {
                        scope.focusedDate = undefined;
                        refill(true, null);
                    }
                }
            });

            scope.$watch('fromDate', function (value) {
                if (attrs.from) {
                    if (!isNaN(scope.currentDate) && !isNaN(value) && datepickerCtrl.compare(scope.currentDate, value) < 0) {
                        swapDate(value, scope.currentDate);
                        return;
                    }
                    if (calendarSelected) {
                        refill();
                        calendarSelected = false;
                    } else {
                        if (angular.isDefined(value) && value !== null) {
                            refill(true, value);
                        } else {
                            scope.focusedDate = undefined;
                            refill(true, null);
                        }
                    }
                }
            });
        }
    };
}])

.directive('datepickerPopup', ['$document', 'datepickerService', '$isElement', '$documentBind', function($document, datepickerService, $isElement, $documentBind) {
    var link = function (scope, elem, attr, ctrl) {
        datepickerService.bindScope(attr, scope);

        scope.isOpen = false;

        var toggle = scope.toggle = function (show) {
            if(show === true || show === false) {
                scope.isOpen = show;
            } else {
                scope.isOpen = !scope.isOpen;
            }
        };

        scope.$watch('current', function () {
            toggle(false);
        });

        var outsideClick = function (e) {
            var isElement = $isElement(angular.element(e.target), elem, $document);
            if(!isElement) {
                toggle(false);
                scope.$apply();
            }
        };

        $documentBind.click('isOpen', outsideClick, scope);
    };

    return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/datepicker/datepickerPopup.html',
        scope: {
            current: "=current"
        },
        compile: function (elem, attr) {
            var wrapperElement = elem.find('span').eq(1);
            wrapperElement.attr('current', 'current');
            datepickerService.setAttributes(attr, wrapperElement);

            return link;
        }
    };
}])

.directive('attDatepicker', ['$log', function($log) {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {},
        controller: ['$scope', '$element', '$attrs', '$compile', 'datepickerConfig', 'datepickerService', function($scope, $element, $attrs, $compile, datepickerConfig, datepickerService) {
            var dateFormatString = angular.isDefined($attrs.dateFormat) ? $scope.$parent.$eval($attrs.dateFormat) : datepickerConfig.dateFormat;
            var selectedDateMessage = '<div class="sr-focus hidden-spoken" tabindex="-1">the date you selected is {{$parent.current | date : \'' + dateFormatString + '\'}}</div>';

            $element.removeAttr('att-datepicker');
            $element.removeAttr('ng-model');
            $element.attr('ng-model', '$parent.current');
            $element.attr('aria-describedby', 'datepicker');
            $element.attr('format-date', dateFormatString);
            $element.attr('att-input-deny', '[^0-9\/-]');
            $element.attr('maxlength', 10);

            var wrapperElement = angular.element('<div></div>');
            wrapperElement.attr('datepicker-popup', '');
            wrapperElement.attr('current', 'current');
            
            datepickerService.setAttributes($attrs, wrapperElement);
            datepickerService.bindScope($attrs, $scope);
            
            wrapperElement.html('');
            wrapperElement.append($element.prop('outerHTML'));
            if (navigator.userAgent.match(/MSIE 8/) === null) {
                wrapperElement.append(selectedDateMessage);
            }
            var elm = wrapperElement.prop('outerHTML');
            elm = $compile(elm)($scope);
            $element.replaceWith(elm);
        }],
        link: function(scope, elem, attr, ctrl) {
            if (!ctrl) {
                $log.error("ng-model is required.");
                return; // do nothing if no ng-model
            }

            scope.$watch('current', function(value) {
                ctrl.$setViewValue(value);
            });
            ctrl.$render = function() {
                scope.current = ctrl.$viewValue;
            };
        }
    };
}])

.directive('formatDate', ['dateFilter', 'datepickerService', function(dateFilter, datepickerService) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function(scope, elem, attr, ctrl) {
            var formatDate = "";
            attr.$observe('formatDate', function (value) {
                formatDate = value;
            });
            var dateToString = function(value) {
                return dateFilter(value, formatDate);
            };
            var stringToDate = function(value) {
                if(datepickerService.validateDateString(value, formatDate)) {
                    ctrl.$setValidity('invalidDate', true);
                    return new Date(value);
                } else {
                    ctrl.$setValidity('invalidDate', false);
                    return null;
                }
            };
            ctrl.$formatters.unshift(dateToString);
            ctrl.$parsers.unshift(stringToDate);
        }
    };
}])

.directive('attDateFilter', ['$document', 'dateFilter', 'datepickerConfig', 'datepickerService', '$isElement', '$documentBind', function($document, dateFilter, datepickerConfig, datepickerService, $isElement, $documentBind) {
    var link = function (scope, elem, attr, ctrl) {
        datepickerService.bindScope(attr, scope);

        scope.selectedOption = datepickerConfig.dateFilter.defaultText;
        scope.showDropdownList = false;
        scope.showCalendar = false;
        scope.applyButtonType = "disabled";

        var currentSelection = "";
        var dateFormatString = angular.isDefined(attr.dateFormat) ? scope.$parent.$eval(attr.dateFormat) : datepickerConfig.dateFormat;
        var inputChange = false;

        var dateRange = {
            from: undefined,
            current: undefined
        };

        var showDropdown = scope.showDropdown = function (show) {
            if(show === true || show === false) {
                scope.showDropdownList = show;
            } else {
                scope.showDropdownList = !scope.showDropdownList;
            }

            if (!scope.showDropdownList) {
                hideCalendar();
            } else {
                if (currentSelection === 'Custom Single Date' || currentSelection === 'Custom Range') {
                    showCalendar();
                }
            }
        };

        var resetTime = function(date) {
            var dt;
            if (!isNaN(new Date(date))) {
                dt = new Date(date);
            } else {
                return null;
            }
            return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
        };

        var addDays = function (date, days) {
            var dt;
            if (!isNaN(new Date(date)) && !isNaN(days)) {
                dt = new Date(date);
                dt.setDate(dt.getDate() + days);
            } else {
                dt = new Date();
            }
            return dt;
        };

        scope.selectOption = function (value, index) {
            scope.selectedOption = value;
            currentSelection = value;
            scope.current = resetTime(new Date());
            dateRange.current = resetTime(new Date());
            switch (index) {
                case 0:
                    scope.from = undefined;
                    dateRange.from = undefined;
                    break;
                case 1:
                    scope.from = resetTime(addDays(new Date(), -7));
                    dateRange.from = resetTime(addDays(new Date(), -7));
                    break;
                case 2:
                    scope.from = resetTime(addDays(new Date(), -15));
                    dateRange.from = resetTime(addDays(new Date(), -15));
                    break;
                case 3:
                    scope.from = resetTime(addDays(new Date(), -30));
                    dateRange.from = resetTime(addDays(new Date(), -30));
                    break;
            }
            showDropdown();
        };

        scope.checkCurrentSelection = function(value) {
            if(value === currentSelection) {
                return true;
            }
            return false;
        };

        var showCalendar = function() {
            scope.showCalendar = true;
        };

        var hideCalendar = function() {
            scope.showCalendar = false;
            if(currentSelection !== 'Custom Single Date' && currentSelection !== 'Custom Range') {
                clear(true);
            }
        };

        var setDropdownText = function(value) {
            if(inputChange) {
                return;
            }

            var fromDateText = dateFormatString.toUpperCase();
            var currentDateText = dateFormatString.toUpperCase();

            if(!isNaN(new Date(scope.fromDate))) {
                fromDateText = dateFilter(scope.fromDate, dateFormatString);
            }
            if(!isNaN(new Date(scope.currentDate))) {
                currentDateText = dateFilter(scope.currentDate, dateFormatString);
            }

            if(value === 'Custom Single Date') {
                scope.maxLength = 10;
                scope.selectedOption = currentDateText;
            } else if(value === 'Custom Range') {
                scope.maxLength = 21;
                scope.selectedOption = fromDateText + '-' + currentDateText;
            }
        };

        scope.getDropdownText = function () {
            inputChange = true;
            var dropdownText = scope.selectedOption;

            if (currentSelection === 'Custom Single Date') {
                if (!isNaN(new Date(dropdownText)) && datepickerService.validateDateString(dropdownText, dateFormatString)) {
                    ctrl.$setValidity('invalidDate', true);
                    scope.fromDate = undefined;
                    scope.currentDate = new Date(dropdownText);
                } else {
                    ctrl.$setValidity('invalidDate', false);
                    clear(true);
                }
            } else if (currentSelection === 'Custom Range') {
                if (dropdownText.indexOf('-') !== -1 && (dropdownText.split('-').length === 2 || dropdownText.split('-').length === 6)) {
                    ctrl.$setValidity('invalidDateRange', true);
                    var resultDropdownText = dropdownText.split('-');
                    if (resultDropdownText.length === 2) {
                        resultDropdownText[0] = resultDropdownText[0].trim();
                        resultDropdownText[1] = resultDropdownText[1].trim();
                    } else if (resultDropdownText.length === 6) {
                        var firstDateString = resultDropdownText[0].trim() + '-' + resultDropdownText[1].trim() + '-' + resultDropdownText[2].trim();
                        var secondDateString = resultDropdownText[3].trim() + '-' + resultDropdownText[4].trim() + '-' + resultDropdownText[5].trim();
                        resultDropdownText[0] = firstDateString;
                        resultDropdownText[1] = secondDateString;
                    }

                    if (!isNaN(new Date(resultDropdownText[0])) && !isNaN(new Date(resultDropdownText[1])) && datepickerService.validateDateString(resultDropdownText[0], dateFormatString) && datepickerService.validateDateString(resultDropdownText[1], dateFormatString)) {
                        ctrl.$setValidity('invalidDate', true);
                        var fromDate = new Date(resultDropdownText[0]);
                        var currentDate = new Date(resultDropdownText[1]);
                        if(fromDate.getTime() < currentDate.getTime()) {
                            ctrl.$setValidity('invalidDateRange', true);
                            scope.fromDate = fromDate;
                            scope.currentDate = currentDate;
                        } else {
                            ctrl.$setValidity('invalidDateRange', false);
                            clear(true);
                        }
                    } else {
                        ctrl.$setValidity('invalidDate', false);
                        clear(true);
                    }
                } else {
                    ctrl.$setValidity('invalidDateRange', false);
                    clear(true);
                }
            }
        };

        elem.find('input').bind('blur', function(ev) {
            inputChange = false;
        });

        scope.selectAdvancedOption = function (value) {
            currentSelection = value;
            showCalendar();
            clear();
            scope.$watch('currentDate', function(val) {
                if(!isNaN(new Date(val))) {
                    scope.applyButtonType = "primary";
                    setDropdownText(value);
                }
            });
            scope.$watch('fromDate', function(val) {
                if(!isNaN(new Date(val))) {
                    scope.applyButtonType = "primary";
                    setDropdownText(value);
                }
            });
        };

        scope.apply = function() {
            if(!isNaN(new Date(scope.fromDate))) {
                scope.from = scope.fromDate;
                dateRange.from = scope.fromDate;
            } else {
                scope.from = undefined;
                dateRange.from = undefined;
            }
            if(!isNaN(new Date(scope.currentDate))) {
                scope.current = scope.currentDate;
                dateRange.current = scope.currentDate;
            } else {
                scope.current = undefined;
                dateRange.current = undefined;
            }

            showDropdown();
        };

        scope.$watchCollection(function() {
            return dateRange;
        }, function(value) {
            if(ctrl) {
                var finalDateRange = angular.copy(value);
                ctrl.$setViewValue(finalDateRange);
            }
        })

        scope.cancel = function() {
            currentSelection = "";
            scope.selectedOption = datepickerConfig.dateFilter.defaultText;
            showDropdown();
        };

        var clear = scope.clear = function(partial) {
            scope.fromDate = undefined;
            scope.currentDate = undefined;
            scope.applyButtonType = "disabled";
            if(!partial) {
                ctrl.$setValidity('invalidDate', true);
                ctrl.$setValidity('invalidDateRange', true);
                setDropdownText(currentSelection);
            }
        };

        var outsideClick = function (e) {
            var isElement = $isElement(angular.element(e.target), elem, $document);
            if(!isElement) {
                showDropdown(false);
                scope.$apply();
            }
        };

        $documentBind.click('showDropdownList', outsideClick, scope);
    };

    return {
        restrict: 'EA',
        scope: {
            from: '=from',
            current: "=current"
        },
        replace: true,
        require: '?ngModel',
        templateUrl: 'app/scripts/ng_js_att_tpls/datepicker/dateFilter.html',
        compile: function(elem, attr) {
            var singleDateCalendar = elem.find('span').eq(4);
            var rangeCalendar = elem.find('span').eq(5);
            rangeCalendar.attr('from', 'fromDate');
            singleDateCalendar.attr('current', 'currentDate');
            rangeCalendar.attr('current', 'currentDate');

            datepickerService.setAttributes(attr, singleDateCalendar);
            datepickerService.setAttributes(attr, rangeCalendar);

            return link;
        }
    };
}]);

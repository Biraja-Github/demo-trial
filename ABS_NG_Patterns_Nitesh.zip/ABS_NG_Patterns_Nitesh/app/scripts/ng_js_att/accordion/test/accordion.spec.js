describe('att.abs.accordion', function () {
  var $scope;

  beforeEach(module('att.abs.accordion'));
  beforeEach(inject(function ($rootScope) {
    $scope = $rootScope;
  }));

  describe('controller', function () {

    var ctrl, $element, $attrs;
    beforeEach(inject(function($controller) {
      $attrs = {}; $element = {};
      ctrl = $controller('AbsAccordionCtrl', { $scope: $scope, $element: $element, $attrs: $attrs });
    }));

//    describe('addGroup', function() {
//      it('adds a the specified group to the collection', function() {
//        var group1, group2;
//        ctrl.addGroup(group1 = $scope.$new());
//        ctrl.addGroup(group2 = $scope.$new());
//        expect(ctrl.groups.length).toBe(2);
//        expect(ctrl.groups[0]).toBe(group1);
//        expect(ctrl.groups[1]).toBe(group2);
//      });
//    });

    describe('closeOthers', function() {
      var group1, group2, group3;
      beforeEach(function() {
        //ctrl.addGroup(group1 = { isOpen: true, $on : angular.noop });
        //ctrl.addGroup(group2 = { isOpen: true, $on : angular.noop });
        //ctrl.addGroup(group3 = { isOpen: true, $on : angular.noop });
      });
      it('should NOT close other groups if close-others attribute is not defined', function() {
        delete $attrs.closeOthers;
        ctrl.closeOthers(group2);
        expect(group1.isOpen).toBe(true);
        expect(group2.isOpen).toBe(true);
        expect(group3.isOpen).toBe(true);
      });

      it('should close other groups if close-others attribute is true', function() {
        $attrs.closeOthers = 'true';
        ctrl.closeOthers(group3);
        expect(group1.isOpen).toBe(false);
        expect(group2.isOpen).toBe(false);
        expect(group3.isOpen).toBe(true);
      });

      it('should not close other groups if close-others attribute is false', function() {
        $attrs.closeOthers = 'false';
        ctrl.closeOthers(group2);
        expect(group1.isOpen).toBe(true);
        expect(group2.isOpen).toBe(true);
        expect(group3.isOpen).toBe(true);
      });

      describe('setting accordionConfig', function() {
        var originalCloseOthers;
        beforeEach(inject(function(accordionConfig) {
          originalCloseOthers = accordionConfig.closeOthers;
          accordionConfig.closeOthers = false;
        }));
        afterEach(inject(function(accordionConfig) {
          // return it to the original value
          accordionConfig.closeOthers = originalCloseOthers;
        }));

        it('should not close other groups if accordionConfig.closeOthers is false', function() {
          ctrl.closeOthers(group2);
          expect(group1.isOpen).toBe(true);
          expect(group2.isOpen).toBe(true);
          expect(group3.isOpen).toBe(true);
        });
      });
    });

    describe('removeGroup', function() {
      it('should remove the specified group', function () {
        var group1, group2, group3;
        ctrl.addGroup(group1 = $scope.$new());
        ctrl.addGroup(group2 = $scope.$new());
        ctrl.addGroup(group3 = $scope.$new());
        ctrl.removeGroup(group2);
        expect(ctrl.groups.length).toBe(2);
        expect(ctrl.groups[0]).toBe(group1);
        expect(ctrl.groups[1]).toBe(group3);
      });
      it('should ignore remove of non-existing group', function () {
        var group1, group2;
        ctrl.addGroup(group1 = $scope.$new());
        ctrl.addGroup(group2 = $scope.$new());
        expect(ctrl.groups.length).toBe(2);
        ctrl.removeGroup({});
        expect(ctrl.groups.length).toBe(2);
      });
    });
	
    describe('accordion-group', function () {
        var scope, $compile;
        var element, groups;
        var findGroupLink = function (index) {
          return groups.eq(index).find('.accordion-heading').eq(0);
        };
        var findGroupBody = function (index) {
          return groups.eq(index).find('.accordion-body').eq(0);
        };

        beforeEach(inject(function(_$rootScope_, _$compile_) {
          scope = _$rootScope_;
          $compile = _$compile_;
        }));

        afterEach(function () {
          element = groups = scope = $compile = undefined;
        });

        describe('with open and disabled groups', function () {
          beforeEach(function () {
            var tpl =
              '<accordion>' +
                '<accordion-group heading="title 1" is-open="params.oneOpen" is-disabled="params.oneDisabled">Content 1</accordion-group>' +
                '<accordion-group heading="title 2" is-open="params.twoOpen" is-disabled="params.twoDisabled">Content 2</accordion-group>' +
                '<accordion-group heading="title 3" is-open="params.threeOpen" is-disabled="params.threeDisabled">Content 3</accordion-group>' +
                '<accordion-group heading="title 4" is-open="params.fourOpen" is-disabled="params.fourDisabled">Content 4</accordion-group>' +
                '</accordion>';
            element = angular.element(tpl);
            scope.params = { oneOpen: false, twoOpen: true, threeOpen: false, fourOpen: true, oneDisabled: false, twoDisabled: false, threeDisabled: true, fourDisabled: true };
            $compile(element)(scope);
            scope.$digest();
            groups = element.find('.accordion-group');
          });
          afterEach(function() {
            element.remove();
          });
    
           it('Click should not change open state of disabled group', function() {
             findGroupLink(0).click();
             scope.$digest();
             expect(findGroupBody(0).scope().isOpen).toBe(true);
             findGroupLink(1).click();
             scope.$digest();
             expect(findGroupBody(1).scope().isOpen).toBe(false);
             findGroupLink(2).click();
             scope.$digest();
             expect(findGroupBody(2).scope().isOpen).toBe(false);
             findGroupLink(3).click();
             scope.$digest();
             expect(findGroupBody(3).scope().isOpen).toBe(true);
           });
  
        });
	});
  });

});

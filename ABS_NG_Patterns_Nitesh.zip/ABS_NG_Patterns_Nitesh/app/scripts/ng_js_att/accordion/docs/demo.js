var AbsAccordionCtrl = function($scope){    
    $scope.oneAtATime = true;
    $scope.groups = [
        {
            title: "Accordion Item #1",
            content:"Unit test me bro! Proin eu quam malesuada, accumsan velit eu, tristique orci. Donec neque nisl, dignissim ut hendrerit sit amet, tempor id erat. Donec fermentum commodo semper. Sed lectus odio, egestas non volutpat eu, venenatis eu turpis. Donec eget fringilla lorem. Fusce sit amet semper velit. ",
            open: false
        },
        {
            title: "Accordion Item #2",
            content: "Lint me too! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        },
        {
            title: "Accordion Item #3",
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        }
    ];
    
    $scope.groups2 = [
        {
            title: "Accordion Item #1",
            content:"Unit test me bro! Proin eu quam malesuada, accumsan velit eu, tristique orci. Donec neque nisl, dignissim ut hendrerit sit amet, tempor id erat. Donec fermentum commodo semper. Sed lectus odio, egestas non volutpat eu, venenatis eu turpis. Donec eget fringilla lorem. Fusce sit amet semper velit. ",
            open: false
        },
        {
            title: "Accordion Item #2",
            content: "Lint me too! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        },
        {
            title: "Accordion Item #3",
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        }
    ];
    

    $scope.groups3 = [
        {
            title: "Accordion Item #1",
            content:"Unit test me bro! Proin eu quam malesuada, accumsan velit eu, tristique orci. Donec neque nisl, dignissim ut hendrerit sit amet, tempor id erat. Donec fermentum commodo semper. Sed lectus odio, egestas non volutpat eu, venenatis eu turpis. Donec eget fringilla lorem. Fusce sit amet semper velit. ",
            open: false
        },
        {
            title: "Accordion Item #2",
            content: "Lint me too! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        },
        {
            title: "Accordion Item #3",
            content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi eleifend aliquam eros quis fringilla. Integer eu justo turpis. Nam mauris augue, posuere interdum dignissim sed, tempor sit amet neque. In nec tortor id nibh sollicitudin aliquam sit amet ac augue",
            open: false
        }
    ];
    
    $scope.checkboxGroup1 = 
        {     
            "A":false,
            "B":false,
            "C":false     
        };
    $scope.checkboxGroup2 =
        {
             "D":false,
             "E":false   
        };
    $scope.expandCollapse =
        {
             "expandAll":false,
             "collapseAll":false   
        };
    $scope.expandAll = function()
        {
             $scope.expandCollapse.expandAll=true;
        };
    $scope.collapseAll = function()
        {
             $scope.expandCollapse.collapseAll=true;
        };      
};

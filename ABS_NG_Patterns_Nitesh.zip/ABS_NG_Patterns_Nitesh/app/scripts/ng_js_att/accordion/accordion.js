angular.module('att.abs.accordion', ['att.abs.position','att.abs.transition'])
.constant('accordionConfig', {
    closeOthers: false
})

.controller('AccordionController',['$scope', '$attrs', 'accordionConfig', '$log',
    function($scope, $attrs, accordionConfig, $log) {
    // This array keeps track of the accordion groups
    this.groups = [];
    this.index = -1;

    // Keep reference to user's scope to properly assign `is-open`
    this.scope = $scope;
    $scope.forceExpand=false;
    // Ensure that all the groups in this accordion are closed, unless close-others explicitly says not to
     this.closeOthers = function(openGroup) {
        var closeOthers = angular.isDefined($attrs.closeOthers) ? $scope.$eval($attrs.closeOthers) : accordionConfig.closeOthers;
        if(closeOthers && !$scope.forceExpand) {
            angular.forEach(this.groups, function(group) {                
                if (group !== openGroup) {
                        group.isOpen=false;
                }
            });       
        }
        if(this.groups.indexOf(openGroup)===(this.groups.length-1) && $scope.forceExpand){
            $scope.forceExpand=false;
        }
    };
    
    this.expandAll = function() {
        $scope.forceExpand=true; 
        angular.forEach(this.groups, function(group) {                               
            group.isOpen = true;
        });
    };
    
    this.collapseAll = function() {
        angular.forEach(this.groups, function(group) {                                
            group.isOpen = false;                                
        });
    };
    /**
     *
     * function focus
     * @param focusGroup
     */
    this.focus = function(focusGroup) {
        var self = this;
        $log.log("entering focus");
        angular.forEach(this.groups, function(group, index) {
            if (group !== focusGroup) {
                group.focused = false;
            } else {
                self.index = index;
                group.focused = true;
            }
        });
    };
    /**
     *
     * @param blurGroup
     */
    this.blur = function(blurGroup) {
        blurGroup.focused = false;
        this.index = -1;
        $log.log("accordion.blur()", blurGroup);
    };
    /**
     *
     * @param group - the group in current focus
     * @param down - cycling down
     */
    this.cycle = function(group, down, noRecycle) {
        if (!down) {
            if (this.index <= 0 && !noRecycle) {
                this.index = this.groups.length - 1;
            } else {
                this.index--;
            }
        } else {
            if (this.index >= (this.groups.length - 1) && !noRecycle) {
                this.index = 0;
            } else {
                this.index++;
            }
        }
        group.focused = false;
        this.groups[this.index].focused = true;
        $log.log("accordion.cycle()", group, down);
        $log.log("group unfocused", group);
        $log.log("group focused", this.groups[this.index]);
        $scope.$apply();
    };

    // This is called from the accordion-group directive to add itself to the accordion
    this.addGroup = function(groupScope) {
        var that = this;
        groupScope.index = this.groups.length;
        groupScope.focused = false;
        this.groups.push(groupScope);

        groupScope.$on('$destroy', function(event) {
            that.removeGroup(groupScope);
        });
    };

    // This is called from the accordion-group directive when to remove itself
    this.removeGroup = function(group) {
        var index = this.groups.indexOf(group);
        if (index !== -1) {
            this.groups.splice(this.groups.indexOf(group), 1);
        }
    };

}])

// The accordion directive simply sets up the directive controller
// and adds an accordion CSS class to itself element.
.directive('accordion', function() {
    return {
        restrict: 'EA',
        controller: 'AccordionController',
        transclude: true,
        replace: false,
        scope: {
            cClass: '@css',
            expandAll:"=?",
            collapseAll:"=?"
        },
        template: '<div class="{{cClass}}" ng-transclude></div>',
        link:function(scope,elem,attribute,ctrl)  {
            
            scope.$watch("expandAll", function(value) {
                if (value===true) {
                     ctrl.expandAll();
                     scope.expandAll=false;
                }
            });
             scope.$watch("collapseAll", function(value) {
                if (value===true) {
                     ctrl.collapseAll();
                     scope.collapseAll = false;
                }
            });
        }   
    };
})

// The accordion-group directive indicates a block of html that will expand and collapse in an accordion
.directive('accordionGroup', ['$parse', '$transition', '$scrollTo', '$timeout', '$log', '$position', '$window', function($parse, $transition, $scrollTo, $timeout, $log, $position, $window) {
    return {
        require: ['^accordion', 'accordionGroup'], // We need this directive to be inside an accordion
        restrict: 'EA',
        transclude: true, // It transcludes the contents of the directive into the template
        replace: true, // The element containing the directive will be replaced with the template
        templateUrl:'app/scripts/ng_js_att_tpls/accordion/accordion.html',
        //templateUrl:'app/scripts/ng_js_att_tpls/accordion/accordion_alt.html',
        
        scope: {
            heading: '@',
            isOpen: '=?'
        }, // Create an isolated scope and interpolate the heading attribute onto this scope
        controller:['$scope', function($scope)
        {
            $scope.showico = true;
            this.setHeading = function(element)
            {
                this.heading = element;
                $scope.showico = false;
            };                                   
            this.isIsOpen = function()
            {
                return $scope.isOpen;
            };
        }],
        link: function(scope, element, attrs, ctrl) {
            var accordionCtrl = ctrl[0];
            var accordionGroupCtrl = ctrl[1];
            var keys = {tab: 9, enter: 13, esc: 27, space: 32, pageup: 33, pagedown: 34, end: 35, home: 36, left: 37, up: 38, right: 39, down: 40};

            //not a fix
            var tab = element.children().eq(0);
            var panel = element.children().eq(1);

            var handleKeydown = function(ev) {
                $log.log("Enter handleKeydown on: ", ev);
                var boolFlag = true;
                switch (ev.keyCode)
                {
                    case keys.space:
                        ev.preventDefault();
                        scope.toggle();
                        scope.$apply();
                        break;
                        //return true;
                    case keys.up:
                    case keys.left:
                        $log.log("cycle up");
                        accordionCtrl.cycle(scope, false);
                        break;
                        //return true;
                    case keys.down:
                    case keys.right:
                        $log.log("cycle down");
                        accordionCtrl.cycle(scope, true);
                        break;
                        //return true;
                    case keys.tab:
                        accordionCtrl.cycle(scope, true, true);
                        break;
                    default:
                        boolFlag = false;
                        break;
                        //return false;
                }
                ev.stopPropagation();
                return boolFlag;
            };

            var swallowKeypress = function(e) {
                $log.log("keypress", e);
                if (e.altKey) {
                    // do nothing
                    return true;
                }
                var boolFlag = true;
                switch (e.keyCode)
                {
                    case keys.enter:
                    case keys.space:
                    case keys.left:
                    case keys.up:
                    case keys.right:
                    case keys.down:
                    case keys.home:
                    case keys.end:
                        e.stopPropagation();
                        boolFlag = false;
                        break;
                        //return false;
                    case keys.pageup:
                    case keys.pagedown:
                        // The tab keypress handler must consume pageup and pagedown
                        // keypresses to prevent Firefox from switching tabs
                        // on ctrl+pageup and ctrl+pagedown
                        if (!e.ctrlKey)
                        {
                            boolFlag = true;
                            break;
                            //return true;
                        }
                        e.stopPropagation();
                        boolFlag = false;
                        break;
                        //return false;
                    default:
                        break;
                }
                return boolFlag;
                //return true;
            };
            
            if(angular.isUndefined(scope.isOpen)) {
                scope.isOpen = false;
            }

            panel.bind("keypress", swallowKeypress);
            tab.bind("keydown", handleKeydown);


            tab.bind("focus", function(ev) {
                tab.attr("tabindex", "0");
            });

            tab.bind("blur", function(ev) {
                if (scope.index !== 0) {
                    tab.attr("tabindex", "-1");
                }
            });

            accordionCtrl.addGroup(scope);

            if (scope.index === 0) {
                tab.attr("tabindex", "0");
            }

            accordionGroupCtrl.toggle = scope.toggle = function() {
                scope.isOpen = !scope.isOpen;
                accordionCtrl.focus(scope);
                if (scope.isOpen === true) {
                    if (navigator.userAgent.match(/MSIE 8/) === null) {
                       // $scrollTo(0, $position.offset(element).top, 0.5);
                    }
                } 
                return scope.isOpen;
            };
            
            scope.$watch('isOpen', function(value) {
                if (value) {
                    accordionCtrl.closeOthers(scope);
                }
            });

            scope.$watch("focused", function(value) {
                if (!!value) {
                    $timeout(function() {
                        tab.attr("tabindex", "0");
                        tab[0].focus();
                    }, 0);
                }
            });
        }
    };
}])
// Use accordion-heading below an accordion-group to provide a heading containing HTML
// <accordion-group>
//   <accordion-heading>Heading containing HTML - <img src="..."></accordion-heading>
// </accordion-group>
//accordionToggle
.directive('accordionToggle',function(){
    return{
        restrict: 'EA',
        require: '^accordionGroup',
        scope:{
            expandIcon:'@',
            collapseIcon:'@'
        },
        link: function(scope, element, attr, accordionCtrl)
        {      
            var isOpen=accordionCtrl.isIsOpen();
                       
            var setIcon = function(){                                            
                if(scope.expandIcon && scope.collapseIcon)
                {
                    if(isOpen) {
                        element.removeClass(scope.expandIcon);
                        element.addClass(scope.collapseIcon);
                    }
                    else {
                        element.removeClass(scope.collapseIcon);
                        element.addClass(scope.expandIcon);
                        
                    }                                    
                }
            };                       
            element.bind('click', function() 
            {                
                 isOpen = accordionCtrl.toggle();
                 setIcon();
            });
            setIcon(); 
        }                
    };   
})

.directive('accordionHeading', function() {
    return {
        restrict: 'EA',
        transclude: true, // Grab the contents to be used as the heading
        template: '', // In effect remove this element!
        //replace: true,
        require: '^accordionGroup',        
        compile: function(element, attr, transclude) {
            return function link(scope, element, attr, accordionGroupCtrl) {
                // Pass the heading to the accordion-group controller
                // so that it can be transcluded into the right place in the template
                // [The second parameter to transclude causes the elements to be cloned so that they work in ng-repeat]                
                transclude(scope, function(clone) {
                    element.append(clone);
                    accordionGroupCtrl.setHeading(element);
                    //angular.element(document.querySelector(["toggleMe"]))
                    $(".toggleMe").on("click", function() 
                    {                        
                        accordionGroupCtrl.toggle(); 
                    });                    
                });                
            };
        }

//        compile: function(element, attr, transclude) {
//            return function link(scope, element, attr, accordionGroupCtrl) {
//                // Pass the heading to the accordion-group controller
//                // so that it can be transcluded into the right place in the template
//                // [The second parameter to transclude causes the elements to be cloned so that they work in ng-repeat]
//                accordionGroupCtrl.setHeading(transclude(scope, function() {
//                }));
//            };
//        }        
    };
})

// Use in the accordion-group template to indicate where you want the heading to be transcluded
// You must provide the property on the accordion-group controller that will hold the transcluded element
// <div class="accordion-group">
//   <div class="accordion-heading" ><a ... accordion-transclude="heading">...</a></div>
//   ...
// </div>
.directive('accordionTransclude', function() {
    return {
        require: '^accordionGroup',
        link: function(scope, element, attr, controller) {
            scope.$watch(function() {
                return controller[attr.accordionTransclude];
            }, function(heading) {
                if (heading) {
                    element.find("span").html('');
                    element.find("span").append(heading);
                }
            });
        }
    };
})

.directive('attGoTop',['$scrollTo', function($scrollTo){    
    return {
      restrict: 'A',        
      transclude: false,                   
      link: function (scope, elem, attrs) 
      {         
          elem.bind('click', function() 
          {
             $scrollTo(0,attrs["attGoTop"]);
          });
      }    
};
}])

.directive('attGoTo',['$anchorScroll','$location', function($anchorScroll, $location){    
    return {
      restrict: 'A',        
      transclude: false,                   
      link: function (scope, elem, attrs) 
      {         
          elem.bind('click', function() 
          {                
                var newHash = attrs["attGoTo"];
                if ($location.hash() !== newHash) 
                {
                    $location.hash(attrs["attGoTo"]);
                }
                else 
                {
                    $anchorScroll();
                }
          });
      }    
};}])

.directive('freeStanding',function(){    
    return {
      restrict: 'E',        
      transclude: true,                   
      replace:true,
      scope:true,
      template: "<div><span style='display:block;min-height:50px' ng-show='showAccordion'></span>\n" +                         
            "<div class='section-toggle'>\n" +
            "<button class='section-toggle__button'>\n" + 
            "    {{btnText}}<i style='font-size:0.875rem' ng-class='{\"icon-chevron-up\": showAccordion,\"icon-chevron-down\": !showAccordion, }'></i> \n" +
            "</button>\n" + 
            "</div></div>",       
        compile: function(element, attr, transclude) 
        {
            return function link(scope, elem, attrs) 
            {                
                scope.content = "";
                transclude(scope, function(clone) 
                {
                    elem.find("span").append(clone);                                        
                });           
                scope.showAccordion = false;
                scope.btnText = scope.showAccordion? attrs.hideMsg:attrs.showMsg;          
                elem.bind('click', function() 
                {                
                  scope.showAccordion = !scope.showAccordion;              
                  scope.btnText = scope.showAccordion? attrs.hideMsg:attrs.showMsg;
                  console.log("Free Standing");
                });                                
            };
        }
       
};
})

.directive('expanders',function(){
    
    return{
        restrict:'E',
        replace:true,
        transclude:true,        
        template:"<div ng-transclude></div>",
        
        controller: ['$scope',function($scope){
               
           var bodyScope = null;
           this.setScope = function(scope){               
               bodyScope = scope;               
           };
           
           this.toggle = function(){             
               bodyScope.isOpen = !bodyScope.isOpen;
               return bodyScope.isOpen;
           };
                
        }],
        
        link: function(scope, element, attrs, accordionCtrl)
        {           
            scope.isOpen = false;
            element.bind('click', function() 
            {
                scope.isOpen = !scope.isOpen; 
            });
        }         
    };
    
})

.directive('expanderHeading',function(){
   
    return{
        require:"^expanders",
        restrict:'E',
        replace:true,
        transclude:true,
        scope:true,
        template: "<div style='padding:10px !important' ng-transclude></div>"
    };
    
})

.directive('expanderBody',function(){
   
    return{
        restrict:'E',
        require:"^expanders",
        replace:true,
        transclude:true,
        scope:{},
        template: "<div collapse='!isOpen'><div ng-transclude></div></div>",        
        link:function(scope, elem, attr, myCtrl){            
          scope.isOpen = false; 
          myCtrl.setScope(scope);
        }   
};
})

.directive('expanderToggle',function(){
   
   return{
        restrict: 'EA',
        require:"^expanders",
        scope:{
            expandIcon:'@',
            collapseIcon:'@'
        },
        link: function(scope, element, attr, myCtrl)
        {      
            var isOpen=false;
                       
            var setIcon = function(){                                            
                if(scope.expandIcon && scope.collapseIcon)
                {
                    if(isOpen) {
                        element.removeClass(scope.expandIcon);
                        element.addClass(scope.collapseIcon);
                    }
                    else {
                        element.removeClass(scope.collapseIcon);
                        element.addClass(scope.expandIcon);
                        
                    }                                    
                }
            };                       
            element.bind('click', function() 
            {                
                 isOpen = myCtrl.toggle();
                 setIcon();
            });   
            setIcon();
        }                
    };             
})
        
.directive('collapse', ['$transition', function($transition) {
  // CSS transitions don't work with height: auto, so we have to manually change the height to a
  // specific value and then once the animation completes, we can reset the height to auto.
  // Unfortunately if you do this while the CSS transitions are specified (i.e. in the CSS class
  // "collapse") then you trigger a change to height 0 in between.
  // The fix is to remove the "collapse" CSS class while changing the height back to auto - phew!

  var props = {
        open : {            
            marginTop: null,
            marginBottom: null,
            paddingTop: null,
            paddingBottom: null,
            display:'block'
        },
        closed: {
            marginTop: 0,
            marginBottom: 0,
            paddingTop: 0,
            paddingBottom: 0,
            display:'none'
        }
    };

  var fixUpHeight = function(scope, element, height) {
    // We remove the collapse CSS class to prevent a transition when we change to height: auto
    element.removeClass('collapse');
    element.css({ height: height });
      //adjusting for any margin or padding
      if (height===0) {
          element.css(props.closed);
      } else {
          element.css(props.open);
      }
    // It appears that  reading offsetWidth makes the browser realise that we have changed the
    // height already :-/
    var x = element[0].offsetWidth;
    element.addClass('collapse');
  };

  return {
    link: function(scope, element, attrs) {

       // alert(element.css("marginTop"));
      var isCollapsed;
      var initialAnimSkip = true;
      scope.$watch(function (){ return element[0].scrollHeight; }, function (value) {
        //The listener is called when scrollHeight changes
        //It actually does on 2 scenarios: 
        // 1. Parent is set to display none
        // 2. angular bindings inside are resolved
        //When we have a change of scrollHeight we are setting again the correct height if the group is opened
        if (element[0].scrollHeight !== 0) {
          if (!isCollapsed) {
            if (initialAnimSkip) {
              fixUpHeight(scope, element, element[0].scrollHeight + 'px');
            } else {
              fixUpHeight(scope, element, 'auto');
            }
          }
        }
      });
      
      scope.$watch(attrs.collapse, function(value) {
        if (value) {
          collapse();
        } else {
          expand();
        }
      });
      

      var currentTransition;
      var doTransition = function(change) {
        if ( currentTransition ) {
          currentTransition.cancel();
        }
        currentTransition = $transition(element,change);
        currentTransition.then(
          function() { currentTransition = undefined; },
          function() { currentTransition = undefined; }
        );
        return currentTransition;
      };

      var expand = function() {
        //element.show();
          scope.postTransition = true;
        if (initialAnimSkip) {
          initialAnimSkip = false;
          if ( !isCollapsed ) {
            fixUpHeight(scope, element, 'auto');
          }
        } else {
          //doTransition({ height : element[0].scrollHeight + 'px' })
          doTransition(angular.extend({ height : element[0].scrollHeight + 'px' }, props.open))
          .then(function() {
            // This check ensures that we don't accidentally update the height if the user has closed
            // the group while the animation was still running
            if ( !isCollapsed ) 
            {
              fixUpHeight(scope, element, 'auto');
            }
          });
        }
        isCollapsed = false;
      };
      
      var collapse = function() {
        isCollapsed = true;
        if (initialAnimSkip) {
          initialAnimSkip = false;
          fixUpHeight(scope, element, 0);
        } else {
          fixUpHeight(scope, element, element[0].scrollHeight + 'px');
          //doTransition({'height':'0'}).then(function() {
            doTransition(angular.extend({height:0}, props.closed)).then(function() {
              //element.hide();
              scope.postTransition = false;
          });
        }
      };
    }
  };
}]);

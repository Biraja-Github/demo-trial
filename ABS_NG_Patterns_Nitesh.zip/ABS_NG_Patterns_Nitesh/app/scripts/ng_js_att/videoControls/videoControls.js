angular.module('att.abs.videoControls', [])
        .directive('videoControls', [ function() {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/videoControls/videoControls.html'
                };
            }])
        .directive('photoControls', [ function() {
                return {
                    restrict: 'EA',
                    replace: true,
                    transclude: true,
                    templateUrl: 'app/scripts/ng_js_att_tpls/videoControls/photoControls.html',
                    scope: {
                        prevLink: "@",
                        nextLink: "@"
                    }
                };
            }]);
       
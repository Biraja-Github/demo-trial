<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **video-controls directive** is built using angular library.
This can be used for rendering video controls in an application.

<br/><br/>

The **photo-controls directive** is built using angular library.
This can be used for rendering photo controls in an application.

<br/><br/>

<h6 class="pl-element">DEFAULT ON LANDING PAGE</h6>
<div class="landing-video-default"></div>

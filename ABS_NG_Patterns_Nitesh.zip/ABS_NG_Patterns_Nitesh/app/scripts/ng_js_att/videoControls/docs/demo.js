var videoControlsController = function($scope) {
    
};
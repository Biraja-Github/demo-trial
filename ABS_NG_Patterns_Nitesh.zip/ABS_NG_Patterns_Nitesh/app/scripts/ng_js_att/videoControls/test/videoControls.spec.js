describe('videoControls', function() {

    var $scope, $compile;

    // load the tagBadges code
    beforeEach(module('att.abs.videoControls'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/videoControls/videoControls.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };

    it('should be rendered when the video-controls attr is applied', function() {
        var localElm = compileElement('<div video-controls>2:09</div>', $scope, $compile);

        expect(localElm).toHaveClass('video-player');
    });
    
    it('should be rendered when the <video-controls> element is applied', function() {
        var localElm = compileElement('<video-controls>2:09</video-controls>', $scope, $compile);

        expect(localElm).toHaveClass('video-player');
    });
    
});


describe('photoControls', function() {

    var $scope, $compile;

    // load the tagBadges code
    beforeEach(module('att.abs.videoControls'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/videoControls/photoControls.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope, compile) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };
    
    it('should be rendered when the photo-controls attr is applied', function() {
        var localElm = compileElement('<div photo-controls prev-link="#photo16" next-link="#photo18">17/50</div>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-arrow-left');
        expect(localElm.find('i').eq(1)).toHaveClass('icon-arrow-right');
        expect(localElm.find('a').eq(0).attr('href')).toBe('#photo16');
        expect(localElm.find('a').eq(1).attr('href')).toBe('#photo18');
    });
    
    it('should be rendered when the <video-controls> element is applied', function() {
        var localElm = compileElement('<photo-controls prev-link="#photo16" next-link="#photo18">17/50</photo-controls>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-arrow-left');
        expect(localElm.find('i').eq(1)).toHaveClass('icon-arrow-right');
        expect(localElm.find('a').eq(0).attr('href')).toBe('#photo16');
        expect(localElm.find('a').eq(1).attr('href')).toBe('#photo18');
    });
    
    it('should be rendered inactive when the photo-controls attr is applied and no prev-link/next-link are supplied', function() {
        var localElm = compileElement('<div photo-controls next-link="#photo18">1/1</div>', $scope, $compile);

        expect(localElm.find('i').eq(0)).toHaveClass('icon-arrow-left');
        expect(localElm.find('i').eq(1)).toHaveClass('icon-arrow-right');
        expect(localElm.find('a').eq(0).attr('href')).toBe(undefined);
        expect(localElm.find('a').eq(1).attr('href')).toBe('#photo18');
    });
    
});
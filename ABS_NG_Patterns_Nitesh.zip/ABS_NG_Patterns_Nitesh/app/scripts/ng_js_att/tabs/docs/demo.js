var tabsCtrl = function($scope, $http) {
    //for floating tabs
    $scope.fTabs = [{
            title: 'Inventory',
            url: '#option1'
        },
        {
            title: 'Alarms',
            url: '#option2',
            selected: true
        },
        {
            title: 'Tickets',
            url: '#option3'
        }
    ];

    $scope.smallTabs = [{
            title: 'Daily',
            url: '#option1'
        },
        {
            title: 'Weekly',
            url: '#option2',
            selected: true
        },
        {
            title: 'Monthly',
            url: '#option3'
        },
        {
            title: 'Annualy',
            url: '#option4'
        }
    ];
    //For Icon Tabs
     $scope.iconTabs = [{
            view: 'list', 
            url: '#option1'
        },
        {
            view: 'tiles', 
            url: '#option2',
            selected: true
        }];
    //For tabs with Images
    $scope.tabsWithIcons = [{
            title: 'Mobile Share Value',
            iconCss: 'icon-groups',
            url: '#mobile-share-value',
            selected: true
        },
        {
            title: 'Group Voice',
            iconCss: 'flat-icon-group',
            url:'#group-voice',
        },
        {
            title: 'Individual',
            iconCss: 'icon-user',
            url:'#individual',
        },
    ];
    //for simplified tabs
    $scope.activeTabId = 'helpFul';
    $scope.sTabs = [{
            title: 'Most helpul',
            id: 'helpFul'
        },
        {
            title: 'Newest',
            id: 'newest'
        },
        {
            title: 'Oldest',
            id: 'oldest'

        },
        {
            title: 'Highest Rating',
            id: 'highRated'
        },
        {
            title: 'Lowest Rating',
            id: 'lowRated'
        },
        {
            title: 'Most Consulted',
            id: 'mostConsulted'
        }
    ];
	//for Generic tabs
	$scope.activeTabsId = 'Profile';
		$scope.gTabs = [
			{
				title: 'Profile',
				id: 'Profile',
				url: '#/Profile'
			}
			, {
				title: 'Product & Accounts',
				id: 'Product & Accounts',
				 url: '#/Product'
			},
			{
				title: 'Users',
				id: 'Users',
				 url: '#/Users'

			},
			{
				title: 'Widgets & Tools',
				id: 'Widgets & Tools',
				 url: '#/Widgets'
			}
			
		];
	
    $scope.isActive = function(tab) {
        return tab === $scope.activeTabId;
    };
    $scope.tabClass = 'bg-dark-gray';
    $scope.triangleClass = 'triangle-dark-gray';
    $scope.colorsItem = [];
    $scope.colorClass = [];
    $http.get('data/colors.json').success(function(data) {
        var obj = data;
        for (var key in obj) {
            if (key !== 'dividers') {
                var colorObj = obj[key];
                for (var cKey in colorObj) {
                    var color = (colorObj[cKey].color);
                    var title = (colorObj[cKey].title);
                    var triangle = (colorObj[cKey].triangle);
                    var name = (colorObj[cKey].name);
                    $scope.colorsItem.push({'color': color, 'title': title, 'triangle': triangle});
                    $scope.colorClass[colorObj[cKey].color] = {'color': color,
                        'triangle': triangle,
                        'colorClass': name
                    };
                    var cItemObj = $scope.colorClass;
                    $scope.$watch('selected', function(val) {
                        for (var key in cItemObj) {
                            if (val == key) {
                                $scope.triangleClass = cItemObj[key].triangle;
                                $scope.tabClass = cItemObj[key].colorClass;
                            }
                        }
                    });
                }
            }
        }
    });
};
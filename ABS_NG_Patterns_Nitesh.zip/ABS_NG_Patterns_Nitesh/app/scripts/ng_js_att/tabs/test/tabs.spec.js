describe('Unit Test- Tabs', function() {
    var scope,compile;
    beforeEach(module('att.abs.tabs'));
    beforeEach(module('app/scripts/ng_js_att_tpls/tabs/floatingTabs.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/tabs/simplifiedTabs.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/tabs/iconTabs.html'));
	beforeEach(module('app/scripts/ng_js_att_tpls/tabs/genericTabs.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_, _$q_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
        $q = _$q_;
    }));

        var compileMarkup = function(markup, scope) {
            var el = $compile(markup)(scope);
            scope.$digest();
            return el;
        };

    // check for toggle of active class in floating tabs
    it('should toggle active class on click on large size floating tabs', function() {
        $scope.tabs = [{
                title: 'Option 1'
            }, {
                title: 'Option 2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><floating-tabs size="large"></floating-tabs></att-tabs>', $scope);
        var list = markUp.children();
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item--active');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
    });
    
    it('should toggle active class on click on small size floating tabs', function() {
        $scope.tabs = [{
                title: 'Option 1'
            }, {
                title: 'Option 2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><floating-tabs size="small"></floating-tabs></att-tabs>', $scope);
        var list = markUp.children();
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item--active');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
    });
  
    it('should render large floating tabs', function() {
        $scope.tabs = [{
                title: 'Option 1',
                url: '#option1'
            }, {
                title: 'Option 2',
                url: '#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><floating-tabs size="large"></floating-tabs></att-tabs>', $scope);
        var list = markUp.children();
        expect(list).toHaveClass('tabs');
        expect(list).not.toHaveClass('tabs--small');
    });
    
    it('should render small floating tabs', function() {
        $scope.tabs = [{
                title: 'Option 1',
                url: '#option1'
            }, {
                title: 'Option 2',
                url: '#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><floating-tabs size="small"></floating-tabs></att-tabs>', $scope);
        var list = markUp.children();
        expect(list).toHaveClass('tabs--small');
    });
    
    it('should toggle active class on click on simplified tabs', function() {
        $scope.tabs = [{
                title: 'Option 1'
            }, {
                title: 'Option 2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><simplified-tabs></simplified-tabs></att-tabs>', $scope);
        var list = markUp.children().children();
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item--active');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
    });
    
    it('should check for header title for image tabs', function() {
        $scope.tabs = [{
                title: 'Option 1',
                iconCss:'icon-groups',
                url:'#option1'
            }, {
                title: 'Option 2',
                iconCss:'icon-groups',
                url:'#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><simplified-tabs header="ATT Wireless Plans"></simplified-tabs></att-tabs>', $scope);
        var headerTag = markUp.children().children().eq(1).children().html();
        expect(headerTag).toBe('ATT Wireless Plans');
    });
    
    it('should toggle active class on click on Image tabs', function() {
        $scope.tabs = [{
                title: 'Option 1',
                iconCss:'icon-groups',
                url:'#option1'
            }, {
                title: 'Option 2',
                iconCss:'icon-groups',
                url:'#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><simplified-tabs header="AT&T Wireless Plans"></simplified-tabs></att-tabs>', $scope);
        var list = markUp.children().children().eq(2);
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item--active');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
    });
    
    it('should toggle active class on click on Icon Tabs', function() {
        $scope.iconTabs = [{
                view: 'list',
                url: '#option1'
            }, {
                view: 'tiles',
                url: '#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="iconTabs"><icon-tabs size="large"></icon-tabs></icon-tabs>', $scope);
        var list = markUp.children();
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item--active');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item--active');
    });
    
	it('should toggle active class on click on generic tabs', function() {
        $scope.tabs = [{
                title: 'Option 1'
            }, {
                title: 'Option 2'
            }];
        var markUp = compileMarkup('<att-tabs title="tabs"><generic-tabs></generic-tabs></att-tabs>', $scope);
        var list = markUp.children().children();
        var firstItem = list.children().eq(0);
        var secondItem = list.children().eq(1);
        firstItem.click();
        expect(firstItem).toHaveClass('tabs__item-link');
        secondItem.click();
        expect(secondItem).toHaveClass('tabs__item-link');
    });
	
    it('should render large icon tabs', function() {
        $scope.iconTabs = [{
                view: 'list',
                url: '#option1'
            }, {
                view: 'tiles',
                url: '#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="iconTabs"><icon-tabs size="large"></icon-tabs></att-tabs>', $scope);
        var list = markUp.children();
        expect(list).toHaveClass('tabs');
        expect(list).not.toHaveClass('tabs--small');
        
    });
    
    it('should render small icon tabs', function() {
        $scope.iconTabs = [{
                view: 'list',
                url: '#option1'
            }, {
                view: 'tiles',
                url: '#option2'
            }];
        var markUp = compileMarkup('<att-tabs title="iconTabs"><icon-tabs size="small"></icon-tabs></att-tabs>', $scope);
        var list = markUp.children();
        expect(list).toHaveClass('tabs--small');
    });
});




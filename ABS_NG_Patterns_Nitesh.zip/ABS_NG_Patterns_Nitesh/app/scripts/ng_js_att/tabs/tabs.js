angular.module('att.abs.tabs', [])
        .directive('attTabs', function() {
            return{
                restrict: 'EA',
                transclude: false,
                replace: true,
                scope: {
                    tabs: "=title"
                },
                controller: ['$scope', function($scope) {
                        this.getData = function() {
                            return $scope.tabs;
                        };
                        this.onClickTab = function(tab) {
                            return $scope.currentTab = tab.url;
                        };
                        this.isActiveTab = function(tab) {
                            return tab === $scope.currentTab;
                        };
                    }],
                link: function(scope, elem, attr, ctrl) {
                    for (var i = 0; i < scope.tabs.length; i++) {
                        if (scope.tabs[i].selected) {
                            if (scope.tabs[i].url) {
                                scope.currentTab = scope.tabs[i].url;
                            }
                        }
                    }
                }
            };
        })
        .directive('floatingTabs', function() {
            return {
                require: '^attTabs',
                restrict: 'EA',
                transclude: false,
                replace: true,
                scope: {
                    size: "@"
                },
                templateUrl: 'app/scripts/ng_js_att_tpls/tabs/floatingTabs.html',
                link: function(scope, elem, attr, attTabsCtrl) {
                    scope.tabs = attTabsCtrl.getData();
                    scope.onClickTab = attTabsCtrl.onClickTab;
                    scope.isActiveTab = attTabsCtrl.isActiveTab;
                }
            };
        })
        .directive('simplifiedTabs', function() {
            return {
                require: '^attTabs',
                restrict: 'EA',
                transclude: false,
                replace: true,
                scope: {
                    ctab: "=ngModel",
                    header: "@"
                },
                templateUrl: 'app/scripts/ng_js_att_tpls/tabs/simplifiedTabs.html',
                link: function(scope, elem, attr, attTabsCtrl) {
                    scope.tabs = attTabsCtrl.getData();
                    scope.clickTab = function(tab) {
                        return scope.ctab = tab.id;
                    };
                    scope.isActive = function(tab) {
                        return tab === scope.ctab;
                    };
                    if(scope.header){
                       scope.iconFlag = true;
                    }
                    else{
                        scope.iconFlag = false;
                    }
                    scope.clickImgTab = attTabsCtrl.onClickTab;
                    scope.isActiveImgTab = attTabsCtrl.isActiveTab;
                }
            };
        })
		 .directive('genericTabs', function() {
            return {
                require: '^attTabs',
                restrict: 'EA',
                transclude: false,
                replace: true,
                scope: {
                    ctab: "=ngModel"
                },
                templateUrl: 'app/scripts/ng_js_att_tpls/tabs/genericTabs.html',
                link: function(scope, elem, attr, attTabsCtrl) {
                    scope.tabs = attTabsCtrl.getData();
                    scope.clickTab = function(tab) {
                        return scope.ctab = tab.id;
                    };
                    scope.isActive = function(tab) {
                        return tab === scope.ctab;
                    };
                }
            };
        })
        .directive('iconTabs', function() {
            return {
                require: '^attTabs',
                restrict: 'EA',
                transclude: false,
                replace: true,
                scope: {
                    size: "@"
                },
                templateUrl: 'app/scripts/ng_js_att_tpls/tabs/iconTabs.html',
                link: function(scope, elem, attr, attTabsCtrl) {
                    scope.tabs = attTabsCtrl.getData();
                    scope.onClickTab = attTabsCtrl.onClickTab;
                    scope.isActiveTab = attTabsCtrl.isActiveTab;
                }
            };
        });
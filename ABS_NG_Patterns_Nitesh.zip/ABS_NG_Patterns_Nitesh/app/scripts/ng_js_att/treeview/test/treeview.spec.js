describe('treeview', function() {
    
    var $scope, $compile;
    beforeEach(module('att.abs.treeview'));
        beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        var elm = $compile(markUp)(scope);
        return elm;
    };
    
    it("the Treeview will be collapsed initially", function() {                
        var treeview = compileElement('<div class="att--tree">' +
'        <ul>' +
'            <li class="att--tree__plus" tree-view>Item Level 1' +
'                <ul>' +
'                    <li class="att--tree__arrow"><a href="#">Item Level 1.1</a></li>' +
'                    <li class="att--tree__arrow"><a href="#">Item Level 1.2</a></li>' +
'                    <li class="att--tree__arrow"><a href="#">Item Level 1.3</a></li>' +
'                </ul>' +
'            </li>' +
'            <li class="att--tree__plus" tree-view>Item Level 2' +
'                 <ul>' +
'                    <li class="att--tree__arrow"><a href="#">Item Level 2.1</a></li>' +
'                    <li class="att--tree__plus" tree-view>Item Level 2.2' +
'                        <ul>' +
'                            <li class="att--tree__arrow"><a href="#">Item Level 2.2.1</a></li>' +
'                            <li class="att--tree__arrow"><a href="#">Item Level 2.2.2</a></li>' +
'                            <li class="att--tree__arrow"><a href="#">Item Level 2.2.3</a></li>' +
'                        </ul>' +
'                    </li>' +
'                    <li class="att--tree__arrow"><a href="#">Item Level 2.3</a></li>' +
'                </ul>' +
'            </li>' +
'        </ul>' +
'</div>',$scope);
    
        expect(treeview.find('li')).toHaveClass('att--tree__arrow');
        expect(treeview.find('li')).not.toHaveClass('minus');              
    });
    
    it("if Clicked on TreeView Branch, it should Toggle the visibitlity of child branch", function() {        
        var treeview = compileElement('<li class="att--tree__plus minus" tree-view>Item Level 1'+
                '<ul>'+
                    '<li class="att--tree__arrow"><a href="#">Item Level 1.1</a></li>'+
                    '<li class="att--tree__arrow"><a href="#">Item Level 1.2</a></li>'+
                    '<li class="att--tree__arrow"><a href="#">Item Level 1.3</a></li>'+
                '</ul></li>',$scope);
        
        treeview.find('li').eq(0).click();   
        //parent UL display must be set to "block"
        expect(treeview.eq(0)).toHaveClass('minus');       
    });       
    
    it("if clicked on list items TreeView should not Collapsed", function(){
        var treeview = compileElement('<li class="att--tree__plus" tree-view>',$scope);
        treeview.find('ul').find('li').eq(0).click();           
        expect(treeview.find('ul').find('li').eq(0)).not.toHaveClass('minus');         
    });
    
});


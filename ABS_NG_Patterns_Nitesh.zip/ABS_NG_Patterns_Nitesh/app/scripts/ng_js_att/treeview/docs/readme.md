<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

A vertical steptracker is used to track ticket status. 
This steptracker lets the user know how many steps are in the process.

<br/>

The **vertical-steptracker directive** is built using angular library.
This can be used for rendering vertical steptracker in an application.

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>The vertical steptracker are used when a user needs to know how many steps are in the process.</li>
</ul>

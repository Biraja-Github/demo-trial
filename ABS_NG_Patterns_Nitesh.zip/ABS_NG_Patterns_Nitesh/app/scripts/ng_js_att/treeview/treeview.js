angular.module('att.abs.treeview',[])
.directive('treeView',function(){
	return{
         restrict: 'A',        
        link: function(scope, elem, attrs) {
                    var el = elem.children('ul li');
                    var list = TweenMax.from(el, .2, {display: 'none', paused: true, reversed: true});
					elem.attr("tabindex","0");									
                    function toggleBranch() {
                        if (list.reversed())
                        {
                            list.play();
                        } else
                        {
                            list.reverse();
                        }
                    };
					function toggleTree(e){
					e.stopPropagation();
						if ($(e.target).attr("tree-view") !== undefined)
                        {
                            if (elem.hasClass('minus'))
                            {
                                elem.removeClass('minus');
                            }
                            else
                            {
                                elem.addClass('minus');
                            }
                            toggleBranch();
                        }
					}
                    elem.on('click', function(e) {
						toggleTree(e);
                    });
					elem.on('keypress', function (e) {						
						var activeCode = e.keyCode ? e.keyCode : e.charCode;				
						var keyCode = [13,32];
						if(keyCode.length > 0 && ((activeCode && keyCode.indexOf(activeCode) > -1))) {						
							toggleTree(e);							
							e.preventDefault();
						}
					});					
                }
		};
});
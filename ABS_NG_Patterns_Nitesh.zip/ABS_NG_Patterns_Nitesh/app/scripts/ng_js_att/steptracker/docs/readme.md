<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

A simple steptracker is used for simple processes.
This steptracker lets the user know how many steps are in the process and where they are.
They can navigate backwards to previous steps.

<br/>

The **steptracker directive** is built using angular library.
This can be used for rendering steptracker in an application.

<br/>

The **att-timeline directive** is built using angular library.
This can be used for rendering timeline in an application.

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>The steptracker are used when a user needs to know how many steps are in the process and where they are.</li>
</ul>

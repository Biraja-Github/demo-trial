var steptrackerController = function($scope) {
    $scope.dSteps = [
            {title: "Voice"},
            {title: "Broadband"},
            {title: "Wifi"}//,
            //{title: "Additional"}
    ];

	$scope.trigger1 = false;
	$scope.alternate1 = false;

	$scope.steps = [
		{title: "Submitted", date: "10/12/2015, 10:00am"},
		{title: "Submitted", date: "10/12/2015, 10:00am"},
		{title: "Submitted", date: "10/12/2015, 10:00am"},
		{title: "Completed"}
	];

	$scope.btnClick1 = function(){
		$scope.trigger1=true;
	};

	/*
		The different types of alerts can be completed, cancelled, and alert.  You don't need complerted
		unless you are stopping in the middle. Animation will only occur if you have more than 4 and alternate
		is set to true.
	*/
	$scope.trigger2 = false;
	$scope.alternate2 = true;

	$scope.steps2 = [
		{title: "Submitted", description: "Initial submit", by: "Ronald Johnson", date: "10/12/2015, 10:00am"},
		{title: "Submitted", description: "Details Text", by: 'Steve Doe', date: "10/12/2015, 10:00am"},
		{title: "Submitted", description: "Details Text", by: 'Steve Doe', date: "10/12/2015, 10:00am"},
		{title: "Submitted", description: "Details Text", by: 'Steve Doe', date: "10/12/2015, 10:00am", type:'alert'},
		{title: "Completed", description: "", by: '', date: ""}
	];
	
	$scope.btnClick2 = function(){
		$scope.trigger2=true;
	};
};



describe('steptracker', function() {
    var scope, compile;
    beforeEach(module('att.abs.steptracker'));
    beforeEach(module('app/scripts/ng_js_att_tpls/steptracker/step-tracker.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));
 
    var compileMarkup = function(markup) {
        scope.dSteps = [
            {title: "Voice"},
            {title: "Broadband"},
            {title: "Wifi"},
            {title: "Additional"},
            {title: "Test"}
         ];
        var elem = angular.element(markup);      
        elem = compile(elem)(scope);      
        scope.$apply(elem);
        return elem;
    };

    it("should create number of dives equal to the attribute maxstepv", function() {            
        var elesteptracker = compileMarkup('<steptracker sdata="dSteps" currentstep="1"></steptracker>');
        var steps = elesteptracker.children().children();
        expect(steps.length).toBe(5);        
        expect(elesteptracker.children().html()).toContain('steptracker-track size-onethird');
        expect(steps.eq(0).children().children().text()).toBe('Voice');
        expect(steps.eq(1).children().children().text()).toBe('Broadband');
        expect(steps.eq(2).children().children().text()).toBe('Wifi');
        expect(steps.eq(3).children().children().text()).toBe('Additional');
    });
    it("Check the initial state is activated or not at the biggining",function(){
         var elesteptracker = compileMarkup('<steptracker sdata="dSteps" currentstep="1"></steptracker>'); 
         var steps = elesteptracker.children().children();        
         expect(steps.eq(0)).toHaveClass('active');
         expect(steps.eq(1)).not.toHaveClass('active');
         expect(steps.eq(2)).not.toHaveClass('active');
         expect(steps.eq(3)).not.toHaveClass('active');
         expect(steps.eq(4)).not.toHaveClass('active');
         expect(steps.eq(4)).toHaveClass('last');  
      });
      it('should change active step when click the step two', function() {
        var elesteptracker = compileMarkup('<steptracker sdata="dSteps" currentstep="1"></steptracker>');
        var steps = elesteptracker.children().children();
        steps.eq(1).click();
        expect(steps.eq(0)).not.toHaveClass('active');
        expect(steps.eq(0)).toHaveClass('done');
        expect(steps.eq(1)).toHaveClass('active');
        expect(steps.eq(2)).not.toHaveClass('active');
        expect(steps.eq(3)).not.toHaveClass('active');
        expect(steps.eq(4)).not.toHaveClass('active');
        expect(steps.eq(4)).toHaveClass('last');  
  });
  it('should change active step when click the step three', function() {
        var elesteptracker = compileMarkup('<steptracker sdata="dSteps" currentstep="1"></steptracker>');
        var steps = elesteptracker.children().children();
        steps.eq(2).click();
        expect(steps.eq(0)).not.toHaveClass('active');
        expect(steps.eq(0)).toHaveClass('done');
        expect(steps.eq(1)).not.toHaveClass('active');
        expect(steps.eq(1)).toHaveClass('done');
        expect(steps.eq(2)).toHaveClass('active');
        expect(steps.eq(2)).not.toHaveClass('done');
        expect(steps.eq(3)).not.toHaveClass('active');
        expect(steps.eq(4)).not.toHaveClass('active');
        expect(steps.eq(4)).toHaveClass('last');  
        
  });
   it('should change active step when click the step four', function() {
        var elesteptracker = compileMarkup('<steptracker sdata="dSteps" currentstep="1"></steptracker>');
        var steps = elesteptracker.children().children();
        steps.eq(3).click();
        expect(steps.eq(0)).not.toHaveClass('active');
        expect(steps.eq(0)).toHaveClass('done');
        expect(steps.eq(1)).not.toHaveClass('active');
        expect(steps.eq(1)).toHaveClass('done');
        expect(steps.eq(2)).not.toHaveClass('active');
        expect(steps.eq(2)).toHaveClass('done');
        expect(steps.eq(3)).toHaveClass('active');
        expect(steps.eq(3)).not.toHaveClass('done');
        expect(steps.eq(4)).not.toHaveClass('active');
        expect(steps.eq(4)).toHaveClass('last');        
  });
     
});


describe('steptracker', function() {

    var scope, compile,timeout;

    beforeEach(module('att.abs.steptracker'));
    beforeEach(module('app/scripts/ng_js_att_tpls/steptracker/timeline.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/steptracker/timelineBar.html'));
    beforeEach(module('app/scripts/ng_js_att_tpls/steptracker/timelineDot.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_, $timeout) {
        scope = _$rootScope_;
        compile = _$compile_;
        timeout = $timeout;
    }));
 
    var markup = "<div att-timeline steps='steps' trigger='trigger'></div>";
    var compileMarkup = function() {
        var elem = angular.element(markup);      
        elem = compile(elem)(scope);      
        scope.$apply(elem);
        return elem;
    };

    it('should create the correct number of steps',function(){
        scope.trigger = false;
        scope.steps = [
            {title: "Submitted long title stufsfdsfsdfdsfdsafsdff", description: "Grammys", by: "by: Kayne West", date: "10/12/2015, 10:00am"},
            {title: "Submitted", description: "details stuff", by: 'Steve Doe', date: "10/12/2015, 10:00am"},
            {title: "Submitted", description: "details stuff", by: 'Steve Doe', date: "10/12/2015, 10:00am"},
            {title: "Submitted", description: "details stuff", by: 'Steve Doe', date: "10/12/2015, 10:00am", type:'alert'},
            {title: "Completed", description: "", by: '', date: ""}
        ];

        var element = compileMarkup();
        var numDots = 0;
        var divs = element.find('div');
        for(var e in divs){
            if(divs.eq(e).hasClass('timeline-dot')){
                numDots++;
            }
        }
        expect(numDots).toBe(5);
    });

    it('should contain the corret text', function(){
        scope.trigger = true;
        scope.steps = [
            {title: "Submitted long title stufsfdsfsdfdsfdsafsdff", description: "Grammys", by: "by: Kayne West", date: "10/12/2015, 10:00am"},
            {title: "Submitted", description: "details stuff", by: 'Steve Doe', date: "10/12/2015, 10:00am", type:'cancelled'},
            {title: "Completed", description: "", by: '', date: ""}
        ];


        var element = compileMarkup();
        
        scope.$apply();

        var numDots = 0;
        var divs = element.find('div');

        var containsText = false;
        for(var e in divs){
            if(divs.eq(e).hasClass('timeline-dot')){
                if(e==0 && divs.eq(e).text().indexOf('Submitted') > -1){
                    containsText = true;
                }
            }
        }

        expect(containsText).toBe(true);
    })

});
'use strict'
angular.module('att.abs.steptracker', ['att.abs.transition'])
    .directive('steptracker', [
    function() {
        return {
            scope: {
                sdata: "=sdata",
                cstep:"=currentstep"
            },
            restrict: 'E',
            replace: true,
            templateUrl: 'app/scripts/ng_js_att_tpls/steptracker/step-tracker.html',
            link: function(scope, elem, attr, ctrl) {
            //dynamically add width for steps, depending on the number of steps.
            scope.set_width = function(indexval) {
                var setwidth = (100 / (scope.sdata.length - 1)) + "%";
                //skip last element and add width for all other element
                if ((scope.sdata.length - 1) > indexval) {
                    return {width: setwidth};
                }
            };
               //add the active class for current step
                scope.activestep = function(indexval) {
                    if (indexval === scope.cstep-1) return true;else return false;
                };
                //add the done class for finished step
                scope.donesteps = function(indexval) {
                    if (indexval < scope.cstep-1) return true;else return false;
                    if (indexval >= scope.cstep-1) return false;else return false;
                };
                //add the last class for final step
                scope.laststep = function(indexval) {
                    if (indexval === scope.sdata.length-1) return true;else return false;
                };
                //click event 
                scope.stepclick = function(steps) {                   
                    scope.donesteps = function(indexval) {
                        if (indexval < steps) return true;else return false;
                        if (indexval >= steps) return false;else return false;
                    };
                    scope.activestep = function(indexval) {
                        if (indexval === steps) return true; else return false;
                    };
                };
            }
         };
     }
 ])
.constant('timelineConstants',{
    STEP_TYPE:{
        ALERT:'alert',
        COMPLETED:'completed',
        CANCELLED: 'cancelled'
    }
})
.controller('AttTimelineCtrl' , ['$scope', '$timeout', function($scope,$timeout){

    var timelineBarCtrls = [];
    var timelineDotCtrls = [];

    this.numSteps = 0;

    this.isAlternate = function(){
        return $scope.alternate;
    }

    this.addTimelineBarCtrls = function(t){
        timelineBarCtrls.push(t);       
    };

    this.addTimelineDotCtrls = function(b){
        timelineDotCtrls.push(b);
    };

    $timeout(init,200);
    
    function init(){
 
        function compare(a,b) {
          if (a.order < b.order)
             return -1;
          if (a.order > b.order)
            return 1;
          return 0;
        }

        timelineDotCtrls.sort(compare);
        timelineBarCtrls.sort(compare);

        if($scope.$parent.animate)
            animateSequence();
        
        $scope.$watch('trigger', function(val){
            if(val){
                $scope.resetTimeline();
            }else{
                $scope.$parent.animate = false;
            }
        });
    }

    function animateSequence(){

        var dotsDuration = .25;
        var start = createAnimation(0,.25);

        function setToInactiveStates(){

            for(var i in timelineDotCtrls){
                var dotCtrl = timelineDotCtrls[i];

                if(i%2 == 0){
                    dotCtrl.unhoveredStateForBelow(.25);
                }else{
                    dotCtrl.unhoveredStateForAbove(.25);
                }

                if(dotCtrl.isStop())
                    break;
            }

        }

        function createAnimation(i, duration){
            if(i == 0){
                return function(){
                    if(timelineDotCtrls[i+1].isStop() && timelineDotCtrls[i+1].isCancelled()){
                        timelineBarCtrls[i].isCancelled(true);
                    }
                    timelineBarCtrls[i].animate(createAnimation(i+1, duration), duration);
                }
            }else if(i == timelineBarCtrls.length - 1){
                return function(){

                    //Removes the bolded text from the start
                    if(timelineDotCtrls[0].isCurrentStep()){
                        timelineDotCtrls[0].isCurrentStep(false);
                    }

                    if(timelineDotCtrls[i].isStop()){
                        timelineDotCtrls[i-1].shrinkAnimate(dotsDuration);
                        timelineDotCtrls[i].isCurrentStep(true);
                    }else{
                        timelineDotCtrls[i-1].shrinkAnimate(dotsDuration);
                        timelineBarCtrls[i].animate(createAnimation(i+1, duration), duration);
                    }

                    timelineDotCtrls[i].expandedAnimate(dotsDuration);

                    $timeout(function(){
                        setToInactiveStates();
                    },500);
                }
            }
            //End Dot
            else if(i == timelineBarCtrls.length){
                return function(){

                    //Removes the bolded text from the start
                    if(timelineDotCtrls[0].isCurrentStep()){
                        timelineDotCtrls[0].isCurrentStep(false);
                    }

                    timelineDotCtrls[i-1].shrinkAnimate(dotsDuration);
                    timelineDotCtrls[i].expandedAnimate(dotsDuration);
                    timelineDotCtrls[i].isCurrentStep(true);

                    $timeout(function(){
                        setToInactiveStates();
                    },500);
                    
                }
            }
            else{
                return function(){
                    //Removes the bolded text from the start
                    if(timelineDotCtrls[0].isCurrentStep()){
                        timelineDotCtrls[0].isCurrentStep(false);
                    }

                    //timelineDotCtrls[i].setColor();
                    if(timelineDotCtrls[i].isStop()){
                        timelineDotCtrls[i-1].shrinkAnimate(dotsDuration);
                        timelineDotCtrls[i].expandedAnimate(dotsDuration);
                        timelineDotCtrls[i].isCurrentStep(true);

                        $timeout(function(){
                            setToInactiveStates();
                        },500);

                    }else{

                        if(timelineDotCtrls[i+1].isStop() && timelineDotCtrls[i+1].isCancelled()){
                            timelineBarCtrls[i].isCancelled(true);
                        }
                    
                        timelineDotCtrls[i-1].shrinkAnimate(dotsDuration);
                        timelineBarCtrls[i].animate(createAnimation(i+1, duration), duration);
                        timelineDotCtrls[i].expandedAnimate(dotsDuration);
                    }
                    
                }
            }
        }

        start();
    }

}])
.directive('attTimeline', ['$timeout', '$compile', function($timeout,$compile){
    return {
        restrict: 'EA',
        replace: true,
        scope: {
            steps: '=',
            trigger:'=',
            alternate: '='
        },
        templateUrl: 'app/scripts/ng_js_att_tpls/steptracker/timeline.html',
        controller: 'AttTimelineCtrl',
        link: function(scope,element,attrs,ctrl){

            var init = function(){
                var tempCtrls = [];
                var steps = scope.steps;

                var middleSteps = [];
                for(var i = 1; i < steps.length; i++){
                    var aStep = steps[i];
                    middleSteps.push(aStep);
                }

                scope.middleSteps = middleSteps;

                //Used in calculating the width of the loading bars
                ctrl.numSteps = steps.length - 1;
            };
            
            init();

            //Recompile in case of scope changes
            scope.resetTimeline = function(){
               scope.animate = true;
               $compile(element)(scope);
            };
        }
    }
}])
.controller('TimelineBarCtrl', ['$scope', function($scope){
    this.type  = 'timelinebar';
    this.order = parseInt($scope.order);

    this.animate = function(callback,duration){
        $scope.loadingAnimation(callback,duration);
    };

    this.isCancelled = function(isCancelled){
        $scope.isCancelled = isCancelled;
    }

}])
.directive('timelineBar', ['animation', '$progressBar', function(animation, $progressBar){
    return {
        restrict: 'EA',
        replace: true,
        templateUrl: 'app/scripts/ng_js_att_tpls/steptracker/timelineBar.html',
        scope: {
            order: '@'
        },
        require: ['^attTimeline', 'timelineBar'],
        controller: 'TimelineBarCtrl',
        link: function(scope,element,attrs, ctrls){

            var attTimelineCtrl = ctrls[0];
            var timelineBarCtrl = ctrls[1];

            attTimelineCtrl.addTimelineBarCtrls(timelineBarCtrl);

            scope.isCompleted = true;

            var widthPerc = (100/attTimelineCtrl.numSteps)-3;

            element.css('width', widthPerc+'%');
        
            var elem = element.find('div').eq(0);

            animation.set(elem, {opacity: 0.0});

            var updateCallback = function(selfElement){
                animation.set(elem, {opacity:1.0});
                animation.set(elem,{
                    scaleX:selfElement.progress(),
                    transformOrigin: "left"
                });
            };
            
            scope.loadingAnimation = $progressBar(updateCallback);
        }
    }
}])
.controller('TimelineDotCtrl', ['$scope','$timeout', 'timelineConstants',function($scope,$timeout,timelineConstants){
    this.type = 'dot';

    this.order = parseInt($scope.order);
    var self = this;

    $timeout(function(){

        if(self.order != 0){
            if(self.order %2 != 0){
                $scope.initializeAboveForAnimation();
            }
            else{
                $scope.initializeBelowForAnimation();
            }
        }

    });

    this.expandedAnimate  = function(duration){

        $scope.setColor();
        $scope.expandedAnimate(duration);

        if(self.order != 0 && !$scope.isStepsLessThanFive()){
            if(self.order % 2 != 0){
                $scope.expandContentForAbove(duration);
            }else{
                $scope.expandContentForBelow(duration);
            }
        }
        
    };

    this.unhoveredStateForAbove = function(duration){
        $scope.unhoveredStateForAbove(duration);
    };

    this.unhoveredStateForBelow = function(duration){
        $scope.unhoveredStateForBelow(duration);
    };

    this.shrinkAnimate = function(duration){
        $scope.shrinkAnimate(duration);
    };

    this.setExpanded = function(){
        $scope.setSize(3);
    };

    this.isStop = function(){
        return $scope.isStop;
    };

    this.isCancelled = function(){
        if($scope.type == timelineConstants.STEP_TYPE.CANCELLED)
            return true;
        else
            return false;
    };

    this.isAlert = function(){
        if($scope.type == timelineConstants.STEP_TYPE.ALERT)
            return true;
        else
            return false;
    };

    //Sets the bolded text
    this.isCurrentStep = function(isCurrentStep){
        if(isCurrentStep != undefined){
            $scope.isCurrentStep = isCurrentStep;
        }
        return $scope.isCurrentStep;
    };

}])
.directive('timelineDot', ['$timeout', 'animation', 'timelineConstants', 
    function($timeout,animation,timelineConstants){
    return {
        restrict: 'EA',
        replace: true,
        scope:{
            order:'@',
            title:'@',
            description: '@',
            by: '@',
            date: '@',
            type: '@'
        },
        templateUrl: 'app/scripts/ng_js_att_tpls/steptracker/timelineDot.html',
        require: ['^attTimeline', 'timelineDot'],
        controller: 'TimelineDotCtrl',
        link: function(scope,element,attrs,ctrls){

            var attTimelineCtrl = ctrls[0];
            var timelineDotCtrl = ctrls[1];
            attTimelineCtrl.addTimelineDotCtrls(timelineDotCtrl);

            scope.numSteps = attTimelineCtrl.numSteps + 1;

            scope.isCurrentStep = false;
            scope.isCompleted = false;
            scope.isStop = false;

            if(scope.type == timelineConstants.STEP_TYPE.ALERT || scope.type == timelineConstants.STEP_TYPE.CANCELLED){
                scope.isStop = true;
            }

            scope.isInactive = true;

            var divs = element.find('div');
            
            var biggerCircleElem = divs.eq(0);
            var expandableCircleElem = divs.eq(2);
            var infoboxElem = divs.eq(3);
            var titleElem = divs.eq(5);
            var contentElem = divs.eq(6);
            var dateElem = divs.eq(9);
        
            
            function isEmptyStep(){
                if(!scope.description && !scope.by  && !scope.date)
                    return true;
                return false;
            }

            scope.isStepsLessThanFive = function(){
                if(scope.numSteps < 5)
                    return true;
                return false;
            }



            scope.titleMouseover=function(num){

                if(!scope.isStepsLessThanFive()){
                    if(!isEmptyStep()){
                        if(num == 1 && scope.order%2 == 0){
                            scope.expandContentForBelow(.25);
                        }

                        if(num == 2 && scope.order%2 != 0){
                            scope.expandContentForAbove(.25);
                        }
                    }
                }
                
            };

            scope.titleMouseleave = function(num){
                if(scope.order%2 == 0){
                    scope.unhoveredStateForBelow(.25);
                }
                else{       
                    scope.unhoveredStateForAbove(.25);
                }
            };

            scope.initializeAboveForAnimation = function(){
                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.set(contentElem,{opacity:0});
                    animation.set(dateElem,{opacity:0});

                    if(!isEmptyStep()){
                        var yOffset = contentElem[0].offsetHeight + dateElem[0].offsetHeight;

                        animation.set(titleElem,{'top':yOffset });
                    }
                }
            };

            scope.expandContentForAbove = function(duration){

                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.to(titleElem,duration, {'top':0});
                    animation.to(contentElem,duration,{opacity:1});
                    animation.to(dateElem,duration,{opacity:1});
                }
                    
            };

            scope.unhoveredStateForAbove = function(duration){

                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.set(contentElem,{opacity:0});
                    animation.set(dateElem,{opacity:1});
                    var yOffset = contentElem[0].offsetHeight;
                    animation.to(titleElem,duration,{'top':yOffset});
                }
        
            };

            scope.initializeBelowForAnimation = function(){
                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.set(contentElem,{height:'0%',opacity:0, top:'-20px'});
                    animation.set(dateElem,{opacity:0});
                }  
            };

            scope.expandContentForBelow = function(duration){

                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.set(dateElem,{opacity:1});
                    animation.to(contentElem,duration,{ height:'auto',opacity:1, top:'0px'});   
                }
                
            };

            scope.unhoveredStateForBelow = function(duration){

                if(!scope.isStepsLessThanFive() && attTimelineCtrl.isAlternate()){
                    animation.to(contentElem,duration,{height:'0%',opacity:0, top:'-20px', position:'relative'});
                    animation.set(dateElem,{opacity:1});
                }
                
            };  

            /*
                Default Initializaztion
            */

            //If the info box is above and the description and date and by are empty then we have do reset its position
            if(isEmptyStep()){
                //IT has to be an alternating version for it to be above
                if(scope.order%2 != 0 && attTimelineCtrl.isAlternate())
                    infoboxElem.css('top', '-47px');
            }


            //Check if the order is odd and set the appropiate above or below and other effects
            //scope.isAboveInfoBoxShown = true;
            if(scope.order%2 == 0 || !attTimelineCtrl.isAlternate()){
                scope.isBelowInfoBoxShown=true;
            }
            else{               
                scope.isBelowInfoBoxShown=false;
            }

            //modify some css for steps less than 5 and not alternating
            if(scope.isStepsLessThanFive() && !attTimelineCtrl.isAlternate()){
                animation.set(dateElem,{marginTop:10});
            }

            //For IE 8 fix
            animation.set(biggerCircleElem,{opacity: '.5'});

            //shrink the expandableCircle to we can expand it later
            animation.set(expandableCircleElem, {opacity: '0.0'});
            animation.set(expandableCircleElem, {scale: .10});

            if(scope.order == 0){
                animation.set(expandableCircleElem, {opacity: '1.0'});
                animation.set(expandableCircleElem,{scale: 1});
                animation.set(biggerCircleElem,{scale:3});

                scope.isCurrentStep = true;
                scope.isInactive=false;
                scope.isCompleted = true;
            }

            scope.setColor = function(){
                scope.isInactive=false;
                if(scope.type == timelineConstants.STEP_TYPE.CANCELLED){
                    scope.isCancelled=true;
                }
                else if(scope.type == timelineConstants.STEP_TYPE.ALERT){
                    scope.isAlert=true;
                }
                else{
                    scope.isCompleted = true;
                }
                
                if(!scope.$phase)
                    scope.$apply();
            };

            scope.setSize = function(size){
                animation.set(biggerCircle,{scale:size});
            };

            scope.setExpandedCircle = function(){
                animation.set(expandableCircleElem, {opacity: '1.0'});
                animation.set(expandableCircleElem,{scale: 1});
            };

            scope.expandedAnimate = function(duration){
                animation.to(biggerCircleElem,duration,{scale:3});
                animation.set(expandableCircleElem, {opacity: '1.0'});
                animation.to(expandableCircleElem,duration,{scale: 1});
            };

            scope.shrinkAnimate = function(duration){
                animation.to(biggerCircleElem,duration,{scale:1});
            };
            
        }
    }
}]);
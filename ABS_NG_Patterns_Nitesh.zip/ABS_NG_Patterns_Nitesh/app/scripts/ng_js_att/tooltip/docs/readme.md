<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

These tooltips is used when the user might need additional information. These can be activated either by hovering over an element. The UX teams should decide which color is most appropriate for each scenario.The arrow should always be centered.

We can control various parameters like tooltip,tooltip-placement, tooltip-style,tooltip-popup-delay,tooltip-trigger using this directive.

#### `<Attribute level configuration for rendering tooltips>` ####

 * `tooltip`: It is just a tooltip directive name.
 
 * `tooltip-placement` : Where to place it? Defaults to "top", but also accepts "bottom", "left", "right". 
 
 * `tooltip-style`: Background color of the tooltip
 
 * `tooltip-popup-delay` : For how long should the user have to have the mouse over the element before the tooltip shows (in milliseconds)? Defaults to 0.
 
 * `tooltip-trigger` : What should trigger a show of the tooltip? `mouseenter`,`click`,`focus`,`blur`
 
 <br/><br/>

<p class="guideline-title">Red Lines</p>
<div class="guidelines-system-feedback-tooltip1"></div>

<div class="guidelines-system-feedback-tooltip2"></div>

<br/><br/>
<p class="guideline-title">Guidelines</p>   
 <ul class="guideline-description">
	<li>Use when an interaction with your website is not necessarily intuitive and self-explanatory.</li>
	<li>When the meaning or definition of an action is not necessarily intuitive and self-explanatory.</li>
	<li>Use to gently introduce functionality to the new and untrained user.</li>
	<li>Use when you want to guide the user to get a good start with a web application.</li>
</ul>
<ul class="guideline-description">
	<li>Use white tooltips for all elements in the website that are on a #F2F2F2 or colored background.</li>
	<li>Use dark tooltips only to describe the name of an action, such as icons.</li>
	<li>Use dark tooltips on tables, lists and tree-view UI.</li>
	<li>Use grey tooltips for all elements in the website that are on a #FFF background.</li>
</ul>



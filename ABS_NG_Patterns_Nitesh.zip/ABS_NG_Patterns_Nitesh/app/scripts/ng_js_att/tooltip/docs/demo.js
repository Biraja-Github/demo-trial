var tooltipController = function($scope) {
    $scope.color = {
        selectedColor : '#444'
    };
    $scope.tooltipColor='dark';

    $scope.$watch('color.selectedColor', function(val) {
        if (val === '#444') {
            $scope.tooltipColor='dark';
        }
        else if(val === '#fff'){
            $scope.tooltipColor='white';
        }
        else if(val === '#f2f2f2'){
            $scope.tooltipColor='grey';
        };
    });
};
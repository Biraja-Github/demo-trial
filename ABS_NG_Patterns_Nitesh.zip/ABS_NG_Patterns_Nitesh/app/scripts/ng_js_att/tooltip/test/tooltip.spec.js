describe('tooltip', function() {
    var elm,
            elmBody,
            scope,
            elmScope;

    // load the tooltip code
    beforeEach(module('att.abs.tooltip'));

    // load the template
    beforeEach(module('app/scripts/ng_js_att_tpls/tooltip/tooltip-popup.html'));

    beforeEach(inject(function($rootScope, $compile) {
        elmBody = angular.element('<a tooltip="Hello, I am a tooltip.">Text</a>');
        
        scope = $rootScope;
        $compile(elmBody)(scope);
        scope.$digest();
        elm = elmBody;
        elmScope = elm.scope();
    }));

    afterEach(function() {
        angular.element('[tooltip]').remove();
    });

    it('should not be open initially', inject(function() {
        expect(elmScope.tt_isOpen).toBe(false);

        // We can only test *that* the tooltip-popup element was created and append
        // to the body tag, instead of the element itself
        expect(elmBody.children().length).toBe(0);

        expect(document.getElementsByTagName('body')[0].getElementsByTagName('div').length).toBe(0);
    }));

    it('should open on mouseenter', inject(function() {
        elm.trigger('mouseenter');
        expect(elmScope.tt_isOpen).toBe(true);

        // We can only test *that* the tooltip-popup element was created and append
        // to the body tag, instead of the element itself
        expect(elmBody.children().length).toBe(0);

        expect(document.getElementsByTagName('body')[0].getElementsByTagName('div')[0].classList.contains('att-tooltip')).toBe(true);

    }));

    it('should close on mouseleave', inject(function() {
        elm.trigger('mouseenter');
        elm.trigger('mouseleave');
        expect(elmScope.tt_isOpen).toBe(false);
    }));

    it('should have default placement of "above"', inject(function() {
        elm.trigger('mouseenter');
        expect(elmScope.tt_placement).toBe("above");
    }));

    it('should have default style of "dark"', inject(function() {
        elm.trigger('mouseenter');
        expect(elmScope.tt_style).toBe("dark");
    }));

    it('should allow specification of placement', inject(function($compile) {
        elm = $compile(angular.element(
                '<a tooltip="Hello, I am a tooltip." tooltip-placement="below" >Text</a>'
                ))(scope);
        scope.$apply();
        elmScope = elm.scope();

        elm.trigger('mouseenter');
        expect(elmScope.tt_placement).toBe("below");
    }));

    it('should allow specification of style', inject(function($compile) {
        elm = $compile(angular.element(
                '<a tooltip="Hello, I am a tooltip." tooltip-style="white" >Text</a>'
                ))(scope);
        scope.$apply();
        elmScope = elm.scope();

        elm.trigger('mouseenter');
        expect(elmScope.tt_style).toBe("white");
    }));

    it('should work inside an ngRepeat', inject(function($compile) {

        elm = $compile(angular.element(
                '<ul>' +
                '<li ng-repeat="item in items">' +
                '<a tooltip="{{item.tooltip}}">{{item.name}}</span>' +
                '</li>' +
                '</ul>'
                ))(scope);

        scope.items = [
            {name: "One", tooltip: "First Tooltip"}
        ];

        scope.$digest();

        var tt = angular.element(elm.find("li > a")[0]);

        tt.trigger('mouseenter');

        expect(tt.text()).toBe(scope.items[0].name);
        expect(tt.scope().tt_content).toBe(scope.items[0].tooltip);

        tt.trigger('mouseleave');
    }));

    it('should not show tooltips if there is nothing to show', inject(function($compile) {

        elmBody = $compile(angular.element(
                '<a tooltip="">Selector Text</a>'
                ))(scope);
        scope.$digest();
        elmBody.trigger('mouseenter');

        expect(elmBody.scope().tt_isOpen).toBe(false);
    }));

    it('should close the tooltip when its trigger element is destroyed', inject(function() {
        elm.trigger('mouseenter');
        expect(elmScope.tt_isOpen).toBe(true);

        elm.remove();
        elmScope.$destroy();
        expect(elmScope.tt_isOpen).toBe(false);
    }));

    describe('with specified popup delay', function() {

        beforeEach(inject(function($compile) {
            scope.delay = '1000';
            elm = $compile(angular.element(
                    '<a tooltip="Hello, I am a tooltip." tooltip-popup-delay="{{delay}}">Text</a>'
                    ))(scope);
            elmScope = elm.scope();
            scope.$digest();
        }));

        it('should open after timeout', inject(function($timeout) {

            elm.trigger('mouseenter');
            expect(elmScope.tt_isOpen).toBe(false);

            $timeout.flush();
            expect(elmScope.tt_isOpen).toBe(true);

        }));

        it('should not open if mouseleave before timeout', inject(function($timeout) {
            elm.trigger('mouseenter');
            expect(elmScope.tt_isOpen).toBe(false);

            elm.trigger('mouseleave');
            $timeout.flush();
            expect(elmScope.tt_isOpen).toBe(false);
        }));

        it('should use default popup delay if specified delay is not a number', function() {
            scope.delay = 'text1000';
            scope.$digest();
            elm.trigger('mouseenter');
            expect(elmScope.tt_isOpen).toBe(true);
        });

    });

    describe('with a trigger attribute', function() {
        var scope, elmBody, elm, elmScope;

        beforeEach(inject(function($rootScope) {
            scope = $rootScope;
        }));

        it('should use it to show but set the hide trigger based on the map for mapped triggers', inject(function($compile) {
            elmBody = angular.element(
                    '<input tooltip="Hello, I am a tooltip." tooltip-trigger="focus" />'
                    );
            $compile(elmBody)(scope);
            scope.$apply();
            elm = elmBody;
            elmScope = elm.scope();

            expect(elmScope.tt_isOpen).toBeFalsy();
            elm.trigger('focus');
            expect(elmScope.tt_isOpen).toBeTruthy();
            elm.trigger('blur');
            expect(elmScope.tt_isOpen).toBeFalsy();
        }));

        it('should use it as both the show and hide triggers for unmapped triggers', inject(function($compile) {
            elmBody = angular.element(
                    '<input tooltip="Hello, I am a tooltip." tooltip-trigger="fakeTriggerAttr" />'
                    );
            $compile(elmBody)(scope);
            scope.$apply();
            elm = elmBody;
            elmScope = elm.scope();

            expect(elmScope.tt_isOpen).toBeFalsy();
            elm.trigger('fakeTriggerAttr');
            expect(elmScope.tt_isOpen).toBeTruthy();
            elm.trigger('fakeTriggerAttr');
            expect(elmScope.tt_isOpen).toBeFalsy();
        }));

        it('should not share triggers among different element instances', inject(function($compile) {

            elmBody = angular.element(
                    '<div>' +
                    '<input tooltip="Hello!" tooltip-trigger="mouseenter" />' +
                    '<input tooltip="Hello!" tooltip-trigger="click" />' +
                    '</div>'
                    );

            $compile(elmBody)(scope);
            scope.$apply();
            var elm1 = elmBody.find('input').eq(0);
            var elm2 = elmBody.find('input').eq(1);
            var elmScope1 = elm1.scope();
            var elmScope2 = elm2.scope();


            elm1.trigger('mouseenter');
            expect(elmScope1.tt_isOpen).toBeTruthy();
            elm1.trigger('mouseleave');
            elm1.click();
            expect(elmScope1.tt_isOpen).toBeFalsy();

            elm2.trigger('mouseenter');
            expect(elmScope2.tt_isOpen).toBeFalsy();
            elm2.trigger('mouseleave');
            elm2.click();
            expect(elmScope2.tt_isOpen).toBeTruthy();

        }));
    });

});

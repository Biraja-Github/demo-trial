angular.module('att.abs.tooltip', ['att.abs.position', 'att.abs.utilities', 'ngSanitize'])
        
        // The default options tooltip and popover.
        .constant('tooltipDefaultOptions', {
            placement: 'above',
            animation: false,
            popupDelay: 0,
            stylett: 'dark',
            appendToBody: true
        })
        
        /**
         * The $tooltip service creates tooltip- and popover-like directives as well as
         * houses global options for them.
         */
        .provider('$tooltip', ['tooltipDefaultOptions', function(tooltipDefaultOptions) {

            // Default hide triggers for each show trigger
            var triggerMap = {
                'mouseenter': 'mouseleave',
                'click': 'click',
                'focus': 'blur',
                'mouseover':'mouseout'
            };

            // The options specified to the provider globally.
            var globalOptions = {};

            this.options = function(value) {
                angular.extend(globalOptions, value);
            };

            /**
             * This allows you to extend the set of trigger mappings available. E.g.:
             *
             *   $tooltipProvider.setTriggers( 'openTrigger': 'closeTrigger' );
             */
            this.setTriggers = function setTriggers(triggers) {
                angular.extend(triggerMap, triggers);
            };

            /**
             * This is a helper function for translating camel-case to snake-case.
             */
            function snake_case(name) {
                var regexp = /[A-Z]/g;
                var separator = '-';
                return name.replace(regexp, function(letter, pos) {
                    return (pos ? separator : '') + letter.toLowerCase();
                });
            }

            /**
             * Returns the actual instance of the $tooltip service.
             */
            this.$get = ['$window', '$compile', '$timeout', '$parse', '$document', '$position', '$interpolate', function($window, $compile, $timeout, $parse, $document, $position, $interpolate) {
                    return function $tooltip(type, prefix, defaultTriggerShow) {
                        var options = angular.extend({}, tooltipDefaultOptions, globalOptions);
                        
                        /**
                         * Returns an object of show and hide triggers.
                         *
                         * If a trigger is supplied,
                         * it is used to show the tooltip; otherwise, it will use the `trigger`
                         * option passed to the `$tooltipProvider.options` method; else it will
                         * default to the trigger supplied to this directive factory.
                         *
                         * The hide trigger is based on the show trigger. If the `trigger` option
                         * was passed to the `$tooltipProvider.options` method, it will use the
                         * mapped trigger from `triggerMap` or the passed trigger if the map is
                         * undefined; otherwise, it uses the `triggerMap` value of the show
                         * trigger; else it will just use the show trigger.
                         */
                        function getTriggers(trigger) {
                            var show = trigger || options.trigger || defaultTriggerShow;
                            var hide = triggerMap[show] || show;
                            return {
                                show: show,
                                hide: hide
                            };
                        }

                        var directiveName = snake_case(type);

                        var startSym = $interpolate.startSymbol();
                        var endSym = $interpolate.endSymbol();
                        var template =
                                '<div ' + directiveName + '-popup ' +
                                'title="' + startSym + 'tt_title' + endSym + '" ' +
                                'content="' + startSym + 'tt_content' + endSym + '" ' +
                                'placement="' + startSym + 'tt_placement' + endSym + '" ' +
                                'animation="tt_animation()" ' +
                                'is-open="tt_isOpen" ' +
                                'stylett="' + startSym + 'tt_style' + endSym + '" ' +
                                '>' +
                                '</div>';
                               
                        return {
                            restrict: 'EA',
                            scope: true,
                            link: function link(scope, element, attrs) {

                                element.attr("tabindex", "0");
                                element.bind('mouseenter', function(){
                                    element.removeAttr("title");
                                });
                                element.bind('mouseleave', function(){
                                    element.attr("title", scope.tt_content);
                                });

                                var tooltip = $compile(template)(scope);
                                var transitionTimeout;
                                var popupTimeout;
                                var $body;
                                var appendToBody = angular.isDefined(options.appendToBody) ? options.appendToBody : false;
                                var triggers = getTriggers(undefined);
                                var hasRegisteredTriggers = false;
                                var hasEnableExp = angular.isDefined(attrs[prefix + 'Enable']);

                                // By default, the tooltip is not open.
                                // TODO add ability to start tooltip opened
                                scope.tt_isOpen = false;
                                
                                //Adding a scope watch, to remove the created popup from DOM, incase it is updated outside the provider code.
                                scope.$watch('tt_isOpen', function(newVal, oldVal){
                                    if(newVal !== oldVal){
                                       if( newVal === false ){
                                           // remove code
                                           tooltip.remove();
                                       }
                                    }
                                });

                                function toggleTooltipBind() {
                                    if (!scope.tt_isOpen) {
                                        showTooltipBind();
                                    } else {
                                        hideTooltipBind();
                                    }
                                }

                                // Show the tooltip with delay if specified, otherwise show it immediately
                                function showTooltipBind() {
                                    tooltip = $compile(template)(scope);
                                    scope.$digest();
                                    if (hasEnableExp && !scope.$eval(attrs[prefix + 'Enable'])) {
                                        return;
                                    }
                                    if (scope.tt_popupDelay) {
                                        popupTimeout = $timeout(show, scope.tt_popupDelay);
                                    } else {
                                        scope.$apply(show);
                                    }
                                }

                                function hideTooltipBind() {
                                    scope.$apply(function() {
                                        hide();
                                    });
                                }

                                // Show the tooltip popup element.
                                function show() {
                                    var position,
                                            ttWidth,
                                            ttHeight,
                                            ttPosition;

                                    // Don't show empty tooltips.
                                    if (!scope.tt_content) {
                                        return;
                                    }

                                    // If there is a pending remove transition, we must cancel it, lest the
                                    // tooltip be mysteriously removed.
                                    if (transitionTimeout) {
                                        $timeout.cancel(transitionTimeout);
                                    }

                                    // Set the initial positioning.
                                    tooltip.css({top: 0, left: 0, display: 'block', 'z-index': 999});

                                    // Now we add it to the DOM because need some info about it. But it's not 
                                    // visible yet anyway.
                                    
                                    if (appendToBody) {
                                        $body = $body || $document.find('body');
                                        $body.append(tooltip);
                                    } else {
                                        element.after(tooltip);
                                    }

                                    // Get the position of the directive element.
                                    position = appendToBody ? $position.offset(element) : $position.position(element);
//                                    alert(JSON.stringify(position));
                                    
                                    // Get the height and width of the tooltip so we can center it.
                                    ttWidth = tooltip.prop('offsetWidth');
                                    ttHeight = tooltip.prop('offsetHeight');

                                    // Calculate the tooltip's top and left coordinates to center it with
                                    // this directive.
                                    var ttArrowOffset = 10;

                                    switch (scope.tt_placement) {
                                        case 'right':
                                            if(appendToBody){
                                                ttPosition = {
                                                    top: position.top + position.height / 2 - ttHeight / 2,
                                                    left: position.left + position.width
                                                };
                                            }else{
                                                ttPosition = {
                                                    top: position.top + position.height / 2 - ttHeight / 2,
                                                    left: position.left + position.width + ttArrowOffset
                                                };
                                            }
                                            break;
                                        case 'below':
                                            if(appendToBody){
                                                ttPosition = {
                                                    top: position.top + position.height,
                                                    left: position.left + position.width / 2 - ttWidth / 2
                                                };
                                            }else{
                                                ttPosition = {
                                                    top: position.top + position.height + ttArrowOffset,
                                                    left: position.left + position.width / 2 - ttWidth / 2
                                                };
                                            }
                                            break;
                                        case 'left':
                                            if(appendToBody){
                                                ttPosition = {
                                                    top: position.top + position.height / 2 - ttHeight / 2,
                                                    left: position.left - ttWidth
                                                };
                                            }else{
                                                ttPosition = {
                                                    top: position.top + position.height / 2 - ttHeight / 2,
                                                    left: position.left - ttWidth - ttArrowOffset
                                                };
                                            }
                                            break;
                                        default:
                                            if(appendToBody){
                                                ttPosition = {
                                                    top: position.top - ttHeight,
                                                    left: position.left + position.width / 2 - ttWidth / 2
                                                };
                                            }else{
                                                ttPosition = {
                                                    top: position.top - ttHeight - ttArrowOffset,
                                                    left: position.left + position.width / 2 - ttWidth / 2
                                                };
                                            }
                                            break;
                                    }

                                    ttPosition.top += 'px';
                                    ttPosition.left += 'px';

                                    // Now set the calculated positioning.
                                    tooltip.css(ttPosition);

                                    // And show the tooltip.
                                    scope.tt_isOpen = true;
                                }

                                // Hide the tooltip popup element.
                                function hide() {
                                    // First things first: we don't show it anymore.
                                    scope.tt_isOpen = false;

                                    //if tooltip is going to be shown after delay, we must cancel this
                                    $timeout.cancel(popupTimeout);

                                    // And now we remove it from the DOM. However, if we have animation, we 
                                    // need to wait for it to expire beforehand.
                                    // FIXME: this is a placeholder for a port of the transitions library.
                                    if (angular.isDefined(scope.tt_animation) && scope.tt_animation()) {
                                        transitionTimeout = $timeout(function() {
                                            tooltip.remove();
                                        }, 500);
                                    } else {
                                        tooltip.remove();
                                    }
                                }

                                /**
                                 * Observe the relevant attributes.
                                 */
                                attrs.$observe(type, function(val) {
                                    if (val) {
                                        scope.tt_content = val;
                                        element.attr('title',val);
                                    } else {
                                        if (scope.tt_isOpen) {
                                            hide();
                                        }
                                    }
                                });

                                attrs.$observe(prefix + 'Title', function(val) {
                                    scope.tt_title = val;
                                });

                                attrs.$observe(prefix + 'Placement', function(val) {
                                    scope.tt_placement = angular.isDefined(val) ? val : options.placement;
                                });
                                
                                attrs.$observe(prefix + 'Style', function(val) {
                                    scope.tt_style = angular.isDefined(val) ? val : options.stylett;
                                });

                                attrs.$observe(prefix + 'Animation', function(val) {
                                    scope.tt_animation = angular.isDefined(val) ? $parse(val) : function() {
                                        return options.animation;
                                    };
                                });

                                attrs.$observe(prefix + 'PopupDelay', function(val) {
                                    var delay = parseInt(val, 10);
                                    scope.tt_popupDelay = !isNaN(delay) ? delay : options.popupDelay;
                                });

                                attrs.$observe(prefix + 'Trigger', function(val) {

                                    if (hasRegisteredTriggers) {
                                        element.unbind(triggers.show, showTooltipBind);
                                        element.unbind(triggers.hide, hideTooltipBind);
                                    }

                                    triggers = getTriggers(val);

                                    if (triggers.show === triggers.hide) {
                                        element.bind(triggers.show, toggleTooltipBind);
                                    } else {
                                        element.bind(triggers.show, showTooltipBind);
                                        element.bind(triggers.hide, hideTooltipBind);
                                    }

                                    hasRegisteredTriggers = true;
                                });

                                attrs.$observe(prefix + 'AppendToBody', function(val) {
                                    appendToBody = angular.isDefined(val) ? $parse(val)(scope) : appendToBody;
                                });

                                // if a tooltip is attached to <body> we need to remove it on
                                // location change as its parent scope will probably not be destroyed
                                // by the change.
                                if (appendToBody) {
                                    scope.$on('$locationChangeSuccess', function closeTooltipOnLocationChangeSuccess() {
                                        if (scope.tt_isOpen) {
                                            hide();
                                        }
                                    });
                                }

                                // Make sure tooltip is destroyed and removed.
                                scope.$on('$destroy', function onDestroyTooltip() {
                                    if (scope.tt_isOpen) {
                                        hide();
                                    } else {
                                        tooltip.remove();
                                    }
                                });
                            }
                        };
                    };
                }];
        }])

        .directive('tooltipPopup', ['$document', '$documentBind', function($document, $documentBind) {
            return {
                restrict: 'EA',
                replace: true,
                transclude: true,
                scope: {content: '@', placement: '@', animation: '&', isOpen: '=', stylett: '@'},
                templateUrl: 'app/scripts/ng_js_att_tpls/tooltip/tooltip-popup.html',
                link: function(scope, elem, attr, ctrl) {
                    var flag = false;
                    
                    scope.$watch("isOpen", function(value) {
                        flag = scope.isOpen;
                    });
                    
                    elem.bind('click', function (e) {
                        e.stopPropagation();
                    });
                    
                    var outsideClick = function(e) {
                        if (!flag) {
                            scope.$apply(function() {
                                scope.isOpen = false;
                            });
                        }
                        flag = false;
                    };

                    $documentBind.click('isOpen', outsideClick, scope);
                }
            };
        }])

        .directive('tooltip', ['$tooltip', function($tooltip) {
            return $tooltip('tooltip', 'tooltip', 'mouseenter');
        }])

        .directive('tooltipCondition', [ '$timeout',function($timeout) {
                return  {
                    restrict: 'EA',
                    replace: true,
                    scope:{
                        tooltipCondition:"@?"
                    },
                    template:'<p><span tooltip=\"{{tooltipCondition}}\" ng-if=\"showpop\">{{tooltipCondition}}</span><span id=\"innerElement\" ng-hide=\"showpop\">{{tooltipCondition}}</span></p>',
                    link: function(scope, elem, attr){
                        scope.showpop=false;
                        if(attr.height==='true'){
                            $timeout(function () {
                                var maxHeight=(elem[0].offsetHeight);
                               var elemHeight=elem.children(0)[0].offsetHeight;
                               if(elemHeight > maxHeight){
                                   scope.showpop=true;
                               }
                            },1000);
                        }
                        else if(scope.tooltipCondition.length>=25){
                        scope.showpop=true;
                        }

                    }
                };
        }]);

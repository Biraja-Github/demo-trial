<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **Toggle Switch directive** is simple "Yes/No" or "On/Off" scenarios, a toggle switch may be used.
N.B. Please add gestures.js as dependency in your index.html to make it Draggable

We can control various parameters like att-toggle-main,ng-model, ng-true-value, ng-false-value using this directive.

#### `<Attribute level configuration for rendering tags>` ####

 * `att-toggle-main`: The attr flag to render the toggle of small size. No values required.
 
 * `att-toggle-main = "large"` : The attr flag to render the toggle of large size. No values required.
 
 * `ng-model`: The attr serves model value.
 
 * `ng-true-value` : The attr will return true value text.
 
 * `ng-false-value` : The attr will return false value text.
    
      

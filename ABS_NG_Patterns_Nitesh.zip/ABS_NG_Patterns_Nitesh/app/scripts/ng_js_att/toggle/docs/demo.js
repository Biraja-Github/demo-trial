var toggleController = function($scope) {
        
        $scope.toggleValue =
                {
                    "On": true,
                    "Off": false
                };
       
        $scope.toggleValueOn =
                {
                    "On": "on",
                    "Off": "off"
                };
        $scope.toggleValueLarge =
                {
                    "On": true,
                    "Off": false
                };
        $scope.toggleValueLargeOn =
                {
                    "On": "on",
                    "Off": "off"
                };
    };



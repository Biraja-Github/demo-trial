angular.module('att.abs.toggle', ['angular-gestures', 'att.abs.position'])
        .directive('attToggleTemplate', ['$compile', '$log', '$position','$timeout',  function($compile, $log, $position, $timeout)
            {
                return{
                    restrict: 'A',
                    require: 'ngModel',
                    transclude: true,
                    scope: {
                        modelVal: "=ngModel"
                    },
                    templateUrl: 'app/scripts/ng_js_att_tpls/toggle/demoToggle.html',
                    link: function(scope, element, attr, ctrl) {
                        var ngCtrl = ctrl;
                        scope.initialDragPosition = 0;
                        var dragStatus = 0;
                        var container = element[0];
                        var content = element[0].querySelector('.att-switch__content');
                        var labels = element[0].querySelector('.att-switch__on-label');
                        
                        var containerWidth = element[0].clientWidth;
                        var contentWidth = element[0].querySelector('.att-switch__content').clientWidth;
                        var labelsWidth = element[0].querySelector('.att-switch__on-label').clientWidth;
                        var min = (labelsWidth * -1) + 1;
                        var minPx = min +'px';
                        scope.drag = function(e) {
                            var self = this;
                            dragStatus = 1;
                            if (e.type === 'dragstart') {
                                scope.initialDragPosition = $position.position(element.children().eq(1).children()).left;     
                                element.children().eq(1).children().addClass('att-switch--dragging');
                            } else if (e.type === 'drag') {                                
                                var left = Math.min(0, Math.max(scope.initialDragPosition + e.gesture.deltaX, min));
                                element.children().eq(1).children().css({
                                    left: left + 'px'
                                });
                            } else if (e.type === 'dragend') {
                                element.children().eq(1).children().removeClass('att-switch--dragging');
                                var isOn = $position.position(element.children().eq(1).children()).left + (contentWidth / 3 * 1.5) > containerWidth / 2; 
                                TweenMax.to(element.children().eq(1).children(), .1, {left: isOn ? 0 : min, ease: Power4.easeOut, onComplete: function(){element.children().eq(1).children().css({left: ''}) } });
                            if(isOn === true){
                                updateModelVal();
                            }
                            else if(isOn === false && e.gesture.direction === "left"){
                                updateModelVal();
                            }                             
                            dragStatus = 0;
                            }

                            return false;
                        };

                        scope.directiveValue = attr.attToggleTemplate;
                        scope.on = attr.trueValue;
                        scope.off = attr.falseValue;
                        scope.$watch('modelVal', function(newVal) {
                            scope.attrValue = newVal;
                            if (newVal === attr.ngTrueValue || newVal === true) {
                                element.children().eq(1).children().css({
                                    left : '0px'
                                });
                                element.addClass('att-checkbox--on');                                
                                
                            } else {
                                element.children().eq(1).children().css({
                                    left : minPx
                                });
                                element.removeClass('att-checkbox--on'); 
                                
                            };
                            element.children().eq(1).children().css({ 
                                    left: '' 
                                });
                        });
                        
                        var updateModelVal = function() {
                            if (scope.attrValue === attr.ngTrueValue || scope.attrValue === true)
                            {
                                scope.modelVal = false;
                                scope.$apply();
                            }
                            else
                            {
                                scope.modelVal = true;
                                scope.$apply();
                            }
                        };
                        element.bind('click', function()
                        {
                               if (dragStatus !== 1) {
                                updateModelVal();
                                dragStatus = 0;
                            }
                        });

                        
                    }
                };
            }

        ])
        
        .directive('attToggleMain', ['$compile', '$log', function($compile, $log)
            {
                return{
                    restrict: 'A',
                    require: 'ngModel',
                    transclude: true,
                    controller: 'toggleController',
                    replace: true,
                    scope: {
                        modelValue: "=ngModel",
                        trueValue: "=ngTrueValue",
                        falseValue: "=ngFalseValue"
                    },
                    link: function(scope, element, attr, ctrl) {
                        var ngCtrl = ctrl;
                        var html = "";
                        var attrVal = "";
                        element.removeAttr('att-toggle-main');
                        scope.on = attr.ngTrueValue;
                        scope.off = attr.ngFalseValue;
                        scope.largeValue = attr.attToggleMain;
                        if (angular.isDefined(attr.ngTrueValue)) {
                            html += ' true-value="{{on}}" false-value="{{off}}"';
                        }                        
                        if (scope.largeValue !== undefined)
                        {
                            attrVal += ' ="{{largeValue}}"';
                        }

                        var elm = angular.element('<div class="att-switch"  ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="modelValue"' + html + ' att-toggle-template' + attrVal + '>' + element.prop('outerHTML') + '</div>');
                        elm = $compile(elm)(scope);
                        element.replaceWith(elm);
                    }
                };
            }]
                );
        
        
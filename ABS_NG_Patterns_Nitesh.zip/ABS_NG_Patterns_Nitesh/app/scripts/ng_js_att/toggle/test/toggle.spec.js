describe('toggle', function() {

    var $scope, $compile;
    beforeEach(module('att.abs.toggle'));
    beforeEach(module('att.abs.position'));
    beforeEach(module('app/scripts/ng_js_att_tpls/toggle/demoToggle.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));

    var compileElement = function(markUp, scope) {
        var elm = $compile(markUp)(scope);
        scope.$digest();
        return elm;
    }
    var html = "";
    var attrVal = "";

    it('should be checked when the model value is true', function() {
        $scope.toggleValue = {
            "On": true
        };
        $scope.$digest();        
        var toggle = compileElement('<div class="att-switch ng-scope ng-isolate-scope ng-pristine ng-valid att-switch--icons" ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="toggleValue.On" att-toggle-template=""></div>', $scope);       
        expect(toggle).toHaveClass('att-checkbox--on');
    });

    it('should be not be checked when the model value is false', function() {
        $scope.toggleValue = {
            "Off": false
        };
        $scope.$digest();
        var toggle = compileElement('<div class="att-switch ng-scope ng-isolate-scope ng-pristine ng-valid att-switch--icons" ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="toggleValue.Off" att-toggle-template=""></div>', $scope);       
        expect(toggle).not.toHaveClass('att-checkbox--on');
    });

    it('should toggle the value on click', function() {
        $scope.toggleValue = {
            "On": true
        };
        $scope.$digest();        
        var toggle = compileElement('<div class="att-switch ng-scope ng-isolate-scope ng-pristine ng-valid att-switch--icons" ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="toggleValue.On" att-toggle-template=""></div>', $scope);       
        expect(toggle).toHaveClass('att-checkbox--on');
        toggle.click();
        expect($scope.toggleValue.On).toEqual(false);
        expect(toggle).not.toHaveClass('att-checkbox--on');

        $scope.toggleValue = {
            "On": false
        };
        $scope.$digest();
        toggle.click();
        expect($scope.toggleValue.On).toEqual(true);
        expect(toggle).toHaveClass('att-checkbox--on');
    });


    it('should show the correct message on the display which passed through ng-true-value and ng-false-value', function() {
        $scope.yes = 'on';
        $scope.no = 'off';
        $scope.$digest();
        var toggle = compileElement('<div class="att-switch ng-scope ng-isolate-scope ng-pristine ng-valid" ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="toggleValueOn.On" true-value="on" false-value="off" att-toggle-template="">', $scope);      
        expect(toggle.find('.att-switch__on-label').text()).toBe($scope.yes);
        expect(toggle.find('.att-switch__off-label').text()).toBe($scope.no);
    });

    it('the icon should be large when the directive attribute value is passed as large', function() {
        $scope.attToggleTemplate = "large";
        $scope.$digest();
        var toggle = compileElement('<div class="att-switch ng-scope ng-isolate-scope ng-pristine ng-valid att-switch--icons att-switch--large" ng-class="{\'att-switch--large\' : largeValue == \'large\',\'att-switch--icons\' : on === undefined}" ng-model="toggleValue.On" att-toggle-template="large"></div>', $scope);
        expect(toggle).toHaveClass('att-switch--large');       
    });
});



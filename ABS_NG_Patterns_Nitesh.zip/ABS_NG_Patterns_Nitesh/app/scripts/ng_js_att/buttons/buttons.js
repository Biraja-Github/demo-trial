angular.module('att.abs.buttons', ['att.abs.position', 'att.abs.utilities'])
.directive('attButton', [function () {
    return {
        priority: -100, //-100 to ensure we get first click
        restrict: 'A',
        scope: {
            size: '@',
            directional:'@'
        },
        link: function (scope, element, attrs, ctrl) {
            element.addClass('button');
            var disabled = false;

            if (scope.size == 'small') {
                element.addClass('button--small');
            }
            if (scope.directional == 'true') {
                element.addClass('button--directional');
            }
            attrs.$observe('btnType', function(value) {
                if (value == 'primary') {
                    element.addClass('button--primary');
                    element.removeClass('button--secondary');
                    element.removeClass('button--disabled');
                } else if (value == 'secondary') {
                    element.addClass('button--secondary');
                    element.removeClass('button--primary');
                    element.removeClass('button--disabled');
                } else if (value == 'disabled') {
                    element.addClass('button--disabled');
                    element.removeClass('button--primary');
                    element.removeClass('button--secondary');
                    disabled = true;
                }
            });
            element.attr("tabindex", "0");

            element.bind("click", function($event){
                if (disabled)
                {
                    $event.stopImmediatePropagation();
                    return false;
                }
            });
        }
    };
}])
.directive('attButtonLoader', [function () {
    return {
        restrict: 'A',
        replace: false,
        scope: {
            size: '@'
        },
        template: '<div class="loading"><div class="loading__inside"></div></div>',
        link: function (scope, element, attrs, ctrl) {
            if (scope.size=="small"){
                element.addClass('button button--disabled button-primary button--loading button--small');
            }
            else{
                element.addClass('button button--disabled button-primary button--loading');
            }
        }
    };
}]).directive('attButtonHero', [function () {
    return {
        restrict: 'A',
        replace: false,
        transclude: true,
        scope: {
            icon: '@',
            btnType:'@'
        },
        template: '<div class="button--hero__inner"><span ng-transclude></span> <i ng-class="{\'icon-arrow-right\': icon === \'arrow-right\',\'icon-cart\': icon === \'cart\'}"></i></div>',
        link: function (scope, element, attrs, ctrl) {
            element.addClass('button button--hero');
            if(scope.btnType=='disabled')
            element.addClass('button--disabled');
            element.attr("tabindex", "0");
        }
    };
}]).directive('attBtnDropdown',['$document', '$isElement', '$documentBind', function($document, $isElement, $documentBind){
       return {
            restrict: 'EA',
            transclude:true,
            scope:{
                type: "@dropdowntype"
            },
            replace: true,
            template: '<div class="att-btn-dropdown"> <div class="buttons-dropdown--small btn-group" ng-class="{\'open\': isOpen}" ng-click="toggleDropdown($event)"> <button class="button button--secondary button--small buttons-dropdown__drop dropdown-toggle ng-isolate-scope" ng-if="type==\'dots\'"> <div class="circle" ng-click="toggleDropdownCircle($event)"></div> <div class="circle" ng-click="toggleDropdownCircle($event)"></div> <div class="circle" ng-click="toggleDropdownCircle($event)"></div> </button> <button class="button button--secondary button--small buttons-dropdown__drop dropdown-toggle ng-isolate-scope actions-title" ng-if="type==\'actions\'"> Actions </button> <ul ng-class="{\'dropdown-menu dots-dropdwn\':type==\'dots\', \'dropdown-menu actions-dropdwn\':type==\'actions\'}" role="menu"> <div ng-transclude> </div> </ul> </div></div>',
            link: function(scope,element,attrs){

                scope.isOpen = false;

                var toggle = scope.toggle = function (show) {
                    if(show === true || show === false) {
                        scope.isOpen = show;
                    } else {
                        scope.isOpen = !scope.isOpen;
                    }
                };

                scope.toggleDropdownCircle = function($event){
                    toggle(false);
                };

                scope.toggleDropdown = function($event){
                    toggle();
                };

                var outsideClick = function (e) {
                    var isElement = $isElement(angular.element(e.target), element, $document);
                    if(!isElement) {
                        toggle(false);
                        scope.$apply();
                    }
                };

                $documentBind.click('isOpen', outsideClick, scope);
            }
        };
}]);

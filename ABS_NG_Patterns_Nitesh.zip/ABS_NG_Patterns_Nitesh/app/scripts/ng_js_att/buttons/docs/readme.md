<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button directive** is built using angular library.
This can be used for rendering various buttons in an application.

We can control various parameters like size, directional, btn-type(primary,disabled)
while using this directive.

#### `<Attribute level configuration for rendering buttons>` ####

 * `size`
 	:
 	The attr with value small to render the Button of small size.

 * `directional`
 	:
 	The attr to indicate an directional arrow on Button.
 
 * `btn-type`
 	:
 	The attr to indicate the type of Button. disabled,secondary.

 * `on-close`
 	:
 	The attr is used for directional buttons when value is made true.

<br/><br/>

<p class="guideline-title">Red Lines</p>
<br/><br/>
<div class="guidelines-button-large"></div>
<br/><br/>
<div class="guidelines-button-small"></div>

<br/><br/>

<p class="guideline-title">GUIDELINES</p>
<ul class="guideline-description">
    <li>Buttons copy is always presented in sentence case.</li>
</ul>

<br/><br/>

<p class="guideline-title">TEXT FORMAT</p>
<p class="guideline-description">Large size : <span class="guideline-description--gray">Clearview Book 18px</span><br/>Small size : <span class="guideline-description--gray">Clearview Book 14px</span></p>


<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button directive** is built using angular library.
This can be used for rendering various buttons in an application.

We can control various parameters like size, directional, btn-type(disabled,secondary)
while using this directive.

#### `<Attribute level configuration for rendering buttons>` ####

 * `size`
 	:
 	The attr with value small to render the Button of small size.

 * `btn-type`
 	:
 	The attr to indicate the type of Button. disabled,secondary.

* `directional`
 	:
 	The attr to indicate an directional arrow on Button.

 * `on-close`
 	:
 	The attr is used for directional buttons when value is made true.

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button** is built using angular library.
This can be used for rendering various color buttons in an application.

We can control various parameters like size, directional, btn-type(primary,disabled,secondary) while using this directive.

#### `<Attribute level configuration for rendering color buttons>` ####

 * `size`
 	:
 	The attr with value small to render the Button of small size.

 * `btn-type`
 	:
 	The attr to indicate the type of Buton. primary,disabled,secondary.
	
* `directional`
 	:
 	The attr is used for directional buttons when value is made true.	

<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-button-hero directive** is built using angular library.
This can be used for rendering cart buttons i.e. `checkout` and `buy`

We can control various parameters like icon, btn-type(disabled) while using this directive.

#### `<Attribute level configuration for rendering buttons>` ####

 * `icon`
 	:
 	The attr is used to indicate an icon on the button.

 * `btn-type`
 	:
 	The attr to indicate the type of Buton. primary,disabled,secondary.


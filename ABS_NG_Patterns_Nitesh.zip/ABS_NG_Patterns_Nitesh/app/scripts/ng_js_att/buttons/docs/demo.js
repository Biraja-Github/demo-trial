//ABSSBA
 var AbsButtonsCtrl = function($scope, $http) {
    $scope.primaryBtn = [{'title':'Default','id':'resetId'},{'title':'Disabled','id':'disableId'},{'title':'Directional','id':'directionalId'},{'title':'Loading','id':'loaderId'}];  
    $scope.secBtn = [{'title': 'Default', 'id': 'resetSecId'}, {'title': 'Disabled', 'id': 'disableSecId'},
        {'title': 'Directional', 'id': 'directionalSecId'}, {'title': 'Loading', 'id': 'loaderSecId'}];

    $scope.primaryBtn.id = 'resetId';
        $scope.secBtn.id = 'resetSecId'; 
 };
 //ABSSBA
 var AbsButtonsCtrl = function($scope, $http) {
    $scope.primaryBtn = [{'title':'Default','id':'resetId'},{'title':'Disabled','id':'disableId'},{'title':'Directional','id':'directionalId'},{'title':'Loading','id':'loaderId'}];  
    $scope.secBtn = [{'title': 'Default', 'id': 'resetSecId'}, {'title': 'Disabled', 'id': 'disableSecId'},
        {'title': 'Directional', 'id': 'directionalSecId'}, {'title': 'Loading', 'id': 'loaderSecId'}];

    $scope.primaryBtn.id = 'resetId';
    $scope.secBtn.id = 'resetSecId'; 
 };
 //ABSSBA
 var AbsColorButtonsCtrl = function($scope, $http) {
    $scope.bgColorClass = 'bg-dark-gray';
    $scope.colorsItem = [];
    $scope.colorClass = [];
    $http.get('data/colors.json').success(function(data) {
        var obj = data;
        for (var key in obj) {
            if (key !== 'dividers') {
                var colorObj = obj[key];
                for (var cKey in colorObj) {
                    var color = (colorObj[cKey].color);
                    var title = (colorObj[cKey].title);
                    var name = (colorObj[cKey].name);
                    $scope.colorsItem.push({'color': color, 'title': title});
                    $scope.colorClass[colorObj[cKey].color] = {'color': color,
                        'colorClass': name
                    };
                    var cItemObj = $scope.colorClass;
                    $scope.$watch('selected', function(val) {
                        for (var key in cItemObj) {
                            if (val == key) {
                                $scope.bgColorClass = cItemObj[key].colorClass;
                            }
                        }
                    });
                }
            }
        }
    });    
	 $scope.secBtnColor = [{'title':'Default','id':'resetId'},{'title':'Disabled','id':'disableId'},{'title':'Directional','id':'directionalId'},{'title':'Loading','id':'loaderId'}];
	$scope.secBtnColor.id = 'resetId';
 };
 //ABSSBA
  var AbsBuyButtonsCtrl = function($scope, $http) {
	$scope.cartBtn = [{'title':'Default','id':'cartResetId'},{'title':'Disabled','id':'cartDisableId'},{'title':'Loading','id':'cartLoaderId'}];
    $scope.checkOutBtn = [{'title':'Default','id':'resetId'},{'title':'Disabled','id':'disableId'},{'title':'Loading','id':'loaderId'}];

    $scope.cartBtn.id = 'cartResetId';
    $scope.checkOutBtn.id = 'resetId';
    
 };
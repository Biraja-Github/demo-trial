describe('Unit Test: Buttons', function() {
    var scope, compile;
    beforeEach(module('att.abs.buttons'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));

    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };

    it("should render primary button ", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="primary">Primary</a>');
        expect(elem).toHaveClass('button');
        expect(elem).toHaveClass('button--primary');
        expect(elem).not.toHaveClass('button--small');
    });

    it("should render small primary button", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="primary" size="small">Primary</a>');
        expect(elem).toHaveClass('button');
        expect(elem).toHaveClass('button--primary');
        expect(elem).toHaveClass('button--small');
    });

    it("should render secondary button ", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="secondary">Secondary</a>');
        expect(elem).toHaveClass('button');
        expect(elem).toHaveClass('button--secondary');
        expect(elem).not.toHaveClass('button--small');
    });

    it("should render small secondary button", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="secondary" size="small">Secondary</a>');
        expect(elem).toHaveClass('button');
        expect(elem).toHaveClass('button--secondary');
        expect(elem).toHaveClass('button--small');
    });

    it("should render large loader button", function() {
        var elem = compileMarkup('<a href="#" att-button-loader size="large"></a>');
        expect(elem).toHaveClass('button--disabled');
		 expect(elem).toHaveClass('button--loading');
    });

    it("should render small loader button", function() {
        var elem = compileMarkup('<a href="#" att-button-loader size="small"></a>');
        expect(elem).toHaveClass('button--small');
		 expect(elem).toHaveClass('button--disabled');
    });

    it("should render hero button with cart Icon", function() {
        var elem = compileMarkup('<a href="#" att-button-hero icon="cart">Add to Cart</a>');
        expect(elem).toHaveClass('button--hero');
        var elemChild = elem.children().children();
        expect(elemChild).toHaveClass('icon-cart');
    });
    
    it("should render hero button with Checkout Icon", function() {
        var elem = compileMarkup('<a href="#" att-button-hero icon="arrow-right">Checkout</a>');
        expect(elem).toHaveClass('button--hero');
        var elemChild = elem.children().children();
        expect(elemChild).toHaveClass('icon-arrow-right');
    });

    it("should render disabled button", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="disabled">Learn More</a>');
        expect(elem).toHaveClass('button--disabled');
        expect(elem).not.toHaveClass('button--small');
    });
    
    it("should render small disabled button", function() {
        var elem = compileMarkup('<a href="#" att-button btn-type="disabled" size="small">Learn More</a>');
        expect(elem).toHaveClass('button--disabled');
        expect(elem).toHaveClass('button--small');
    });


    //Test cases for attBtnDropdown
    it("should contain att button dropdown of type dots", function(){
        var elem = compileMarkup('<att-btn-dropdown dropdowntype="dots"> <li> <a href="#/awesome">Awesome</a> </li> <li> <a href = "#/moreawesome">More Awesome</a> </li> </att-btn-dropdown>');
        expect(elem).toHaveClass('att-btn-dropdown');
        expect(elem.children()).toHaveClass('buttons-dropdown--small');

        var elemChildren = elem.children().children().children();
        expect(elemChildren).toHaveClass('circle');
    });

    it("should contain att button dropdown of type actions", function(){
        var elem = compileMarkup('<att-btn-dropdown dropdowntype="actions"> <li> <a href="#/awesome">Awesome</a> </li> <li> <a href = "#/moreawesome">More Awesome</a> </li> </att-btn-dropdown>');
        expect(elem).toHaveClass('att-btn-dropdown');
        expect(elem.children()).toHaveClass('buttons-dropdown--small');

        var elemChildren = elem.children().children().children();
        expect(elemChildren).not.toHaveClass('circle');
    });

});

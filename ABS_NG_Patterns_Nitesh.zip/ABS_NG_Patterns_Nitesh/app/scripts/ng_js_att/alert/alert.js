
'use strict'

angular.module('att.abs.alert', [])
.directive('attAlert', [function()
{
    return {
        restrict: 'EA',        
        replace : true,
        transclude : true,
        scope: { 
            alertType : "@type",
            showTop : "@topPos",
            showAlert : "="
        },
       templateUrl : 'app/scripts/ng_js_att_tpls/alert/alert.html',
       link: function(scope, elem, attr, ctrl)
        {
            if(scope.showTop === 'true'){
                scope.cssStyle = {'top':'50px'};
            }
            else{
               scope.cssStyle = {'top':'0px'};
            }
           scope.close = function(){
               scope.showAlert = false;
            };
        }
    };
}
]);

var AbsAlertCtrl = function($scope,$timeout){ 
    $scope.alertShow = {'sAlert':true,
                       'wAlert':true, 
                        'eAlert':true,
                        'iAlert':true,
                        'stAlert':false, 
                        'wtAlert':false, 
                        'etAlert':false, 
                        'itAlert':false};
    
       $scope.tryClick = function(type){
          if(type === 'success'){
           $scope.alertShow.stAlert = true;
           $scope.alertShow.wtAlert = false;
           $scope.alertShow.etAlert = false;
           $scope.alertShow.itAlert = false;
           $timeout(function() {
             $scope.alertShow.stAlert = false;
           }, 5000);
       }
       else if(type === 'warning'){
           $scope.alertShow.stAlert = false;
           $scope.alertShow.wtAlert = true;
          $scope.alertShow.etAlert = false;
           $scope.alertShow.itAlert = false;
           $timeout(function() {
             $scope.alertShow.wtAlert = false;
           }, 5000);
       }
       else if(type === 'error'){
         $scope.alertShow.stAlert = false;
          $scope.alertShow.wtAlert = false;
          $scope.alertShow.etAlert = true;
          $scope.alertShow.itAlert = false;
          $timeout(function() {
             $scope.alertShow.etAlert = false;
           }, 5000);
       }
       else if(type === 'info'){
          $scope.alertShow.stAlert = false;
          $scope.alertShow.wtAlert = false;
          $scope.alertShow.etAlert = false;
          $scope.alertShow.itAlert = true;
          $timeout(function() {
             $scope.alertShow.itAlert = false;
           }, 5000);
       }                
    };
};

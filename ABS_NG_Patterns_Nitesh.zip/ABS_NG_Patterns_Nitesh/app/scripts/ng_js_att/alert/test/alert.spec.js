describe('Unit Test: Page Warnings', function() {
    var scope, compile;
    beforeEach(module('att.abs.alert'));
    beforeEach(module('app/scripts/ng_js_att_tpls/alert/alert.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));

    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };

    it("Check the alert Box for type Success", function() {

        var elem = compileMarkup('<att-alert type="success">Success. It worked</att-alert>');
        expect(elem).toHaveClass('alert-success');
        expect(elem).not.toHaveClass('alert-warning');
        expect(elem).not.toHaveClass('alert-error');
        expect(elem).not.toHaveClass('alert-info');
    });

    it("Check the alert Box for type Warning", function() {

        var elem = compileMarkup('<att-alert type="warning">Warning.</att-alert>');
        expect(elem).not.toHaveClass('alert-success');
        expect(elem).toHaveClass('alert-warning');
        expect(elem).not.toHaveClass('alert-error');
        expect(elem).not.toHaveClass('alert-info');
    });

    it("Check the alert Box for type Error", function() {

        var elem = compileMarkup('<att-alert type="error">Error.</att-alert>');
        expect(elem).not.toHaveClass('alert-success');
        expect(elem).not.toHaveClass('alert-warning');
        expect(elem).toHaveClass('alert-error');
        expect(elem).not.toHaveClass('alert-info');
    });

    it("Check the alert Box for type Information", function() {

        var elem = compileMarkup('<att-alert type="info">Information. Lorem ipsum.</att-alert>');
        expect(elem).not.toHaveClass('alert-success');
        expect(elem).not.toHaveClass('alert-warning');
        expect(elem).not.toHaveClass('alert-error');
        expect(elem).toHaveClass('alert-info');
    });

    it("Check for the alert Box to be placed at top of window", function() {
        var elem = compileMarkup('<att-alert type="success" top-pos="true">Success. It Worked.</att-alert>');
        expect(elem).toHaveClass('alert-success');
        expect(elem).not.toHaveClass('alert-inplace');
    });

    xit("Check for the alert Box to be closed on click on dismiss button or Close Icon", function() {
        var elem = compileMarkup('<att-alert type="success">Success. It Worked.</att-alert>');
        var btn = elem.children();
        btn.click();
        expect(elem).toHaveClass('ng-hide');
    });

});
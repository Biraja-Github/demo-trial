var AbsBreadCrumbsCtrl = function($scope, $timeout) {
    $scope.crumbData = [{
            title: 'Page #1'
        }, {
            title: 'Page #2'
        }, {
            title: 'Page #3'
        }, {
            title: 'Page #4'
        }];


};

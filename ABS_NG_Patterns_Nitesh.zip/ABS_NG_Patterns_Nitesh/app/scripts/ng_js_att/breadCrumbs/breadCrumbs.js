angular.module('att.abs.breadCrumbs', [])
    .constant("classConstant",{
            "defaultClass" : "breadcrumbs__link",
            "activeClass": "breadcrumbs__link--active"
        })
.directive('attCrumb', ['classConstant', function(classConstant)
{
    return {
        restrict: 'A',        
        replace : true,
        transclude : true,
        scope: {},
        //template : '<div class="breadcrumbs"><span ng-repeat="crumbs in data"><a class="breadcrumbs__link" ng-class="{\'breadcrumbs__link--active\': clickCrumb($index)}">{{crumbs.title}}</a><i class="breadcrumbs__item"></i></span></div>',
        link: function(scope, elem, attr, ctrl)
        {
            elem.addClass(classConstant.defaultClass);
            if(attr.attCrumb === 'active'){
                 elem.addClass(classConstant.activeClass);
            }
           if(!elem.hasClass('last')){
               elem.append('<i class="breadcrumbs__item"></i>');
           }
        }
    };
}
]);

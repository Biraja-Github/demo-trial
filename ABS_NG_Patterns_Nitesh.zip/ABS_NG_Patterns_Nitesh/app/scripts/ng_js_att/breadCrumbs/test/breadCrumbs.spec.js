describe('Unit Test: Page Warnings', function() {
    var scope, compile;
    beforeEach(module('att.abs.breadCrumbs'));
    //beforeEach(module('app/scripts/ng_js_att_tpls/alert/alert.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));

    var compileMarkup = function(markup) {
        var e = angular.element(markup);
        e = compile(e)(scope);
        scope.$apply(e);
        return e;
    };

    it("Check for the active breadCrumbs", function() {

        var elem = compileMarkup('<a att-crumb="active" ng-transclude class="last">Page #4</a>');
        expect(elem).toHaveClass('breadcrumbs__link');
        expect(elem).toHaveClass('breadcrumbs__link--active');
     });

    it("Check for the default breadCrumbs", function() {

        var elem = compileMarkup('<a att-crumb ng-transclude>Page #2</a>');
        expect(elem).toHaveClass('breadcrumbs__link');
        expect(elem).not.toHaveClass('breadcrumbs__link--active');
        
     });
     
  
});
'use strict'

angular.module('att.abs.progressBars', [])

.directive('attProgressBar', [ function() {
    return {
        restrict: 'A',
        replace: true,              
        templateUrl : 'app/scripts/ng_js_att_tpls/progressBars/progressBars.html'
    };
}]);
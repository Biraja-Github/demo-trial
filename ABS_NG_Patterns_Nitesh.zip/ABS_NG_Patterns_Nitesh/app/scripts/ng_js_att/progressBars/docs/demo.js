var AbsProgressBarsCtrl = function() {
    
};
<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **att-progress-bar directive** is built using angular library.
This can be used for rendering a progress bar in an application.

We need to use this directive as an attribute.

<br/><br/>

<p class="guideline-title">Guidelines</p>
<ul class="guideline-description">
    <li>It renders a progress bar in the page, where ever it is applied.</li>
</ul>
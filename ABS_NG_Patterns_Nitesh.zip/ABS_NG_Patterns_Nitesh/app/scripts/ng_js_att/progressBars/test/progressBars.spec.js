describe('progressBars', function() {
    var $scope, $compile;
    beforeEach(module('att.abs.progressBars'));
    beforeEach(module('app/scripts/ng_js_att_tpls/progressBars/progressBars.html'));
    beforeEach(inject(function(_$rootScope_, _$compile_) {
        $scope = _$rootScope_;
        $compile = _$compile_;
    }));       

    var compileElement = function(markup, scope) {
        var el = $compile(markup)(scope);
        scope.$digest();
        return el;
    };

    it('should add progress bar on page', function() {
        var ele = compileElement('<div att-progress-bar></div>', $scope);                
        expect(ele.attr('class')).toBe('att-progress');   
    }); 
    
    it('should add progress bar on page', function() {
        var ele = compileElement('<div att-progress-bar></div>', $scope);                
        expect(ele.find('div').attr('class')).toBe('att-progress-value');   
    });        
});
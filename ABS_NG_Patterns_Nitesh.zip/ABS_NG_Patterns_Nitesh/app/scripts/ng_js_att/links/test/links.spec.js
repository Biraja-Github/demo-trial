describe('links', function() {

    var scope, compile;

    // load the Links Code
    beforeEach(module('att.abs.links'));
    
    // load the template
  beforeEach(module('app/scripts/ng_js_att_tpls/links/readMore.html'));

    beforeEach(inject(function(_$rootScope_, _$compile_) {
        scope = _$rootScope_;
        compile = _$compile_;
    }));

    var compileElement = function(markUp) {
        var elmBody = angular.element(markUp);
        elmBody = compile(elmBody)(scope);
        scope.$digest();
        return elmBody;
    };

    it('should be rendered correctly when attribute for FREE LINKS is used', function() {
        var localElm = compileElement('<a href="#" att-link>Change Device User</a>');
        expect(localElm).toHaveClass('link');
    });
    
    it('should rendered small size links when attribute for FREE LINKS with size:small is used', function() {
        var localElm = compileElement('<a href="#" att-link size="small">Change Device User</a>');
        expect(localElm).toHaveClass('link');
        expect(localElm).toHaveClass('link--small');
    });
    
    it('should be rendered correctly when attribute for LINKS IN COPY is used', function() {
        var localElm = compileElement('<p>The <a href="#" att-link>Samsung GALAXY S4</a> is a handy companion.</p>');
        expect(localElm.find('a').eq(0)).toHaveClass('link');
    });
    
    it('should be rendered correctly when attribute for READMORE LINK is used', function() {
        scope.demoText="In order to manage the many-handed designs this project requires, it is necessary to standardize common UI elements, interactions, patterns and style choices. This allows for consistency to reign and breeds familiarity with the interface for the user. The systems and standards we set in this document will drive the decisions that are made in every new design.";
        var localElm = compileElement('<div att-readmore no-of-lines="3"> </div>');
        expect(localElm.children().children().eq(1).children().eq(0)).toHaveClass('att-readmore-ellipsis');
        expect(localElm.children().children().eq(1).children().eq(1)).toHaveClass('att--readmore__link');
    });
    
    it('should be rendered correctly when attribute for VISITED LINKS is used', function() {
        var localElm = compileElement('<a href="#" att-link-visited>Change Device User</a>');
        expect(localElm).toHaveClass('link--visited');
    });
    
    it('should rendered Vertical Link List when list-align:vertical is used', function() {
        var localElm = compileElement('<ul att-links-list list-align="vertical"><li att-links-list-item><a href="#">First Link</a></li></ul>');
        expect(localElm).toHaveClass('links-list');
        expect(localElm.find('li').eq(0)).toHaveClass('links-list__item');
    });
    
    it('should rendered Vertical Link List when list-align:horizontal is used', function() {
        var localElm = compileElement('<ul att-links-list list-align="horizontal"><li att-links-list-item><a href="#">First Link</a></li></ul>');
        expect(localElm).toHaveClass('links-list--horizontal');
        expect(localElm.find('li').eq(0)).toHaveClass('links-list__item');
    });
    
    it('should rendered LINK with ICON at left position  when attribute attLinkIcon is used', function() {
        var localElm = compileElement('<a href="#" att-link-icon icon-pos="left"><i class="icon-arrow-directional-link-left"></i>See plan details</a>');
        expect(localElm).toHaveClass('link--with-left-icon');
        expect(localElm).toHaveClass('link-spacing');
    });
    
    it('should rendered LINK with ICON at right position when attribute attLinkIcon is used', function() {
        var localElm = compileElement('<a href="#" att-link-icon icon-pos="right">Internet Plans<i class="icon-arrow-directional-link"></i></a>');
        expect(localElm).not.toHaveClass('link--with-left-icon');
        expect(localElm).toHaveClass('link-spacing');
    });
    
    it('should rendered small size LINK with ICON when attribute attLinkIcon is used', function() {
        var localElm = compileElement('<a href="#" att-link-icon size="small" icon-pos="left">Internet Plans<i class="icon-arrow-directional-link"></i></a>');
        expect(localElm).toHaveClass('link--small');
        expect(localElm).toHaveClass('link--with-left-icon');
        expect(localElm).toHaveClass('link-spacing');
    });
});
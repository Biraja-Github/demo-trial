var linksController = function($scope,$http) {
    $scope.demoText = "Give your customers a simple, convinient way to reach you. AT&amp;T Long Distance Toll-Free allows your customers to reach you business, without charges. You choose the calling area from where you would like to receive calls, within the United States and Canada. This feature requires subscription to AT&amp;T Long Distance, a selected calling are that establishes interstate calling, and a valid terminating number.";
    $scope.bgColorClass = 'bg-dark-gray';
    $scope.colorsItem = [];
    $scope.colorClass = [];
    $http.get('data/colors.json').success(function(data) {
        var obj = data;
        for (var key in obj) {
            if (key !== 'dividers') {
                var colorObj = obj[key];
                for (var cKey in colorObj) {
                    var color = (colorObj[cKey].color);
                    var title = (colorObj[cKey].title);
                    var name = (colorObj[cKey].name);
                    $scope.colorsItem.push({'color': color, 'title': title});
                    $scope.colorClass[colorObj[cKey].color] = {'color': color,
                        'colorClass': name
                    };
                    var cItemObj = $scope.colorClass;
                    $scope.$watch('selected', function(val) {
                        for (var key in cItemObj) {
                            if (val == key) {
                                $scope.bgColorClass = cItemObj[key].colorClass;
                            }
                        }
                    });
                }
            }
        }
    });
};


angular.module('att.abs.links', [])
        .directive('attLink', [ function() {
                return {
                    restrict: 'A',
                    link: function(scope, elem, attr) {
                        elem.addClass('link');
                        attr.$observe('size', function(val) {
                            if (val === 'small') {
                                elem.addClass('link--small');
                            }
                        });
                    }
                };
            }])
        .directive('attLinkIcon', [ function() {
                return {
                    restrict: 'A',
                    scope: {
                            pos:'@iconPos'
                        },
                    link: function(scope, elem, attr) {
                        if(scope.pos === 'left')
                            elem.addClass('link link-spacing link--with-left-icon');
                        else if(scope.pos === 'right')
                            elem.addClass('link link-spacing');
                        attr.$observe('size', function(val) {
                            if (val === 'small') {
                                elem.addClass('link--small');
                            }
                        });
                    }
                };
            }])
        .directive('attLinkVisited', [ function() {
                return {
                    restrict: 'A',
                    link: function(scope, elem, attr) {
                        elem.addClass('link--visited');
                    }
                };
            }])
        .directive('attReadmore', ['$timeout',function($timeout) {
                return {
                    restrict: 'A',
                    scope: {
                        lines:"@noOfLines",
                        textModel: "=",
                        isOpen: "=" //attribute to use readmore inside accordion
                    },
                    templateUrl: 'app/scripts/ng_js_att_tpls/links/readMore.html',
                    link: function(scope, elem, attr, ctrl) {
                        var height = 1;
                        scope.$watch('textModel', function(val){
                            if(!val){
                                scope.textToDisplay = '';
                                scope.readMoreText = false;
                                scope.readLessText = false;
                                scope.readFlag = false;
                            }
                            else{
                                if (typeof String.prototype.trim !== 'function') {
                                    String.prototype.trim = function() {
                                       return this.replace(/^\s+|\s+$/g, '');
                                    };
                                }
                                scope.textToDisplay = val.trim();
                                scope.readFlag = true;
                                $timeout(function() {
                                    var readElem = elem[0].children[0].children[0];
                                    if(height===1){
                                        if(window.getComputedStyle){
                                            height = parseInt(scope.lines) * parseFloat(window.getComputedStyle(readElem,null).getPropertyValue("height"));
                                        }
                                        else {
                                            height = parseInt(scope.lines) * parseFloat(readElem.currentStyle.height);
                                        }
                                        scope.elemHeight = height;
                                        scope.readLinkStyle = {'height': scope.elemHeight + 'px'};
                                    }
                                });
                                scope.readMoreText = true;
                                scope.readLessText = false;
                            }
                        });
                                              
                        // Code to use readmore inside accordion 
                        var parentElem = elem.parent();
                        if (parentElem.hasClass('att-accordion__body')) {
                            scope.$watch('isOpen', function(val) {
                                if (!val) {
                                    scope.readLess();
                                }
                            });
                        }
                        
                        scope.readMore = function() {
                            scope.readMoreText = false;
                            scope.readLessText = true;
                            scope.readLinkStyle = {'height': 'auto'};
                            scope.readFlag = false;
                        };
                        
                        scope.readLess = function() {
                            scope.readMoreText = true;
                            scope.readLessText = false;
                            scope.readLinkStyle = {'height': scope.elemHeight + 'px'};
                            scope.readFlag = true;
                        };
                    }
                };
            }])
        .directive('attLinksList', [ function() {
                return {
                    restrict: 'A',
                    controller: function(){
                    },
                    link: function(scope, elem, attr) {
                        attr.$observe('listAlign',function(val){
                            if(val==='vertical')
                                elem.addClass('links-list');
                            else if(val==='horizontal')
                                elem.addClass('links-list--horizontal');
                        });
                    }
                };
            }])
        .directive('attLinksListItem', [ function() {
                return {
                    restrict: 'A',
                    require: '^attLinksList',
                    link: function(scope, elem, attr, attLinksListCtrl) {
                        elem.addClass('links-list__item');
                    }
                };
            }]);
        

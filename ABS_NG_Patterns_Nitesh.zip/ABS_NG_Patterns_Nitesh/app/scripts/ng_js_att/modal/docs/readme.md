<!-- ABSSBA -->
<p class="guideline-title">Directives</p>

The **Modal directive** is built using angular library.
This can be used for rendering modal window in an application.

We can control various parameters like simple-modal,modal-ok, modal-cancel,keyboard,backdrop,controller,window-class while using this directive.

#### `<Attribute level configuration for rendering Modal>` ####

 * `simple-modal`	: This is actual modal directive name.

 * `modal-ok`: This attr  make it easy to close a modal window and the attr serves as an option to specify a callback function, as soon as the modal is closed.

 * `modal-cancel`:This attr  make it easy to close a modal window and the attr serves as an option to specify a callback function, as soon as the modal is closed.
 	
 * `keyboard`: indicates whether the dialog should be closable by hitting the ESC key, defaults to true
 * `backdrop`: controls presence of a backdrop. Allowed values: true (default), false (no backdrop), 'static' - backdrop is present but modal window is not closed when clicking outside of the modal window.
 *	`window-class`:additional CSS class(es) to be added to a modal window template
 *	`controller`: a controller for a modal instance - it can initialize scope used by modal. can be injected with $modalInstance

<br/><br/>

<p class="guideline-title">Red Lines</p>
  <div class="col-md-24">
      <div class="guidelines-system-feedback-modals"></div>
  </div>

<br/><br/>

<p class="guideline-title">Guidelines</p>     
<ul class="guideline-description">
	<li>
		Appears over white background (#FFF) with 80% transparency .
	</li>
	<li>
		For pages with data entry, use a type of OK and CANCEL buttons: describe what
		the buttons do in the body copy (OK saves the user's changes and closed the
		window, CANCEL discards any changes and closes the window). <br>
		Primary action should be the safest action of the one that is recommended by
		the system.
	</li>
	<li>
		Reserve modal dialogs for times when it's absolutely necessary to gather
		information or alert a user to something urgent
	</li>
	<li>
		A modal blocks input to some other top-level windows in an application.
		This type of dialog boxes requires a type of input/response from the user.
	</li>
	<li>
		There are 2 situational categories where modals are commonly used
		<ul>
			<li>Warnings: to warn users of a potentially harmful situation;</li>
			<li>Confirm, Help or Prompt: to remind users to do something before moving forward and to inform users of important information.</li>
		</ul>
	</li>
</ul>
<ul class="guideline-description">

	<li>Use modals only when there is no other alternative (they are disruptive, cause mode errors, steal focus and gloss over UI designs;</li>
	<li>Use inline editing and other means to avoid breaking the users' stride (unless necessary);</li>

	<li>Place modals in close proximity to the link or button or action that triggers it;</li>
	<li>Allow users to close the window with the "ESC" key;</li>
	<li>Use CANCEL buttons when it's correct to do so;</li>
	<li>Close the window when users click outside it (except when there's a CANCEL button);</li>
	<li>Modals should never contain scroll bars, tables and large amounts of text.</li>
	<li>If the modal is for read only, use a CLOSE icon.</li>
</ul>

<p class="guideline-title">Text Format</p>
<ul class="guideline-description guideline-description--dots">
	<li>
		Omnes Light 36pt<br>
		Maximum of 28 characters in a 220px width box.<br>
		Break paragraph when appropriate.<br>

	</li>
	<li>
		Clearview Book 14pt<br>
		Maximum of 166 characters, 4 lines of text, in a 300px width box.<br>
		Break paragraph when appropriate.<br>
	</li>
</ul>
              



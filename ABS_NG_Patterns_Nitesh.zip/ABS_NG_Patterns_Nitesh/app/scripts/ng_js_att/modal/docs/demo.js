var modalpopupController = function($scope) {
    $scope.ok = function() {
        //add the  ok functionality
        alert("Logout");        
    };
    $scope.cancel = function() {
        //add the cancel functionality
        alert("Keep Log in");
    };
    $scope.cancelbutton = function() {
        //add the cancel functionality
        alert("Modal Waring popup close event");
    };
    $scope.accsubmit = function(){
        alert("Your Account information has submited");
    };
    $scope.acccancel = function(){
        alert("Your Account information has cancelled");
    };
    $scope.acc={
       "checkboxGroupAccounts1" :false,
        "checkboxGroupAccounts2" :false,
         "checkboxGroupAccounts3" :false
    };
    $scope.checkboxGroupAccounts1 = 
        {     
            "A":false,
            "B":false,
            "C":false,
            "D":false,
            "E":false  
        };
    $scope.checkboxGroupAccounts2 =
        {
             "A":false,
            "B":false,
            "C":false,
            "D":false,
            "E":false,
            "F":false,
            "G":false,
            "H":false,
            "I":false,
            "J":false
        };  
         $scope.checkboxGroupAccounts3 =
        {
             "A":false,
            "B":false,
            "C":false,
            "D":false,
            "E":false,
            "F":false,
            "G":false,
            "H":false,
            "I":false,
            "J":false
        };
    $scope.options = [        
        {index: 0, value: 'MCN', title: 'MCN', alias:'mcn'},
        {index: 1, value: 'ABC', title: 'ABC', alias:'abc'},
        {index: 2, value: 'DEF', title: 'DEF', alias:'def'}       
    ];		
};

//
//  overlay.js
//  AT&T UI & Patterns Library
//
//  Created by André Neves on 27/05/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('pl.overlay', {
            _super: $.att.base,

            _render: function() {
                this.id = this.$callingElement.attr('id');

                if (!this.id) {
                    this.id = new Date().getTime();

                    this.$callingElement.attr('id', this.id);
                }

                this.$body = $('body');
                this.$container = $('<div>', { 'class': 'overlay' });

                this.$callingElement
                    .find('[data-role="hide-overlay"]')
                    .add($('[data-role="hide-overlay"][data-target="#' + this.id + '"]'))
                    .on('click.overlay', $.proxy(this, 'hide'));

                this.$container
                    .append(this.$callingElement)
                    .prependTo(this.$body);

                // The callingElement is initially hidden because it has data-overlay
                this.$callingElement.show();

                this.$callingElement.find('.overlay-controls__tab-link').on('click.overlay', $.proxy(this, '_onClickTab'));

                this.$triggers = $('[data-role="show-overlay"][data-target="#' + this.id + '"]');

                this.$triggers
                    .off('click.overlay')
                    .on('click.overlay', $.proxy(this, 'show'));

                if (window.location.hash && window.location.hash === ('#' + this.id)) {
                    this.show();
                }
            },

            _onClickTab: function(e) {
                var $tab  = $(e.currentTarget),
                    $tabs = $tab.parents('.overlay-controls__tabs:first');

                $tabs.children().removeClass('overlay-controls__tab--active');
                $tab.parent().addClass('overlay-controls__tab--active');

                this.$callingElement.trigger('change:tab', [$tabs, $tab]);

                e.preventDefault();
            },

            _disableBodyScroll: function() {
                this.$body = $('body');

                var height = this.$body.height(),
                    top    = -this.$body.scrollTop();

                this.$body.css({
                    height:   height,
                    overflow: 'hidden',
                    position: 'fixed',
                    width:    '100%',
                    top:      top
                });

                this.$body.addClass('overlay-visible');
            },

            _enableBodyScroll: function() {
                this.$body = $('body');

                var top = Math.abs(parseInt(this.$body.css('top'), 10));

                this.$body
                    .css({
                        height:   'auto',
                        overflow: 'auto',
                        position: 'static',
                        width:    'auto',
                        top:      'auto'
                    })
                    .scrollTop(top);

                this.$body.removeClass('overlay-visible');
            },

            show: function(e) {
                var self = this;

                if (this.$container.is(':visible')) {
                    return false;
                }

                this._disableBodyScroll();

                window.location.hash = this.id;

                self.$callingElement.trigger('overlay:will-show');

                this.$container.fadeIn(function() {
                    if (self.option('onHide') && $.isFunction(self.option('onHide'))) {
                        self.option('onHide').call(self, [self.$callingElement]);
                    }

                    self.$callingElement.trigger('overlay:shown');
                });

                if (e && e.preventDefault) {
                    e.preventDefault();
                }
            },

            hide: function(e) {
                var self = this;

                if (!this.$container.is(':visible')) {
                    return false;
                }

                self.$callingElement.trigger('overlay:will-hide');

                this.$container.fadeOut(function() {
                    if (self.option('onShow') && $.isFunction(self.option('onShow'))) {
                        self.option('onShow').call(self, [self.$callingElement]);
                    }

                    self._enableBodyScroll();

                    self.$callingElement.trigger('overlay:hidden');

                    if ($.isFunction(e)) {
                        e();
                    } else if (e && e.preventDefault) {
                        e.preventDefault();
                    }
                });
            },

            destroy: function() {
                this._trigger('destroy');
                $.removeData(this.callingElement, this.fullname);
                this._off(this._events, 'off');

                this.$container.remove();
                this.$triggers.off('.overlay');
            },

            options: {
                /**
                 * Callback to execute after the overlay is shown
                 *
                 * @type {Function}
                 * @default null
                 */
                onShow: null,

                /**
                 * Callback to execute after the overlay is hiddeb
                 *
                 * @type {Function}
                 * @default null
                 */
                onHide: null
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-overlay]').overlay();
        });
    }
})();

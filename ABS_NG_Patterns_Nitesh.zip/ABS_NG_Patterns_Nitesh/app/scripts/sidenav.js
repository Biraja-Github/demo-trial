/* global
    store: false,
    ATT: false
*/

'use strict';

var $body         = $('body'),
    $mainSidebar  = $('.main-sidebar'),
    $secondaryNav = $mainSidebar.find('.secondary-nav'),
    $toggleButton = $secondaryNav.find('.secondary-nav__toggle'),
    $pinButton    = $secondaryNav.find('.secondary-nav__pin-toggle input'),
    media         = '(max-width: 1167px)';

$(function() {
    $secondaryNav.on('click', function() {
        if (!$body.hasClass('main-sidebar--expanded')) {
            $body.addClass('main-sidebar--expanded');
        }
    });

    $toggleButton.on('click', function(e) {
        if ($body.hasClass('main-sidebar--expanded')) {
            $body.removeClass('main-sidebar--expanded');

            e.stopPropagation();
        }
    });

    $pinButton.on('change', function() {
        $body.toggleClass('main-sidebar--pinned', $pinButton.prop('checked'));

        store.set('is-main-sidebar-pinned', $pinButton.prop('checked'));
    });

    $body.on('click', function() {
        if (!$body.hasClass('main-sidebar--pinned')) {
            $body.removeClass('main-sidebar--expanded');
        }
    });

    $mainSidebar.on('click', function(e) {
        e.stopPropagation();
    });

    $secondaryNav.on('click', 'a', function(e) {
        var $el     = $(this),
            href    = $el.attr('href'),
            $target = $(href);

        if ($target.size() && ATT) {
            ATT.utils.scrollTo($target, {
                duration: 700,
                callback: function() {
                    window.location.hash = href;
                }
            });
        }

        e.preventDefault();
    });

    var $sections = $('main > section[id]'),
        $sidebarLinks = $secondaryNav.find('.nav__link');

    $sections.waypoint(function() {
        var $section = $(this);
        var id = $section.attr('id');

        $sidebarLinks.filter(':not([data-section])').parent().removeClass('nav__item--active');
        $sidebarLinks.filter('[href="#' + id + '"]').parent().addClass('nav__item--active');

        if ($section.is('[data-main-section]')) {
            var $secondarySections = $section.find('[data-secondary-section]');

            if ($secondarySections.size() === 1) {
                id = $secondarySections.eq(0).attr('id');

                $sidebarLinks.filter('[href="#' + id + '"]').parent().addClass('nav__item--active');
            }
        }
    });

    var toggleTertiarySections = function() {
        var $sections = $('[data-main-section][id], [data-secondary-section][id]');


        $sections.waypoint(function(direction) {
            var $prevMainSection;

            if (!$(this).is('[data-main-section]')) {
                return;
            }

            if (direction === 'down') {
                $prevMainSection = $(this).prevAll('[data-main-section]:first');

                // Entering this section, so expand
                expandNavigationSection($(this));

                // Leaving this section, so expand
                if ($prevMainSection.size()) {
                    collapseNavigationSection($prevMainSection);
                }
            } else {
                $prevMainSection = $(this).prevAll('[data-main-section]:first');

                // Leaving this section, so collapse
                collapseNavigationSection($(this));

                // Entering this section, so expand
                if ($prevMainSection.size()) {
                    expandNavigationSection($prevMainSection);
                }
            }
        }, { offset: '50%' });
    };

    var collapseNavigationSection = function($el) {
        var $item = $('.secondary-nav .nav__link[data-section=' + $el.attr('id') + ']').parent();

        $item.removeClass('nav__item--active');

        $item.find('.tertiary-nav').stop(true, false).slideUp(200);
    };

    var expandNavigationSection = function($el) {
        var $item = $('.secondary-nav .nav__link[data-section=' + $el.attr('id') + ']').parent();

        $item.addClass('nav__item--active');

        $item.find('.tertiary-nav').removeAttr('style');
        $item.find('.tertiary-nav').stop(true, false).slideDown(200);
    };

    toggleTertiarySections();

    $('.tertiary-nav').toggle();

    if (window.location.hash) {
        var id = window.location.hash;
        var $item;

        id = id.slice(1,id.lenght);

        $item = $('.secondary-nav .nav__link[data-section=' + id + ']').parent();

        $item.addClass('nav__item--active');
        $item.find('.tertiary-nav').removeAttr('style');
        $item.find('.tertiary-nav').slideDown(200);
    } else {
        $($('.tertiary-nav')[0]).toggle();
    }

    $(window).on('resize', function() {
        if (
            window.matchMedia &&
            window.matchMedia(media).matches &&
            $body.hasClass('main-sidebar--pinned')
        ) {
            $body.removeClass('main-sidebar--pinned');

            store.set('is-main-sidebar-pinned', false);
            $pinButton.prop('checked', false);
        }
    });

});

if (store.get('is-main-sidebar-pinned') === true && $secondaryNav.size()) {
    $pinButton.prop('checked', true);

    $body.addClass('main-sidebar--pinned main-sidebar--expanded');
}

'use strict';

(function($, window, document, undefined) {

    $(function() {
        jumpToSection();
        initializeBxSlider();
    });


    function jumpToSection() {
        $('.scroll-popup').on('click', function(e) {
            e.preventDefault();

            var offset = $(this).data('offset') || 0;
            var $viewport = $('html, body');

            $viewport
                .stop(true, false).animate({
                    scrollTop: $($(this).attr('href')).offset().top + offset
                }, 1000)

                .bind('scroll mousedown DOMMouseScroll mousewheel keyup', function(){
                    $viewport.stop();
                });

        });
    }

    function initializeBxSlider() {
        $('.home-carousel').bxSlider({
            mode: 'fade',
            slideSelector: '',
            infiniteLoop: false,
            hideControlOnEnd: true,
            speed: 300,
            easing: 'ease-in-out',
            captions: false,
            useCSS: true,
            preloadImages: 'all',
            responsive: true,
            touchEnabled: true,
            pager: true,
            pagerType: 'full',
            pagerSelector: null,
            pagerCustom: null,
            controls: true,
            nextText: '',
            prevText: '',
            nextSelector: null,
            prevSelector: null
        });
    }
}(jQuery, window, document, undefined));

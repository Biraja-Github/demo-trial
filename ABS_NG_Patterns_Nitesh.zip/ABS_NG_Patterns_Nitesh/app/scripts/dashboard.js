'use strict';

(function($, window, document, undefined) {

    // writeHtml(); //first call

    $(function() {
        setTimeout(function() {
            identifiEvents();
        }, 800);
    });

    function identifiEvents() {
        $('.status-new').parent().addClass('new');
        $('.status-fix').parent().addClass('fix');
        $('.status').parent().addClass('normal');

        $('.event').each(function() {
            if ($(this).position().left === 0) {
                $(this).addClass('left');
            } else {
                $(this).addClass('right');
            }
        });
    }

}(jQuery, window, document, undefined));
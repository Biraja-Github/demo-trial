/* global jQuery:false */

'use strict';

(function ($, Handlebars) {

    if (!Handlebars) {
        return;
    }

    Handlebars.registerHelper('highlight', function(what, where, options) {
        var result  = where;

        options = $.extend({}, { wrapWith: 'em', className: 'highlight' }, options.hash);

        result = where.replace(new RegExp(what, 'gi'), '<' + options.wrapWith + ' class="' + options.className + '">' + what + '</' + options.wrapWith + '>');

        return new Handlebars.SafeString(result);
    });

}(jQuery, window.Handlebars));

/*jshint -W117 */
/*jshint -W098 */

'use strict';


(function($, window, document, undefined) {

    $(function() {
        initializeMagnifiers();
    });

    function initializeMagnifiers() {
        $('[data-show-magnifier]').on('click', function(e) {
            var $target = $($(this).data('showMagnifier'));

            if ($target.size() && $target.data('plMagnifier')) {
                $target.magnifier('show');
            }

            e.preventDefault();
        });
    }
}(jQuery, window, document, undefined));

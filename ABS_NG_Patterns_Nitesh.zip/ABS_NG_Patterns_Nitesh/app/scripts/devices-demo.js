'use strict';

$(function() {
    var $demoContainer = $('.devices-demo__container');

    $demoContainer
        .on('change:tab', function(e, $tabs, $activeTab) {
            if ($activeTab.is('[data-toggle-device]')) {
                var device = $activeTab.data('toggle-device');

                $demoContainer.find('.devices-demo').attr('data-device', device);

            } else if ($activeTab.is('[data-toggle-orientation]')) {
                var $demo              = $demoContainer.find('.devices-demo'),
                    currentOrientation = $demo.attr('data-orientation');

                if (currentOrientation === 'portrait') {
                    $demo.attr('data-orientation', 'landscape');
                } else {
                    $demo.attr('data-orientation', 'portrait');
                }
            }
        })
        .on('overlay:shown', function() {
            // Hidden iframe don't load on safari so we wait for the overlay
            // to show, and load the iframe then
            $demoContainer.find('iframe[data-src]').each(function() {
                var $iframe = $(this),
                    src = $iframe.data('src');

                $iframe
                    .attr('src', src)
                    .attr('data-src', null);
            });
        });
});

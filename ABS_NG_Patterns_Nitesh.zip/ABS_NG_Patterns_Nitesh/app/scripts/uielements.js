/* global
jQuery: false
$: false
*/

/*jshint -W117 */
/*jshint -W098 */

'use strict';

(function($, window, document, undefined) {
    $(function() {
        initializeVideos();
        initializeToggleButtons();
        initializeTooltipsDemo();
        initializeLoadingDemo();
        initializeTableSorter();
        initializeFormValidation();
        initializeDemoCarousel();
        initializePagination();
        initializeQuickNav();
        initializeColorSelectors();
    });

    var slider;

    function initializeTableSorter() {

        $.tablesorter.addParser({
            id: 'date',
            is: function() {
                return false;
            },
            format: function(s) {
                return s.toLowerCase().replace(/3 days/,4).replace(/2 days/,3).replace(/1 day/,2).replace(/yesterday/,1).replace(/today/,0);
            },
            type: 'numeric'
        });

        $('#object2Table2').tablesorter({
            theme: 'default',
            widgets: [ 'zebra' ],
            widgetOptions: {
                'zebra': [ 'normal-row', 'alt-row' ],
                'build_type': 'json',
                'build_source': {
                    url: 'data/ui-elements/table.json',
                    dataType: 'json'
                }
            },
            debug: false,
            headers: {
                5: {
                    sorter: 'date'
                },
                6: {
                    sorter: 'inputs'
                }
            }
        }).bind('tablesorter-initialized', function() {
            //insert states
            $(this).find('.tbody__status').html(function () {
                var $state = $(this).text(),
                    $color = 'bg-success-green',
                    $badge;

                if ($state === 'Deactivated') {
                    $color = 'bg-yellow-warning';
                } else if ($state === 'Idle') {
                    $color = 'bg-error-red';
                } else if ($state === 'Locked') {
                    $color = 'bg-secondary-gray';
                }

                $badge = ' <div class="badge">';
                $badge += '<span class="badge__circle ' + $color + '"></span>';
                $badge += '<label class="badge__title">' + $(this).text() + '</label>';
                $badge += '</div>';

                return $badge;
            });

            //insert tools
            $(this).find('.tbody__tools').html(function () {
                var $tool;

                /* jshint indent: false */
                $tool = $([
                    '<div class="button-group">',
                        '<button class="button button--small button--icon">',
                            '<i class="icon-edit"></i>',
                        '</button>',
                        '<div class="button button--small button--icon button--dropdown button--ellipsis">',
                            '<i class="icon-more-options"></i>',
                            '<ul class="dropdown__menu">',
                                '<li class="dropdown__menu-item"><a href="javascript:void(0);" class="dropdown__menu-link">Archive</a></li>',
                                '<li class="dropdown__menu-item"><a href="javascript:void(0);" class="dropdown__menu-link">Save History</a></li>',
                                '<li class="dropdown__menu-item"><a href="javascript:void(0);" class="dropdown__menu-link">Send Email</a></li>',
                                '<li class="dropdown__menu-item"><a href="javascript:void(0);" class="dropdown__menu-link">Delete</a></li>',
                            '</ul>',
                        '</div>',
                    '</div>'
                ].join(''));
                /* jshint indent: 4 */

                return $tool;
            });

            $(this).find('.tbody__tools .button--dropdown').buttonDropdown();

            $(this).on({
                'show-dropdown.att-button-dropdown': function(e) {
                    var $buttonDropdown = $(e.target);

                    $buttonDropdown.parents('tr:first').addClass('active');
                },

                'hide-dropdown.att-button-dropdown': function(e) {
                    var $buttonDropdown = $(e.target);

                    $buttonDropdown.parents('tr:first').removeClass('active');
                }
            });
        });
    }

    function initializeFormValidation() {
        $('#validation-field').on('keyup', function() {
            var el = $(this),
            wrapper = el.parents('.form-field:first'),
            text = el.val();

            if (text === 'password') {
                wrapper
                .removeClass('form-field--success')
                .addClass('form-field--error');

                wrapper.find('.error').show();
                wrapper.find('.success').hide();
            } else if (text === 'business') {
                wrapper
                .removeClass('form-field--error')
                .addClass('form-field--success');

                wrapper.find('.success').show();
                wrapper.find('.error').hide();
            } else if (text === '') {
                wrapper.removeClass('form-field--success form-field--error');

                wrapper.find('.error').hide();
                wrapper.find('.success').hide();
            }
        });
    }

    function initializeToggleButtons() {
        $('[data-toggle-buttons]').on('click', function() {
            var el = $(this),
            icons = el.data('toggle-buttons').replace(' ', '').split(','),
            target = el.data('target') ? el.find(el.data('target')) : el;

            if (icons.length !== 2) {
                return false;
            }

            if (target.hasClass(icons[0])) {
                target.removeClass(icons[0]).addClass(icons[1]);
            } else {
                target.removeClass(icons[1]).addClass(icons[0]);
            }
        });
    }

    function initializeVideos() {
        $('.video-player__volume-bar').on('click', function() {
            var bars = $(this).parent().children().removeClass('video-player__volume-bar--full'),
            index = bars.index($(this)) + 1;

            bars.slice(0, index).each(function() {
                $(this).addClass('video-player__volume-bar--full');
            });
        });
    }

    function initializeTooltipsDemo() {
        $('[data-tooltips-demo]').on('change', ':radio', function() {
            var $radio = $(this),
            action = $radio.data('action'),
            $section = $radio.parents('[data-tooltips-demo]:first'),
            $tooltips = $section.find('.att-tooltip');

            function grey(state) {
                $tooltips.toggleClass('att-tooltip--grey', state);
            }

            function dark(state) {
                if (state) {
                    $tooltips.toggleClass('att-tooltip--dark', state);
                } else {
                    $tooltips.removeClass('att-tooltip--dark');
                }
            }

            function white(state) {
                if (state) {
                    $tooltips.toggleClass('att-tooltip--white', state);
                } else {
                    $tooltips.removeClass('att-tooltip--white');
                }
            }

            if (action === 'set-white') {
                grey(false);
                dark(false);
            } else if (action === 'set-grey') {
                grey(true);
                dark(false);
                white(false);
            } else if (action === 'set-dark') {
                grey(false);
                dark(true);
                white(false);
            } else if (action === 'set-white') {
                grey(false);
                dark(false);
                white(true);
            }
        });
    }

    function initializeLoadingDemo() {
        setInterval(function() {
            var $loadingCount = $('#system-feedback-loading').find('[data-loading]');
            $loadingCount.loading('value', Math.floor(Math.random() * 100));
        }, 2500);

        $('[data-loading-demo]').on('change', ':radio', function() {
            var $radio = $(this),
            action = $radio.data('action'),
            $section = $radio.parents('[data-loading-demo]:first'),
            $loading = $section.find('.loading'),
            $loadingCount = $section.find('[data-loading]'),
            $plLoadingBackground = $section.find('.pl-loading-background');

            $loadingCount.loading('value', Math.floor(Math.random() * 100));
            $plLoadingBackground.removeClass().addClass('pl-loading-background');

            function dark(state) {
                $loading.toggleClass('att-loading--dark', state);
                $loadingCount.toggleClass('att-loading--dark', state);
            }

            function blue(state) {
                if (state) {
                    $loading.toggleClass('att-loading--blue', state);
                    $loadingCount.toggleClass('att-loading--blue', state);
                } else {
                    $loading.removeClass('att-loading--blue');
                    $loadingCount.toggleClass('att-loading--blue', state);
                }
            }

            function white(state) {
                if (state) {
                    $plLoadingBackground.addClass('att-loading--white');
                    $loading.toggleClass('att-loading--white', state);
                    $loadingCount.toggleClass('att-loading--white', state);
                } else {
                    $loading.removeClass('att-loading--white');
                    $loadingCount.toggleClass('att-loading--white', state);
                }
            }

            if (action === 'set-dark-gray') {
                dark(true);
                blue(false);
                white(false);
            } else if (action === 'set-prime-blue') {
                dark(false);
                blue(true);
                white(false);
            } else if (action === 'set-white') {
                dark(false);
                blue(false);
                white(true);
            }
        });
    }

    function initializeQuickNav() {
        $('.pl-quick-nav__demo .att-quick-nav__items-container').on('mouseenter mouseleave', function(e) {
            $(this).toggleClass('att-quick-nav--open', e.type === 'mouseenter');
        });
    }

    function initializeColorSelectors() {
        $('.pl-color-selector').colorSelector({
            change: function(el) {
                var newClass = el.attr('value'),
                $section = $(this).parents('[data-color-demo-container]:first'),
                $previewEl = $section.find('[data-preview-element]'),
                secondEl = $section.find('[data-preview-second-element].tabs__content');

                if ($previewEl.hasClass('elements-vertical-align')) {
                    newClass = newClass + ' elements-vertical-align';
                }

                if (secondEl) {
                    secondEl.removeClass().addClass(newClass.replace('triangle', 'bg') + ' tabs__content');
                }

                $previewEl
                .removeClass()
                .addClass(newClass);
            }
        });
    }

    function initializePagination() {

        function goToPage(element, page) {
            var itemToSelect = $(element),
            pager = itemToSelect.parent(),
            displayedPages = 3,
            edges = 2,
            pages = 100,
            itemsOnPage = 6,
            currentPage = page;

            var halfDisplayed = Math.ceil(displayedPages / 2),
            interval = {
                start: Math.ceil(currentPage > halfDisplayed ? Math.max(Math.min(currentPage - halfDisplayed, (pages - displayedPages)), 0) + 1 : 0),
                end:  Math.ceil(currentPage > halfDisplayed ? Math.min(currentPage + halfDisplayed, pages)  : Math.min(displayedPages, pages))
            };

            var $panel = $('<ul>', { 'class': pager });
            var i;

            var prevButton = $('<li>', { 'class': 'pager__item pager__item--prev' })
            .append($('<a>', { 'class': 'pager__item-link' }).html('<i class="icon-arrow-left"></i>Previous'));

            var nextButton = $('<li>', { 'class': 'pager__item pager__item--next' })
            .append($('<a>', { 'class': 'pager__item-link', 'text': 'Next' })
                .append($('<i>', { 'class': 'icon-arrow-right' })));

            if (currentPage > 1) {
                prevButton.appendTo($panel);
            }else {
                prevButton.addClass('pager__item--hidden').appendTo($panel);
            }

            if (currentPage < itemsOnPage) {
                for (i = 0; i < itemsOnPage; i++) {
                    $('<li>', {
                        'class': 'pager__item',
                        'data-page': i +1
                    }).append($('<a>', { 'class': 'pager__item-link', 'text': i + 1 }))
                    .appendTo($panel);
                }
            } else {

                if (interval.start > 0 && edges > 0) {
                    var end = Math.min(edges, interval.start);
                    for (i = 0; i < end; i++) {
                        $('<li>', {
                            'class': 'pager__item',
                            'data-page': i +1
                        }).append($('<a>', { 'class': 'pager__item-link', 'text': i + 1 }))
                        .appendTo($panel);
                    }
                    if (edges < interval.start && (interval.start - edges !== 1)) {
                        $panel.append('<li class="disabled pager__item"> ... </li>');
                    } else if (interval.start - edges === 1) {
                        $('<li>', {
                            'class': 'pager__item',
                            'data-page': edges
                        }).append($('<a>', { 'class': 'pager__item-link', 'text': edges }))
                        .appendTo($panel);
                    }
                }
                if (currentPage <= pages - itemsOnPage + 1) {
                    for (i = interval.start; i < interval.end; i++) {
                        $('<li>', {
                            'class': 'pager__item',
                            'data-page': i
                        }).append($('<a>', { 'class': 'pager__item-link', 'text': i }))
                        .appendTo($panel);
                    }
                }
            }

            if (currentPage > pages - itemsOnPage + 1) {
                for (i = pages - itemsOnPage; i < pages; i++) {
                    $('<li>', {
                        'class': 'pager__item',
                        'data-page': i +1
                    }).append($('<a>', { 'class': 'pager__item-link', 'text': i + 1 }))
                    .appendTo($panel);
                }
            } else {
                if (interval.end < pages && edges > 0) {
                    if (pages - edges > interval.end) {
                        $panel.append('<li class="disabled pager__item"> ... </li>');
                    } else if (pages - edges - interval.end === 1) {
                        $('<li>', {
                            'class': 'pager__item',
                            'data-page': interval.end
                        }).append($('<a>', { 'class': 'pager__item-link', 'text': interval.end }))
                        .appendTo($panel);
                    }
                    var begin = Math.max(pages - edges, interval.end);
                    for (i = begin; i < pages; i++) {
                        $('<li>', {
                            'class': 'pager__item',
                            'data-page': i + 1
                        }).append($('<a>', { 'class': 'pager__item-link', 'text': i + 1 }))
                        .appendTo($panel);
                    }
                }
            }

            if (currentPage < pages) {
                nextButton.appendTo($panel);
            }else {
                nextButton.addClass('pager__item--hidden').appendTo($panel);
            }

            pager.html($panel.html());
            pager.find('li[data-page="' + currentPage + '"]').addClass('pager__item--active');
        }

        $('#pagination-medium-page-count').on('click', '.pager__item--prev', function() {
            var currentPage = $(this).parent().find('.pager__item--active').data('page');
            goToPage(this, currentPage - 1);
        });

        $('#pagination-medium-page-count').on('click', '.pager__item--next', function() {
            var currentPage = $(this).parent().find('.pager__item--active').data('page');
            goToPage(this, currentPage + 1);
        });

        $('#pagination-medium-page-count').on('click', '.pager__item[data-page]', function() {
            var currentPage = $(this).data('page');

            goToPage(this, currentPage);
        });

        $('.views-per-page__item').on('click', function() {
            var itemToSelect = $(this),
            perPage = itemToSelect.parent(),
            itemSelected = perPage.find('.views-per-page__item--active');

            if (itemSelected === itemToSelect) {
                return;
            } else if (itemToSelect.is(':first-child') === false) {
                itemSelected.removeClass('views-per-page__item--active');
                itemToSelect.addClass('views-per-page__item--active');
            }
        });

        $('#pagination-small-count-demo').on('click', '.pager__item', function() {
            var itemToSelect = $(this),
            smallCount = itemToSelect.parent(),
            itemSelected = smallCount.find('.pager__item--active');

            itemSelected.removeClass('pager__item--active');
            itemToSelect.addClass('pager__item--active');
        });

    }

    function initializeDemoCarousel() {
        slider = $('.demo-carousel').bxSlider({
            autoHover:  true,
            auto:       false,
            pause:      2000,
            speed:      900,
            useCSS:     false,
            prevText:   '',
            nextText:   '',
            slideWidth: 250
        });
    }
}(jQuery, window, document, undefined));

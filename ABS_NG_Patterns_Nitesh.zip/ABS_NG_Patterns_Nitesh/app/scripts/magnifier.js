//
//  magnifier.js
//  AT&T UI & Patterns Library
//
//  Created by André Neves on 27/05/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('pl.magnifier', {
            _super: $.att.base,

            isVisible: false,

            _dragStartPosition: null,

            _render: function() {
                var self = this;
                var imageSrc = this.$callingElement.attr('src');
                var img = new Image();

                img.onload = function() {
                    self.$container = $('<div>', { 'class': 'pl-magnifier' });
                    self.$loupe = $('<div>', { 'class': 'pl-magnifier__loupe' });
                    self.$close = $('<div>', { 'class': 'pl-magnifier__close' });

                    self.$loupe.css({
                        'background-image': 'url(' + imageSrc + ')',
                        'background-size': (self.$callingElement.width() * self.option('zoom')) + 'px auto',
                        'width': self.option('size') + 'px',
                        'height': self.option('size') + 'px'
                    });

                    self.$container.insertBefore(self.$callingElement);
                    self.$callingElement.appendTo(self.$container);
                    self.$container.append(self.$loupe);
                    self.$loupe.append(self.$close);

                    self.$loupe
                        .hammer({
                            'correct_for_drag_min_distance': false,
                            'drag_block_horizontal': true,
                            'prevent_default': true
                        })
                        .on('dragstart drag dragleave dragend click', $.proxy(self, '_handleDrag'));

                    self.$close.on('click', $.proxy(self, 'hide'));

                    var x = self.$callingElement.width() - self.option('size');
                    var y = 0;

                    if (self.option('size') >= self.$callingElement.height()) {
                        y = Math.round(self.$callingElement.height() / 2 -  self.option('size') / 2);
                    }

                    self._moveTo(x, y);
                };

                img.src = imageSrc;
            },

            _handleDrag: function(evt) {
                var x;
                var y;

                if (evt.type === 'dragstart') {
                    this._dragStartPosition = this.$loupe.position();
                }

                if (evt.type === 'drag') {
                    x = Math.round(this._dragStartPosition.left + evt.gesture.deltaX);
                    y = Math.round(this._dragStartPosition.top + evt.gesture.deltaY);

                    this._moveTo(x, y);
                }

                if (evt.type === 'dragend') {
                    x = parseInt(this.$loupe.css('left'), 10);
                    y = parseInt(this.$loupe.css('top'), 10);
                    var startX = -(this.option('size') / 2 * (this.option('zoom') - 1));
                    var startY = startX;
                    var endX = this.callingElement.width + startX;
                    var endY = this.callingElement.height + startY;
                    var moveMagnifier = { move: false, x: x, y: y};

                    if (x < startX) {
                        moveMagnifier.x = startX;
                        moveMagnifier.move = true;
                    }

                    if (y < startY) {
                        moveMagnifier.y = startY;
                        moveMagnifier.move = true;
                    }

                    if (x > endX) {
                        moveMagnifier.x = endX;
                        moveMagnifier.move = true;
                    }

                    if (y > endY) {
                        moveMagnifier.y = endY;
                        moveMagnifier.move = true;
                    }

                    if (moveMagnifier.move) {
                        this._animeteTo(moveMagnifier.x, moveMagnifier.y);
                    }
                }
            },

            _moveTo: function(x, y) {
                var bgLeft = -(x * this.option('zoom') + (this.option('size') / 2 * (this.option('zoom') - 1))) + 'px';
                var bgTop = -(y * this.option('zoom') + (this.option('size') / 2 * (this.option('zoom') - 1))) + 'px';

                this.$loupe.css({
                    'left': x,
                    'top': y,
                    'background-position': bgLeft + ' ' + bgTop
                });
            },

            _animeteTo: function(x, y) {
                var bgLeft = -(x * this.option('zoom') + (this.option('size') / 2 * (this.option('zoom') - 1))) + 'px';
                var bgTop = -(y * this.option('zoom') + (this.option('size') / 2 * (this.option('zoom') - 1))) + 'px';
                var animation = {
                    'left': x,
                    'top': y,
                    'background-position-x': bgLeft,
                    'background-position-y': bgTop
                };

                this.$loupe.animate( animation, 500 );
            },

            toggle: function() {
                this[this.isVisible ? 'hide' : 'show'].apply(this, arguments);
            },

            show: function() {
                this.$container.addClass('pl-magnifier--visible');

                this.isVisible = true;
            },

            hide: function() {
                this.$container.removeClass('pl-magnifier--visible');

                this.isVisible = false;
            },

            options: {
                zoom: 2,
                size: 160
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'hammerjs', 'jquery.hammer', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($, window.Hammer);

        $(function() {
            $('img[data-magnifier]').magnifier();
        });
    }
})();

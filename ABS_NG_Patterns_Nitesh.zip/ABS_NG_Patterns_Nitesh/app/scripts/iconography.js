/* global
    Handlebars: false,
    store: false
*/

'use strict';

$(function() {

    function Icons(icons, $el, iconTemplate) {
        var self = this;

        this.filter = store.get('Iconography:filter') ? store.get('Iconography:filter') : '';
        this.sort = store.get('Iconography:sort') ? store.get('Iconography:sort') : 'name';
        this.category = store.get('Iconography:category') ? store.get('Iconography:category') : 'all';
        this.size = store.get('Iconography:size') ? store.get('Iconography:size') : 'large';
        this.$el = $($el);
        this.iconClasses = [];
        this.categoryIcons = [];
        this.iconTemplate = iconTemplate;
        this.icons = icons;
        this.defaultIcons = icons.slice(0);

        $.each(icons, function (i, icon) {
            self.iconClasses.push(icon.title);
        });

        this.render();
    }

    Icons.prototype = {
        setTotalIcons: function() {
            $('h1 sup').html('(' + this.$el.find('li:visible').length + ')');
        },

        setSortBy: function(sort) {
            if (['name', 'date'].indexOf(sort) === -1) {
                sort = 'name';
            }

            this.sort = sort;
            store.set('Iconography:sort', sort);

            this.render();
        },

        setCategoryBy: function(category) {
            this.category = category;

            store.set('Iconography:category', category);

            this.icons = this.getIconsByCategory(this.category);

            this.render();
        },

        setSizeBy: function(size) {
            this.$el.attr('data-size', size);

            this.$el.find('[data-category^="all"]').removeClass('disabled');
            switch(size) {
                case 'small':
                case 'bluebar':
                case 'medium':
                    this.$el.find('[data-category*="flat-large-size"]').addClass('disabled');
                    break;

                case 'extralarge':
                    this.$el.find('[data-category*="flat-small-size"]').addClass('disabled');
                    break;

            }

            this.size = size;
            store.set('Iconography:size', size);
        },

        getIconsSortedBy: function(order) {
            order = order || this.sort;

            var icons = this.icons;

            if (order === 'name') {
                icons = icons.sort(function(a, b) {
                    if (a.name < b.name) {
                        return -1;
                    }

                    if (a.name > b.name) {
                        return 1;
                    }

                    return 0;
                });
            }

            return icons;
        },

        getIconsByCategory: function(category) {
            category = category || this.category;

            var icons = this.icons;

            var resultIcons  = [];
            this.$el.find('.icons-list__item').show();

            if(category !== 'all') {
                $.each(icons, function(i, icon) {
                    if(icon.category === category ) {
                        resultIcons.push(icon);
                    }
                });
            }

            // this.setSizeBy(this.size);

            return category !== 'all' ? resultIcons : icons;
        },

        render: function() {
            var self = this;

            this.$el.empty();

            self.icons = self.defaultIcons.slice(0);

            this.icons = this.getIconsByCategory(this.category);
            this.icons = this.getIconsSortedBy(this.sort);

            $.each(self.icons, function(i, icon) {
                var item = self.iconTemplate({
                    'class': icon.title,
                    'name':  icon.name,
                    'category': icon.category
                });

                self.$el.append($(item));
            });

            self.$el.find(self.categoryIcons.join(',')).parent().hide();

            this.search(this.filter);

            this.$el.find('.icons-list__item').removeClass('disabled');

            this.setTotalIcons();
        },

        search: function(val) {
            var $icons = this.$el.children(),
                invert = val[0] === '!',
                expr   = new RegExp(invert ? val.substr(1) : val, 'gi'),
                found  = [];

            $.each(this.iconClasses, function() {
                var className = this;

                if (className.match(expr)) {
                    found.push('.' + className);
                }
            });

            if (found.length === 0) {
                $('.no-icons').css('display', 'inline-block');
            } else {
                $('.no-icons').css('display', 'none');
            }

            found = found.join(',');

            $icons.find(found).parent()[invert ? 'hide' : 'show']();
            $icons.find('i:not(' + found + ')').parent()[invert ? 'show' : 'hide']();

            this.filter = val;

            store.set('Iconography:filter', this.filter);

            this.setTotalIcons();
        }
    };

    var iconTemplate = Handlebars.compile($('#icon-template').html());
    var iconography = new Icons(window.icons || [], '.icons-list', iconTemplate);

    $('#input-search-icons').on('keyup', function() {
        var value = $(this).val().replace(/\ \ /g, ' ').replace(/\ /g, '-').replace(/\*/g, '.*');

        clearTimeout(window.iconographySearchTimeout);

        window.iconographySearchTimeout = setTimeout(function() {
            iconography.search(value);
        }, 200);

    });

    $('#select-filter')
        .on('change', function() {
            iconography.setSortBy($(this).val());
        });

    $('#select-font')
        .on('change', function() {
            iconography.setCategoryBy($(this).val());
        });

    $('#select-size')
        .on('change', function() {
            iconography.setSizeBy($(this).val());
        });

    $('form').on('submit',function(e) {
        $('#input-search-icons').blur();
        e.preventDefault();
    });

    if(store.get('Iconography:filter')) {
        $('#input-search-icons').val(store.get('Iconography:filter'));
    }

    if(store.get('Iconography:sort')) {
        var sort = store.get('Iconography:sort');
        var sortName = $('#select-filter').find('[data-filter="'+sort+'"]').attr('selected','').text();
        $('#s2id_select-filter').find('.select2-chosen').text(sortName);
    }

    if(store.get('Iconography:category')) {
        var category = store.get('Iconography:category');
        var categoryName = $('#select-font').find('[data-category="'+category+'"]').attr('selected','').text();
        $('#s2id_select-font').find('.select2-chosen').text(categoryName);
    }

    if(store.get('Iconography:size')) {
        var size = store.get('Iconography:size');
        var sizeValue = $('#select-size').find('option[value="'+size+'"]').attr('selected','').text();
        $('#s2id_select-size').find('.select2-chosen').text(sizeValue);
        iconography.setSizeBy(size);
    }



    var updateHeader = function() {
        var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
        var $header = $('.iconography-header');
        var paddingTop = Math.max(420 - scrollTop, 0);

        $header.css('padding-top', paddingTop);
    };

    updateHeader();

    $(window).on('scroll', updateHeader);

});

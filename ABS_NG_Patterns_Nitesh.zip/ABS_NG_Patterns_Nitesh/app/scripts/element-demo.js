//
//  element-demo.js
//  AT&T UI & Patterns Library
//
//  Created by André Neves on 27/05/14.
//  Copyright (c) 2014 AT&T. All rights reserved.
//

/* global
    define: false
*/

'use strict';

(function() {

    function factory($) {
        $.jqfactory('pl.elementDemo', {
            _super: $.att.base,

            _render: function() {
                this.$radios = this.$callingElement.find('.radio-selectors :radio');
                this.$states = this.$callingElement.find('[data-demo-state]');
                this.$tag = this.$callingElement.find('[data-demo-tag]');

                if (!this.$states.eq(0).is('img')) {
                    this.$tag.css({
                        opacity: 0
                    });
                }

                this.$states
                    .each(function() {
                        var $el = $(this);
                        var display = $el.css('display');

                        $el.data('display', display);
                    })

                    .not('[data-demo-state=reset]').hide()
                ;

                this.$radios.on('change.element-demo', $.proxy(this, '_change'));
            },

            _change: function(e) {
                var $radio = $(e.currentTarget);
                var state = $radio.attr('data-demo-set-state');
                var $newStateElement = this.$states.filter('[data-demo-state=' + state + ']');
                var display = $newStateElement.data('display');

                this.$states.filter(':visible').filter(':not([data-demo-state=' + state + '])').fadeOut(40, function() {
                    if (display) {
                        $newStateElement.css('display', display === 'none' ? 'block' : display);
                    }
                });

                this.$tag.css({
                    opacity: $newStateElement.is('img') ? 1 : 0
                });
            }
        }, false);
    }

    if (typeof define === 'function' && define.amd) {
        define([ 'jquery', 'att.base' ], factory);
    } else {
        var $ = window.jQuery;

        factory($);

        $(function() {
            $('[data-element-demo]').elementDemo();
        });
    }
})();

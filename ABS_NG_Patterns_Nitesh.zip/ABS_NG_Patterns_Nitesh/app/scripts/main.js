/* global FastClick: false */

'use strict';

$(function() {
    FastClick.attach(document.body);

    // Prevent "empty" links from navigating to top
    $('a[href="#"]').on('click', function(e) {
        e.preventDefault();
    });
});

// speed - could be defined with 'slow', 'medium' or 'fast' or even with a 'milisecond' value.
var speed = 'slow';

$('html, body').hide();
$(document).ready(function() {
    $('html, body').fadeIn(speed, function() {
        $('.nav__item[href]').click(function(event) {
            var url = $(this).attr('href');

            event.preventDefault();
            $('html, body').fadeOut(speed, function() {
                window.location = url;
            });
        });
    });
});

$('#dev-mode').change(function() {
    $('.dev-box').slideToggle($(this).is(':checked'));
});

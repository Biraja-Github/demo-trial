'use strict';

$(function() {
    $('a').on('click', function(e) {
        e.preventDefault();
    });
});

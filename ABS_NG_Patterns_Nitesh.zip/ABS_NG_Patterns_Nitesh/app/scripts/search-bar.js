
/* global
    ATT: false,
    Bloodhound: false,
    Handlebars: false
*/

'use strict';

$(function() {
    var $searchContainer =  $('.search-container'),
        $search =  $('#search .typeahead'),
        options = [
            {
                hint: true,
                highlight: true,
                autoselect: true
            }
        ],
        dataSets = {
            'structures': {
                title: 'Structures',
                jsonFile: '../data/search-bar/structures.json'
            },
            'uielements': {
                title: 'UI Elements',
                jsonFile: '../data/search-bar/ui_elements.json'
            },
            'uipatterns': {
                title: 'UI Patterns',
                jsonFile: '../data/search-bar/ui_patterns.json'
            }
        };

    $.each(dataSets, function(name, set) {
        var items = new Bloodhound({
            datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value'),
            queryTokenizer: Bloodhound.tokenizers.whitespace,
            prefetch: set.jsonFile
        });

        items.initialize();

        options.push({
            name: name,
            displayKey: 'value',
            source: items.ttAdapter(),
            templates: {
                header: '<h4 class="section-name">' + set.title + '</h4>',
                suggestion: Handlebars.compile('<a href="{{url}}" class="suggestion-value">{{value}}</a>')
                //footer: '<h4 class="empty-message">' + 'No results found' + '</h4>'
                // empty: [
                //   '<div class="empty-message">',
                //   'Could not find content that matches the current query',
                //   '</div>'
                // ].join('\n')
            }
        });
    });

    $.fn.typeahead.apply($search, options);

    //add "not found" box below the typeahead when no results are found
    var active = false;
    $('input.typeahead.tt-input').on('keyup', function(e) {

        // number of sections with content
        var dropdownSections = $('.tt-suggestions').length;
        var insertedTextLength = $('input.typeahead.tt-input').val().length;
        var code = e.keyCode || e.which;

        if( dropdownSections === 0 && active === false && insertedTextLength > 0) {
            $('input.typeahead.tt-input').after('<div class="empty-results"><p class="empty-results-message">No results found...</p><a class="goto-sitemap" href="#">Go to sitemap</a></div>');
            active = true;
        }

        if (dropdownSections >= 0 && code === 8) {
            $('.empty-results').remove();
            active = false;
        }
    });

    $('#search').css('opacity', 1);

    $search
        .on('typeahead:selected', function(e, suggestion, setName) {
            var currentPage = $('html').data('page'),
                targetPage  = setName,
                matches     = suggestion.url.match(/.+(\#.+)/),
                anchor;

            if (matches) {
                anchor = matches[1];
            }

            if (currentPage === targetPage) {
                $('#search-overlay').overlay('hide');
                $search.typeahead('val', '');

                ATT.utils.scrollTo(anchor, { duration: 700 });

                e.preventDefault();
            } else {
                if (suggestion && suggestion.url) {
                    window.location = suggestion.url;
                }
            }
        })
        .on('focus blur', function(e) {
            $searchContainer.toggleClass('search-container--focused', e.type === 'focus');
        })
    ;

    $('#search-overlay').on('overlay:shown', function() {
        $search.focus();
    });


    var isPortrait, isLandscape;
    window.addEventListener('orientationchange', function() {
        if (window.orientation === 0 || window.orientation === 180 ) { //PORTRAIT
            isPortrait = true;
            isLandscape = false;
        }
        if (window.orientation === 90 || window.orientation === -90 ) { //LANDSCAPE
            isPortrait = false;
            isLandscape = true;
        }
        console.log(window.orientation);
    }, false);

    // to prevent dropdown resize behavior on desktop


    if (ATT.utils.isMobile.any()) {

        //ToDo

        //html data-page = "uipatterns"

        //console.log($('html').attr());




         //when opening the keyboard on ipad, set the max-height of dropdown
        $('input.typeahead.tt-input').on('focus', function() {

            $('.search-container').removeClass('slide-header-search-blur');
            $('.top-banner__landing-header').removeClass('slide-header-search-blur');
            $('.search-container').addClass('slide-header-search-focus');
            $('.top-banner__landing-header').addClass('slide-header-search-focus');

            $('.top-banner').removeClass('slide-background-blur');
            $('.top-banner').addClass('slide-background-focus');

            $('.tt-dropdown-menu').removeClass('tt-dropdown-height-blur');
            $('.tt-dropdown-menu').addClass('tt-dropdown-height-focus');
            window.scrollTo(0,300);
        });

        //when closing the keyboard on ipad, increase the max-height of dropdown
        $('input.typeahead.tt-input').on('blur', function() {

            $('.search-container').removeClass('slide-header-search-focus');
            $('.top-banner__landing-header').removeClass('slide-header-search-focus');
            $('.search-container').addClass('slide-header-search-blur');
            $('.top-banner__landing-header').addClass('slide-header-search-blur');

            $('.top-banner').removeClass('slide-background-focus');
            $('.top-banner').addClass('slide-background-blur');

            $('.tt-dropdown-menu').removeClass('tt-dropdown-height-focus');
            $('.tt-dropdown-menu').addClass('tt-dropdown-height-blur');
            window.scrollTo(0,0);
        });
    }

    // on vertical resize of the window, make the dropdown shorter
    if (!ATT.utils.isMobile.any()) {
        $(window).resize(function() {
            $('.tt-dropdown-menu').css('max-height', $(window).height() - 450 + 'px');
        });
        //console.log('RESIZE');
    }

    // when inserting text on the input search bar, make the clear icon appear
    $('input.typeahead.tt-input').on('keyup', function() {
        var insertedText = $('input.typeahead.tt-input').val();

        if (insertedText === null || insertedText === '') {       //if content is empty, hide icon
            $('.pl-icon-close').removeClass('close-visible');
        }
        else {                                                    // else (if has text, show icon)
            $('.pl-icon-close').addClass('close-visible');
        }
    });

    // clear the input
    $('.icon-container').on('click', function() {
        $('.typeahead').typeahead('val','');
        //$('input.typeahead.tt-input').focus();
        $('.pl-icon-close').removeClass('close-visible');

    });
});
